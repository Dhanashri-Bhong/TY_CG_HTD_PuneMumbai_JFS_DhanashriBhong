package com.capgemini.studmaintenanceapplication.dao;

import java.util.List;

import com.capgemini.studmaintenanceapplication.bean.GradeBean;
import com.capgemini.studmaintenanceapplication.bean.StudentBean;

public interface StudentDao {

	
	public StudentBean searchStudent(int sid);
	public boolean addStudent(StudentBean student);
	public boolean updateStudent(StudentBean student);
	public boolean deleteStudent(int sid);
	public List<StudentBean> getAllStudents();
	public GradeBean aggregate(GradeBean grade);
	

}
