package com.capgemini.studmaintenanceapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.studmaintenanceapplication.bean.GradeBean;
import com.capgemini.studmaintenanceapplication.bean.StudentBean;
import com.capgemini.studmaintenanceapplication.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService {

	
	@Autowired
	private StudentDao dao;
	
	@Override
	public StudentBean searchStudent(int sid) {
		
		if(sid > 0) {
		return dao.searchStudent(sid);
		}
		return null;
	}

	
	@Override
	public boolean addStudent(StudentBean student) {
		return dao.addStudent(student);
	}

	@Override
	public boolean updateStudent(StudentBean student) {
		return dao.updateStudent(student);
	}

	@Override
	public boolean deleteStudent(int sid) {
		return dao.deleteStudent(sid);
	}

	@Override
	public List<StudentBean> getAllStudents() {
		return dao.getAllStudents();
	}


	@Override
	public GradeBean aggregate(GradeBean grade) {
		return dao.aggregate(grade);
	}

}
