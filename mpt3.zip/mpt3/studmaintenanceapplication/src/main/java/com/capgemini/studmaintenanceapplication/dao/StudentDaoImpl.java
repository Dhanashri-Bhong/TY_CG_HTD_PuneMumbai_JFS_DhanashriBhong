package com.capgemini.studmaintenanceapplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.studmaintenanceapplication.bean.GradeBean;
import com.capgemini.studmaintenanceapplication.bean.StudentBean;

@Repository
public class StudentDaoImpl implements StudentDao {

	
	@PersistenceUnit
	 private EntityManagerFactory emf;

	@Override
	public StudentBean searchStudent(int sid) {
     
		EntityManager manager = emf.createEntityManager();
		StudentBean student = manager.find(StudentBean.class, sid);
		manager.close();
		
		
		return student;
	}//end of search Student
	
	@Override
	public boolean addStudent(StudentBean student) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdd= false;
		try{tx.begin();
		manager.persist(student);
		tx.commit();
		isAdd = true;
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		manager.close();
		return isAdd;
	}//end of add

	@Override
	public boolean updateStudent(StudentBean student) {

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		
		StudentBean studInfo = manager.find(StudentBean.class, student.getSid());
		if(studInfo != null) {
			if(student.getEmail()!=null) {
				studInfo.setEmail(student.getEmail());
			}
				
		}
		boolean isUpdate = false;
		try{tx.begin();
		manager.persist(studInfo);
		tx.commit();
		isUpdate = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		manager.close();
		return isUpdate;
	
	}//end of update
	
	
	@Override
	public boolean deleteStudent(int sid) {
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			StudentBean studentBean= entityManager.find(StudentBean.class, sid);
			entityManager.remove(studentBean);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}// End of delete

	@Override
	public List<StudentBean> getAllStudents() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from StudentBean";
		Query query = manager.createQuery(jpql);
		
		List<StudentBean> sbList = null;
		try {
			sbList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return sbList;
		
	}// End of getAllEmployees()

	@Override
	public GradeBean aggregate(GradeBean grade) {
		
		EntityManager manager = emf.createEntityManager();
		String jpql = "from GradeBean select avg where sid : sid in(from StudentBean select SUM(1yearmark+2yearmark+3yearmark)/3";
		Query query = manager.createQuery(jpql);
        
		
		try {
			grade = (GradeBean) query.getSingleResult();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return grade;
	}
}
