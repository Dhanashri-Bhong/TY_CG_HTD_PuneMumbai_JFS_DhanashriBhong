package com.capgemini.studmaintenanceapplication.bean;

import java.util.List;

public class StudentResponse {

	
	private int statusCode;
	private String message;
	private String description;
	private StudentBean sb;
	private List<StudentBean> sbList ;
	
	//getters and setters
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public StudentBean getSb() {
		return sb;
	}
	public void setSb(StudentBean sb) {
		this.sb = sb;
	}
	public List<StudentBean> getSbList() {
		return sbList;
	}
	public void setSbList(List<StudentBean> sbList) {
		this.sbList = sbList;
	}
	
}
