package com.capgemini.studmaintenanceapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudmaintenanceapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudmaintenanceapplicationApplication.class, args);
	}

}
