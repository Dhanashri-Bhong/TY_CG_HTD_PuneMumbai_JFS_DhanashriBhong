package com.capgemini.studmaintenanceapplication.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;


@JsonRootName("studentInfo")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name="studentinfo")
@JsonPropertyOrder({"employeeId","name"})
public class StudentBean {
	
	@Id
	@Column
	@XmlElement
     private int sid;
	
	@Column
	@XmlElement
	private String sname;
	
	@Column	
	@XmlElement
    private String email;
	
	@XmlElement(name="1yearmark")
    @Column(name="1yearmark")
	private int firstyearmark;
	
	@XmlElement(name="2yearmark")
    @Column(name="2yearmark")
	private int secondyearmark;
	
	@XmlElement(name="3yearmark")
     @Column(name="3yearmark")
	private int thirdyearmark;
	
	//getters and setters
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getFirstyearmark() {
		return firstyearmark;
	}
	public void setFirstyearmark(int firstyearmark) {
		this.firstyearmark = firstyearmark;
	}
	public int getSecondyearmark() {
		return secondyearmark;
	}
	public void setSecondyearmark(int secondyearmark) {
		this.secondyearmark = secondyearmark;
	}
	public int getThirdyearmark() {
		return thirdyearmark;
	}
	public void setThirdyearmark(int thirdyearmark) {
		this.thirdyearmark = thirdyearmark;
	}
	

	

}
