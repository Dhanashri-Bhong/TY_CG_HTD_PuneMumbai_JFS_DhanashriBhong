package com.capgemini.studmaintenanceapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.studmaintenanceapplication.bean.GradeBean;
import com.capgemini.studmaintenanceapplication.bean.StudentBean;
import com.capgemini.studmaintenanceapplication.bean.StudentResponse;
import com.capgemini.studmaintenanceapplication.service.StudentService;

@RestController
public class StudentController {

	
	@Autowired
	private StudentService service;

	@GetMapping("/searchStudent")
	public StudentResponse searchStudent(int sid) {

		StudentBean sb = service.searchStudent(sid);

		StudentResponse response = new StudentResponse();
		
		if(sb != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Student Found successfully");
			response.setSb(sb);
			
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to get Student record...");

		}
		return response; 
  }// end of search()
	
	@PutMapping(path="/addStudent" , consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public StudentResponse addStudent(@RequestBody StudentBean student) {

		boolean isAdd= service.addStudent(student);
		StudentResponse response = new StudentResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Student added successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to add Student record...");
		}
		return response;

	}// end of addStudent()

	@DeleteMapping(path="/deleteStudent/{studentId}",  
	produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public StudentResponse deleteStudent( @PathVariable("studentId") int sid) {

		boolean isDeleted= service.deleteStudent(sid);
		StudentResponse response = new StudentResponse();
		
		if(isDeleted) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Student deleted successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to delete Student record...");
		}
		return response;

	}// end of delete

	@PostMapping(path="/updateStudent", consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public StudentResponse updateStudent(@RequestBody StudentBean student) {

		boolean isUpdated= service.updateStudent(student);
		StudentResponse response = new StudentResponse();
		
		if(isUpdated) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Student updated successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to update Student record...");
		}
		return response;

	}// end of update
	
	@GetMapping(path="/getAll" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public StudentResponse getAllStudents(){
		List<StudentBean> sbList =  service.getAllStudents();

		StudentResponse response = new StudentResponse();
       
		if(sbList != null && !sbList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Student record found...");
			response.setSbList(sbList);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find student record...");

		}
		return response;

	}//end of see all
	
	@GetMapping("/searchResult")
	public StudentResponse aggregate(GradeBean grade) {

		GradeBean grade1 = service.aggregate(grade);

		StudentResponse response = new StudentResponse();
		
		if(grade1 != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Grade Found successfully");
			
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to get Grade ...");

		}
		return response; 
  }// end of search()
	
	
	
}
