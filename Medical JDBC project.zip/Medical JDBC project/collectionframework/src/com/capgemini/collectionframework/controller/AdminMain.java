package com.capgemini.collectionframework.controller;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.collectionframework.beans.MedicineBean;
import com.capgemini.collectionframework.dao.MedicineDao;
import com.capgemini.collectionframework.dao.ValidationInterface;
import com.capgemini.collectionframework.factory.UserFactory;

public class AdminMain {

	public static void adminMain() {

		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		int id = 0;
		while (true) {
			System.out.println("Press 1 to show all the Medicines");
			System.out.println("Press 2 to Insert the Medicines");
			System.out.println("Press 3 to Update the Medicines");
			System.out.println("Press 4 to  Delete the Medicines");
			System.out.println("Press 5 to see user list");
			System.out.println("Press 6 to  Delete the User");
			System.out.println("Select 7 to see all questions ");
			System.out.println("Select 8 for send a answer to users");

			System.out.println("Select the Number and Enter :");

			String a = sc.nextLine();
			switch (a) {

			case "1": {
				ArrayList<MedicineBean> list = ms.getAllInfo();
			}
				break;
			case "2": {
				try {

					System.out.println("Give the Medicine pid: ");
					int productid = Integer.parseInt(sc.nextLine());
					if (!ms.productidValidation(productid)) {
						System.out.println("Give the Medicine  name: ");
						String medicineName = sc.nextLine();
						if (uv.nameValidation(medicineName)) {
							if (!ms.productNameValidation(medicineName)) {
								System.out.println("Give the Medicine category: ");
								String category = sc.nextLine();
								System.out.println("Give the Medicine price: ");
								double price = Double.parseDouble(sc.nextLine());
								System.out.println("Enter the quantity of the medicine");
								int quantity = Integer.parseInt(sc.nextLine());
								ms.addProducts(productid, medicineName, category, price, quantity);
								ms.getAllInfo();
								break;
							} else {
								System.err.println("Entered medicine name is already exist");
							}
						} else {
							System.err.println("Enter correct medicine name");
						}

					} else {
						System.err.println("Entered id already exist");
					}
				} catch (Exception e) {
					System.err.println("Enter digits only");
				}
			}
				break;
			case "3": {
				try {
					System.out.println(" Enter the id of the medicine which you want to update");
					int pid = Integer.parseInt(sc.nextLine());
					if (ms.productidValidation(pid)) {
						ms.modifyProducts(pid);
						ms.getAllInfo();
					} else {
						System.err.println("Entered id does not exist");
					}

				} catch (Exception e) {
					System.err.println("Enter digits only");
				}

			}
				break;
			case "4": {
				try {
					System.out.println("Enter medicine  id which you want to delete");
					int pid = Integer.parseInt(sc.nextLine());
					if (ms.productidValidation(pid)) {
						ms.deleteProducts(pid);
						ms.getAllInfo();
					} else {
						System.err.println("Entered id does not exist");
					}
				} catch (Exception e) {
					System.err.println("Enter digits only");
				}

			}
				break;
			case "5": {
				ms.getAllInfoOfUser();
			}
				break;
			case "6": {
				try {
					System.out.println("Enter user  id which you want to delete");
					int usersid = Integer.parseInt(sc.nextLine());
					if (ms.useridValidation(usersid)) {
						ms.deleteUser(usersid);
						ms.getAllInfoOfUser();
					} else {
						System.err.println("Entered id does not exist");
					}

				} catch (Exception e) {
					System.err.println("Enter digits only");
				}

			}
				break;
			case "7": {
				ms.seeQuestions();
			}
				break;
			case "8": {
				try {
					System.out.println(" Enter the id of the admin");
					int aid = Integer.parseInt(sc.nextLine());
					if (ms.adminidValidation(aid)) {
						ms.insertAnswer(aid);
					} else {
						System.err.println("Entered id does not exist");
					}

				} catch (Exception e) {
					System.err.println("Enter digits only");
				}

			}
				break;
			default: {
				System.out.println("Enter valid choice.");
			}

			}// end of admin switch
		} // end of while
	}// end of adminMain()
}
