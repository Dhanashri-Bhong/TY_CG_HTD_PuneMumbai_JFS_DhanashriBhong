package com.capgemini.collectionframework.controller;

import java.util.Scanner;

import com.capgemini.collectionframework.dao.MedicineDao;
import com.capgemini.collectionframework.dao.ValidationInterface;
import com.capgemini.collectionframework.factory.UserFactory;

public class RegistrationMain {
	
	public static void registration() {
		
		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		int id = 0;
		while(true) {
		try {
			
			System.out.println("Enter the userid: ");
			int userid = Integer.parseInt(sc.nextLine());
			System.out.println("Enter the user name: ");
			String username = sc.nextLine();
			if(uv.nameValidation(username)) {
				System.out.println("Enter the user emailId: ");
				String emailId = sc.nextLine();
				if(uv.emailValidation(emailId)) {
					System.out.println("Enter the password: ");
					String pwd = sc.nextLine();
					if(uv.passValidation(pwd)) {
						System.out.println("Enter the phone number : ");
						String phoneNumber = sc.nextLine();
						if(uv.mobileValidation(phoneNumber)) {
							ms.RegisterUsers(userid, username, emailId, pwd, phoneNumber );
							System.out.println(" You are registered Successfully.");
							 UserMain.userMain();
						} else {
							System.err.println("Enter digits only");
						}
					
					} else {
						System.err.println("enter suitable password");
					}
					
				} else {
					System.err.println("Enter valid email address");
				}
				
			} else {
				System.err.println("Enter name and surname");
			}
			
		} catch (Exception e) {
           System.err.println("Enter number only!");
		}
		
	}//end of while
		
	}//end of registration

}
