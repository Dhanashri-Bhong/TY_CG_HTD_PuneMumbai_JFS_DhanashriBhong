package com.capgemini.collectionframework.controller;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.collectionframework.beans.MedicineBean;
import com.capgemini.collectionframework.dao.MedicineDao;
import com.capgemini.collectionframework.factory.UserFactory;

public class MedicineMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		while (true) {
			System.out.println("***********Welcome To Online Medical Store************");
			System.out.println("Select A for login as Admin");
			System.out.println("Select U for User page");
			System.out.println("Select O  to see medicine List");

			String b = sc.nextLine();
			switch (b) {
			
			case "O": {
				ArrayList<MedicineBean> list = ms.getAllInfo();

			}
			break;
			case "A": {
				System.out.println("Please Login as admin...");
				System.out.println("Enter admin name to login  :");
				String adminName = sc.nextLine();
				if(ms.adminNameValidation(adminName)) {
					System.out.println("Enter password to login :");
					String password = sc.nextLine();
					int button = ms.authenticate(adminName, password);
					if (button > 0) {
						new AdminMain();
						AdminMain.adminMain();
					} else {
						System.err.println("Enter the valid credintial");
					} // end of if else
				} else {
					System.err.println("Enter correct name");
				}
				
			} // end of case A
				break;
			case "U": {

				System.out.println("Welcome to user page....");
				System.out.println("press 1 for registration ");
				System.out.println("Press 2 for login....");
				System.out.println("Press 3 to logout");
				int b1 = Integer.parseInt(sc.nextLine());
				if (b1 == 1) {
					RegistrationMain.registration();
				} else if (b1==2) {
					UserMain.userMain();
				} else {
					System.exit(0);
				}

			} // end of case U
			break;
			
			default:{ 
				System.err.println("Enter valid choice.");
			}

			}// end of main switch

		} // end of while
	}// end of main()

}// end of class
