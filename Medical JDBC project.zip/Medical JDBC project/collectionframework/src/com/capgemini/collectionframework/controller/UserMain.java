package com.capgemini.collectionframework.controller;

import java.util.Scanner;
import java.util.Set;

import com.capgemini.collectionframework.beans.AdminBean;
import com.capgemini.collectionframework.beans.CartBean;
import com.capgemini.collectionframework.beans.MedicineBean;
import com.capgemini.collectionframework.beans.UserBean;
import com.capgemini.collectionframework.dao.MedicineDao;
import com.capgemini.collectionframework.dao.ValidationInterface;
import com.capgemini.collectionframework.factory.UserFactory;

public class UserMain {
	public static void userMain() {

		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		int id = 0;
		while (true) {
			System.out.println("Please Login as user...");
			System.out.println("Enter emailId to login  :");
			String emailId = sc.nextLine();
			System.out.println("Enter password to login :");
			String pwd = sc.nextLine();
			id = ms.loginAsUser(emailId, pwd);
			if (id > 0) {
				System.out.println("Logged in successfully.");
				System.out.println("Welcome to online Medical Store ");
				ms.getAllInfo();

				while (true) {
					System.out.println("Select 1 to add to card");
					System.out.println("Select 2 to check history of cart");
					System.out.println("Select 3 to delete a order");
					System.out.println("Select 4 to buy a medicine");
					System.out.println("Select 5 to payment ");
					System.out.println("Select 6 to change profile");
					System.out.println("Select 7 to send a question to Administrator");
					System.out.println("Select 8 to see all replays ");
					System.out.println("Select 9 to see cart");
					System.out.println("Please enter your choice");

					String c = sc.nextLine();
					switch (c) {

					case "1": {
						int userid = id;
						ms.addToCart(userid);
					}
						break;
					case "2": {
						int userid = id;
						ms.seeAddToCart(userid);
					}
						break;
					case "3": {
						int userid = id;
						ms.delete(userid);
					}
						break;
					case "4": {
						int userid = id;
						ms.buyMedicine(userid);
					}
						break;
					case "5": {
						int userid = id;
						ms.payment(userid);
					}
						break;
					case "6": {
						try {
							System.out.println(" Enter the id of the user which you want to update");
							int userid = Integer.parseInt(sc.nextLine());
							if (ms.useridValidation(userid)) {
								ms.modifyUser(userid);
							} else {
								System.err.println("Entered id does not exist");
							}

						} catch (Exception e) {
							System.err.println("Enter digits only");
						}

					}
						break;

					case "7": {
						int userid = id;
						ms.insertQuestion(userid);
					}
						break;
					case "8": {
						ms.seeAnswers();
					}
						break;
					case "9": {
						try {
							System.out.println("Enter a user id");
							int userid = Integer.parseInt(sc.nextLine());
							if (ms.useridValidation(userid)) {
								ms.seeAddToCart(userid);
							} else {
								System.err.println("Entered id does not exist");
							}

						} catch (Exception e) {
							System.err.println("Enter digits only");
						}

					}
						break;
					default: {
						System.out.println("Enter valid choice.");
					}
					}// end of switch
				} // end of while

			} else {
				System.out.println("Please enter valid username and password.");
			}
		} // end of while
	}// userMain()
}// end of class
