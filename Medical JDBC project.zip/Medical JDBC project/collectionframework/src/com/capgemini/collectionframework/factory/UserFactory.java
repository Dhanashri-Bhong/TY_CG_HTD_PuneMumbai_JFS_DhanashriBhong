package com.capgemini.collectionframework.factory;

import com.capgemini.collectionframework.dao.MedicineDao;
import com.capgemini.collectionframework.dao.MedicineDaoImpl;
import com.capgemini.collectionframework.dao.ValidationImpl;
import com.capgemini.collectionframework.dao.ValidationInterface;

public class UserFactory {
	
	private UserFactory() {
	}
	
	public static MedicineDao getDAOImplInstance() {
		MedicineDao dao = new MedicineDaoImpl();
		return dao;
	}
	
	
	public static ValidationInterface getValidationInstance() {
		ValidationInterface validation = new ValidationImpl();
		return validation;
	}
}
