package com.capgemini.collectionframework.beans;

public class OrderMedicineBean {
	
	private int orderid;
	private int cardid;
	private int userid;
	private String medicineName;
	private int quantity;
	private double price;
	
	//constructor
	public OrderMedicineBean(int orderId, int cardid, int userid, String medicineName,double price, int quantity) {
		super();
		this.orderid = orderid;
		this.cardid = cardid;
		this.userid = userid;
		this.medicineName = medicineName;
		this.quantity = quantity;
		this.price = price;
	}//end of constructor

	//getters and setters
	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getCardid() {
		return cardid;
	}

	public void setCardid(int cardid) {
		this.cardid = cardid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
}//end of class
