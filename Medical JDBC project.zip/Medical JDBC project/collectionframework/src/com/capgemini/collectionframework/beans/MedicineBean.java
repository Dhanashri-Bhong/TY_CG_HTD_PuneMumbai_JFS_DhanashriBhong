package com.capgemini.collectionframework.beans;

public class MedicineBean {
	
	private int productid;
	private String medicineName;
	private String category;
	private double price;
	private int quantity;
	
	
	//getters and setters
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	//constructor
	public MedicineBean(int productid, String medicineName, String category, double price , int quantity) {
		super();
		this.productid = productid;
		this.medicineName = medicineName;
		this.category = category;
		this.price = price;
		this.quantity= quantity;
	}//end of constructor
	
	

}//end of class
