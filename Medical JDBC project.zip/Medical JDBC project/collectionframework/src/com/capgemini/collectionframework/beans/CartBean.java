package com.capgemini.collectionframework.beans;


public class CartBean {
	
	private int cartid;
	private int userid;
	private int productid;
	private String username;
	private String medicineName;
	private double price;
	private int quantity;
	
	//getters and setters
	public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	//constructor
	public CartBean(int cartid, int userid, int productid, String username, String medicineName, double price , int quantity) {
		super();
		this.cartid = cartid;
		this.userid = userid;
		this.productid = productid;
		this.username = username;
		this.medicineName = medicineName;
		this.price = price;
		this.quantity = quantity;
	} //end of constructor
	
	
	

}
