package com.capgemini.collectionframework.beans;


public class AdminMsgBean {
	
	private int ansid;
	private int userid;
	private String username;
	private String msgreplay;
	
	//getters and setters
	public int getAnsid() {
		return ansid;
	}
	public void setAnsid(int ansid) {
		this.ansid = ansid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMsgreplay() {
		return msgreplay;
	}
	public void setMsgreplay(String msgreplay) {
		this.msgreplay = msgreplay;
	}
	public AdminMsgBean(int ansid, int userid, String username, String msgreplay) {
		super();
		this.ansid = ansid;
		this.userid = userid;
		this.username = username;
		this.msgreplay = msgreplay;
	} 
	
	

}
