package com.capgemini.collectionframework.beans;


public class AdminBean {
	
	private int adminid;
	private String adminName;
	private String email;
	private String password;
	private String mobileNumber;
	
	//getters and setters
	public int getAdminid() {
		return adminid;
	}
	public void setAdminid(int adminid) {
		this.adminid = adminid;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	//constructor
	public AdminBean(int adminid, String adminName, String email, String password, String mobileNumber) {
		super();
		this.adminid = adminid;
		this.adminName = adminName;
		this.email = email;
		this.password = password;
		this.mobileNumber = mobileNumber;
	}//end of constructor
	
	

}//end of class
