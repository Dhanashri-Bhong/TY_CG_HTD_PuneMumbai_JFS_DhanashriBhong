package com.capgemini.collectionframework.beans;

public class UserMsgBean {

		private int msgid;
		private int userid;
		private String username;
		private String question;
		
		//getters and setters
		public int getMsgid() {
			return msgid;
		}
		public void setMsgid(int msgid) {
			this.msgid = msgid;
		}
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getQuestion() {
			return question;
		}
		public void setQuestion(String question) {
			this.question = question;
		}
		
		//constructor
		public UserMsgBean(int msgid, int userid, String username, String question) {
			super();
			this.msgid = msgid;
			this.userid = userid;
			this.username = username;
			this.question = question;
		}//end of constructor
		
	

}//end of class
