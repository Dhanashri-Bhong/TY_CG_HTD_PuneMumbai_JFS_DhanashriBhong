package com.capgemini.collectionframework.beans;

public class UserBean {
	
	private int userid;
	private String username;
	private String emailId;
	private String pwd;
	private String phoneNumber;
	
	
	//getters and setters
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	//constructor
	public UserBean(int userid, String username, String emailId, String pwd, String phoneNumber) {
		super();
		this.userid = userid;
		this.username = username;
		this.emailId = emailId;
		this.pwd = pwd;
		this.phoneNumber = phoneNumber;
	}//end of constructor
	

}//end of class
