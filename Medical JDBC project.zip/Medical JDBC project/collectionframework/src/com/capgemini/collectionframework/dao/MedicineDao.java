package com.capgemini.collectionframework.dao;

import java.util.ArrayList;
import java.util.Set;

import com.capgemini.collectionframework.beans.AdminMsgBean;
import com.capgemini.collectionframework.beans.CartBean;
import com.capgemini.collectionframework.beans.MedicineBean;
import com.capgemini.collectionframework.beans.UserBean;
import com.capgemini.collectionframework.beans.UserMsgBean;

public interface MedicineDao {

	
	public int authenticate(String adminName, String password) ;
	public ArrayList<MedicineBean> getAllInfo();
	public MedicineBean addProducts(int productid, String medicineName, String category , double price , int quantity);
	public void modifyProducts (int productid);
	public void deleteProducts (int productid);
	public Set<UserBean> getAllInfoOfUser();
	public void deleteUser (int usersid);
	public void insertAnswer(int adminid );
	public ArrayList<UserMsgBean> seeQuestions();

	
	//user methods
	public void RegisterUsers(int userid ,String username, String emailId,String phoneNumber, String pwd);
    public int loginAsUser(String emailId , String pwd);
    public void addToCart(int userid);
    public ArrayList<CartBean> getCartInfo();
	public CartBean delete(int userid);
	public void buyMedicine(int userid);
	public double payment(int userid);
	public void modifyUser (int userid);
	public void insertQuestion(int userid );
	public ArrayList<AdminMsgBean> seeAnswers();
	public void seeAddToCart(int userid);
	
	
	public boolean useridValidation(int userid);
	public boolean cartiddValidation(int cartid);
	public boolean adminidValidation(int adminid);
	public boolean productidValidation(int productid);
	public boolean productNameValidation(String medicineName);
	public boolean orderiddValidation(int orderid);
	public boolean quantitydValidation(int quantity);
	public boolean adminNameValidation(String adminName);

}
