package com.capgemini.collectionframework.dao;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationImpl implements ValidationInterface {

	Pattern pat = null;
	Matcher mat = null;

	@Override
	public boolean idValidation(String userid) {

		pat = Pattern.compile("\\d{1,10}");
		mat = pat.matcher(userid);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean mobileValidation(String mobile) {

		pat = Pattern.compile("\\d{10}");
		mat = pat.matcher(mobile);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean nameValidation(String name) {

		pat = Pattern.compile("\\w+\\s\\w+");
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean emailValidation(String email) {

		pat = Pattern.compile("\\w+\\@\\w+\\.\\w+");
		mat = pat.matcher(email);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean passValidation(String pass) {

		pat = Pattern.compile("\\w+");
		mat = pat.matcher(pass);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

}
