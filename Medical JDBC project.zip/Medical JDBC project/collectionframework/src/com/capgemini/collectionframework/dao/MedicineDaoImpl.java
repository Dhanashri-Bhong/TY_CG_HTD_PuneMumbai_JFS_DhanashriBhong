package com.capgemini.collectionframework.dao;

import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.collectionframework.beans.AdminBean;
import com.capgemini.collectionframework.beans.AdminMsgBean;
import com.capgemini.collectionframework.beans.CartBean;
import com.capgemini.collectionframework.beans.MedicineBean;
import com.capgemini.collectionframework.beans.OrderMedicineBean;
import com.capgemini.collectionframework.beans.UserBean;
import com.capgemini.collectionframework.beans.UserMsgBean;
import com.capgemini.collectionframework.factory.UserFactory;

public class MedicineDaoImpl implements MedicineDao {
	Scanner sc = new Scanner(System.in);
	// medicine
	ValidationInterface uv = UserFactory.getValidationInstance();

	static ArrayList<MedicineBean> mList = new ArrayList<MedicineBean>();
	static ArrayList<AdminMsgBean> adminMsgList = new ArrayList<AdminMsgBean>();
	static ArrayList<UserMsgBean> userMsgList = new ArrayList<UserMsgBean>();

	static {
		MedicineBean m1 = new MedicineBean(101, "chrocine", "health care", 50, 10);
		MedicineBean m2 = new MedicineBean(102, "nice", "health care", 60, 5);
		MedicineBean m3 = new MedicineBean(103, "paracetamol", "health care", 70, 8);
		MedicineBean m4 = new MedicineBean(104, "meta plus", "health care", 80, 12);
		mList.add(m1);
		mList.add(m2);
		mList.add(m3);
		mList.add(m4);
		AdminMsgBean ans1 = new AdminMsgBean(1, 1001, "vaibhav", "out of stock");
		AdminMsgBean ans2 = new AdminMsgBean(2, 1002, "gayatri", "no discount");
		adminMsgList.add(ans1);
		adminMsgList.add(ans2);

		UserMsgBean que1 = new UserMsgBean(1, 1001, "vaibhav", "Sir do you have chrocine tablet ?");
		UserMsgBean que2 = new UserMsgBean(1, 1001, "vaibhav", "Is there any discount?");
		userMsgList.add(que1);
		userMsgList.add(que2);

	}

	static AdminBean admin = null;
	static UserBean user = null;
	public static ArrayList<AdminBean> adminList = new ArrayList<AdminBean>();
	static ArrayList<UserBean> userList = new ArrayList<UserBean>();
	public static ArrayList<CartBean> cartList = new ArrayList<CartBean>();
	public static ArrayList<OrderMedicineBean> orderList = new ArrayList<OrderMedicineBean>();

	// user , admin and cart
	static {
		admin = new AdminBean(1, "dhanashri", "dhanu@gmail.com", "admin", "7887669198");
		adminList.add(admin);

		UserBean user1 = new UserBean(1001, "vaibhav", "v@gmail.com", "vaibhav", "9922120326");
		UserBean user2 = new UserBean(1002, "gayatri", "g@gmail.com", "vaibhav", "7887669198");
		UserBean user3 = new UserBean(1003, "simran", "s@gmail.com", "vaibhav", "9359467646");
		UserBean user4 = new UserBean(1004, "shital", "shi@gmail.com", "vaibhav", "9172029365");
		userList.add(user1);
		userList.add(user2);
		userList.add(user3);
		userList.add(user4);

		CartBean cartBean1 = new CartBean(1, 1001, 101, "vaibhav", "chrocine", 20, 10);
		CartBean cartBean2 = new CartBean(2, 1002, 102, "gayatri", "nice", 100, 2);
		CartBean cartBean3 = new CartBean(3, 1003, 103, "simran", "paracetamol", 50, 50);
		CartBean cartBean4 = new CartBean(4, 1004, 104, "shital", "meta plus", 5, 1);
		cartList.add(cartBean1);
		cartList.add(cartBean2);
		cartList.add(cartBean3);
		cartList.add(cartBean4);

		OrderMedicineBean order1 = new OrderMedicineBean(1, 1, 1001, "meta plus", 5, 2);
		OrderMedicineBean order2 = new OrderMedicineBean(2, 2, 1001, "nice", 5, 2);

		orderList.add(order1);
		orderList.add(order2);

	}

	@Override
	public int authenticate(String adminName, String password) {
		int adminid = 0;
		if (adminName.equals(admin.getAdminName())) {
			if (password.equals(admin.getPassword())) {
				System.out.println("Admin Logged in successfully.");
				adminid = admin.getAdminid();
			} else {
				System.err.println("Enter valid  password");
				return 0;
			}

		} else {
			System.err.println("Enter valid name ");
		}

		return adminid;
	}

	@Override
	public ArrayList<MedicineBean> getAllInfo() {

		for (MedicineBean list : mList) {
			System.out.println("Id is " + list.getProductid());
			System.out.println("Category is  " + list.getCategory());
			System.out.println("Medicine Name " + list.getMedicineName());
			System.out.println("price is " + list.getPrice());
			System.out.println("Quantity is : " + list.getQuantity());
			System.out.println("----------------------------------------");
		}
		return null;
	}

	@Override
	public MedicineBean addProducts(int productid, String medicineName, String category, double price, int quantity) {

		MedicineBean medicineBean = null;

		medicineBean = new MedicineBean(productid, medicineName, category, price, quantity);
		mList.add(medicineBean);
		System.out.println("Medicine inserted successfully.");
		return medicineBean;
	}

	@Override
	public void modifyProducts(int pid) {
		try {

			System.out.println(" Enter the medicine id which you want to update");
			int medicineId = Integer.parseInt(sc.nextLine());
			MedicineBean medicineBean = null;
			for (MedicineBean list : mList) {
				if (list.getProductid() == medicineId) {
					medicineBean = list;
				}
			}
			if (medicineBean != null) {
				System.out.println("Give the Medicine  name: ");
				String medicineName = sc.nextLine();
				if (!productNameValidation(medicineName)) {

					System.out.println("Give the Medicine category: ");
					String category = sc.nextLine();
					System.out.println("Give the Medicine price: ");
					double price = Double.parseDouble(sc.nextLine());
					System.out.println("Enter the quantity of the medicine");
					int quantity = Integer.parseInt(sc.nextLine());

					medicineBean.setMedicineName(medicineName);
					medicineBean.setCategory(category);
					medicineBean.setPrice(price);
					medicineBean.setQuantity(quantity);
					System.out.println("Medicine updated successfully.");

				} else {
					System.err.println("Medicine name is already exist");
				}

			} else {
				System.err.println("Enter medicine id is not present");
			}

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public void deleteProducts(int pid) {
		try {

			System.out.println(" Enter the medicine id which you want to update");
			int medicineId = Integer.parseInt(sc.nextLine());
			MedicineBean medicineBean = null;
			for (MedicineBean list : mList) {
				if (list.getProductid() == medicineId) {
					medicineBean = list;
				}
			}
			if (medicineBean != null) {
				mList.remove(medicineBean);
				System.out.println("medicine deleted successfully.");
			} else {
				System.err.println("Enter medicine id is not present");
			}

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public Set<UserBean> getAllInfoOfUser() {
		for (UserBean list : userList) {
			System.out.println("Id is " + list.getUserid());
			System.out.println("username is  " + list.getUsername());
			System.out.println("password " + list.getPwd());
			System.out.println("Phone Number is " + list.getPhoneNumber());
			System.out.println("----------------------------------------");
		}
		return null;
	}

	@Override
	public void deleteUser(int usersid) {
		try {

			System.out.println(" Enter the user id which you want to update");
			int userid = Integer.parseInt(sc.nextLine());
			UserBean userBean = null;
			for (UserBean list : userList) {
				if (list.getUserid() == userid) {
					userBean = list;
				}
			}
			if (userBean != null) {
				userList.remove(userBean);
				System.out.println("user deleted successfully.");
			} else {
				System.out.println("Given user id is not present");
			}

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public void RegisterUsers(int userid, String username, String emailId, String pwd, String phoneNumber) {
		UserBean userBean = new UserBean(userid, username, emailId, pwd, phoneNumber);
		userList.add(userBean);
		// System.out.println("You are registered successfully.");
	}

	@Override
	public int loginAsUser(String emailId, String pwd) {
		int id = 0;
		for (UserBean bean : userList) {
			if (emailId.equals(bean.getEmailId())) {
				if (pwd.equals(bean.getPwd())) {
					System.out.println("User Logged in successfully.");
					id = bean.getUserid();

				} else {
					System.err.println("Enter valid  password");
					return 0;
				}

			} else {
				System.err.println("Please Enter valid emailId.");
			}
		}
		return id;
	}

	@Override
	public void modifyUser(int userid) {

		try {
			System.out.println(" Enter the user id which you want to update");
			int userid1 = Integer.parseInt(sc.nextLine());
			UserBean userBean = null;
			for (UserBean list : userList) {
				if (list.getUserid() == userid1) {
					userBean = list;
				}
			}
			if (userBean != null) {
				System.out.println("Give the user  name: ");
				String username = sc.nextLine();
				System.out.println("Give the user email Id: ");
				String emailId = sc.nextLine();
				if (uv.emailValidation(emailId)) {
					System.out.println("Give the user password: ");
					String pwd = sc.nextLine();
					if (uv.passValidation(pwd)) {

						System.out.println("Give the user phone number: ");
						String phoneNumber = sc.nextLine();
						if (uv.mobileValidation(phoneNumber)) {

							userBean.setUsername(username);
							userBean.setEmailId(emailId);
							userBean.setPwd(pwd);
							userBean.setPhoneNumber(phoneNumber);

							System.out.println("User updated successfully.");
						} else {
							System.err.println("Enter digits only!");
						}

					} else {
						System.err.println("Enter valid password");
					}

				} else {
					System.err.println("Enter correct email ID");
				}

			} else {
				System.out.println("Enter user id is not present");
			}

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public ArrayList<CartBean> getCartInfo() {

		for (CartBean list : cartList) {
			System.out.println(" Medicine Id is " + list.getProductid());
			System.out.println("Cart id is :" + list.getCartid());
			System.out.println("Userid is :" + list.getUserid());
			System.out.println("UserName is  " + list.getUsername());
			System.out.println("Medicine Name :" + list.getMedicineName());
			System.out.println("price is " + list.getPrice());
			System.out.println("Quantity is : " + list.getQuantity());
			System.out.println("----------------------------------------");
		}
		return null;
	}

	@Override
	public void addToCart(int userid) {

		try {

			System.out.println("How many medicine you want to add");
			int count = Integer.parseUnsignedInt(sc.nextLine());

			for (int i = 1; i <= count; i++) {

				System.out.println("Enter medicine name ");
				String medicineName = sc.nextLine();
				if (productNameValidation(medicineName)) {
					System.out.println("Enter quantity of medicine");
					int quantity = Integer.parseInt(sc.nextLine());
					System.out.println("Enter Username ");
					String username = sc.nextLine();
					System.out.println("Enter the cart id");
					int cartid = Integer.parseInt(sc.nextLine());
					if (cartiddValidation(cartid)) {
						MedicineBean medicineBean = null;

						for (MedicineBean list : mList) {
							if (list.getMedicineName().equals(medicineName)) {
								medicineBean = list;
							}
						}
						int productid = medicineBean.getProductid();
						double price = medicineBean.getPrice();
						if (medicineBean != null) {
							CartBean cartBean = new CartBean(cartid, userid, productid, username, medicineName, price,
									quantity);
							cartList.add(cartBean);
							System.out.println("Medicine inserted successfully.");
						}
					} else {
						System.err.println("Cart id does not exist");
					}

				} else {
					System.err.println("Entered medicine name does not exist");
				}
			} // end of for

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public CartBean delete(int userid) {
		System.out.println(" Enter the Medicine name which you want to delete");
		String medicineName1 = sc.nextLine();
		if (productNameValidation(medicineName1)) {

			CartBean cartBean = null;
			for (CartBean list : cartList) {
				if (list.getMedicineName().equals(medicineName1)) {
					cartBean = list;
				}
			}
			if (cartBean != null) {
				cartList.remove(cartBean);
				System.out.println("Medicine deleted successfully.");
			} else {
				System.err.println("Given medicine name is not present");
			}

		} else {
			System.err.println("Entered medicine name does not exist");
		}

		return null;
	}

	@Override
	public void buyMedicine(int userid) {
		try {

			System.out.println("Enter how many medicine you want to buy");
			int count = Integer.parseInt(sc.nextLine());
			for (int i = 1; i <= count; i++) {
				System.out.println("Enter the cartid ");
				int cardid = Integer.parseInt(sc.nextLine());
				if (cartiddValidation(cardid)) {

					System.out.println("Enter order id");
					int orderid = Integer.parseInt(sc.nextLine());

					if (orderiddValidation(orderid)) {
						System.out.println("Enter the quantity of the medicine");
						int quantity = Integer.parseInt(sc.nextLine());
						if (quantitydValidation(quantity)) {
							CartBean cartBean = null;
							for (CartBean list : cartList) {
								if (cardid == list.getCartid() && userid == list.getUserid()) {
									cartBean = list;
									OrderMedicineBean orderBean = new OrderMedicineBean(orderid, cardid, userid,
											cartBean.getMedicineName(), cartBean.getPrice(), quantity);
									orderList.add(orderBean);
									System.out.println("Your order is confirmed");
								}
							}
						} else {
							System.err.println("Sorry quantity is less");
						}

					} else {
						System.err.println("order id does not exist");
					}

				} else {
					System.err.println("Entered cartid is wrong");
				}

			} // end of for loop

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public void insertQuestion(int aid) {
		try {

			System.out.println("Enter the number of question do you have?");
			int count = Integer.parseInt(sc.nextLine());
			for (int i = 1; i <= count; i++) {

				System.out.println("Enter the user name ");
				String username = sc.nextLine();

				System.out.println("Enter the question");
				String question = sc.nextLine();

				System.out.println("Enter msg id");
				int msgid = Integer.parseInt(sc.nextLine());

				UserBean userBean = null;

				for (UserBean list : userList) {
					if (list.getUsername().equals(username)) {
						userBean = list;
					}
				}
				int userid1 = userBean.getUserid();
				if (userBean != null) {
					UserMsgBean userMsgBean = new UserMsgBean(msgid, userid1, username, question);
					userMsgList.add(userMsgBean);
					System.out.println("question inserted successfully.");
				}

			} // end of for

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public ArrayList<UserMsgBean> seeQuestions() {
		for (UserMsgBean list : userMsgList) {
			System.out.println("Id is " + list.getMsgid());
			System.out.println("User id is  " + list.getUserid());
			System.out.println("User Name " + list.getUsername());
			System.out.println("Question is " + list.getQuestion());
			System.out.println("----------------------------------------");
		}
		return null;

	}

	@Override
	public void insertAnswer(int userid) {

		try {

			System.out.println("how many replays do you want to give to users");
			int count = Integer.parseInt(sc.nextLine());
			for (int i = 1; i <= count; i++) {

				System.out.println("Enter the user name ");
				String username = sc.nextLine();

				System.out.println("Enter the Answer");
				String msgreplay = sc.nextLine();

				System.out.println("Enter answer id");
				int ansid = Integer.parseInt(sc.nextLine());

				UserBean userBean = null;

				for (UserBean list : userList) {
					if (list.getUsername().equals(username)) {
						userBean = list;
					}
				}
				int userid1 = userBean.getUserid();
				if (userBean != null) {
					AdminMsgBean adminMsgBean = new AdminMsgBean(ansid, userid1, username, msgreplay);
					adminMsgList.add(adminMsgBean);
					System.out.println("Answer inserted successfully.");
				}

			} // end of for

		} catch (Exception e) {
			System.err.println("Enter digits only");
		}

	}

	@Override
	public ArrayList<AdminMsgBean> seeAnswers() {

		for (AdminMsgBean list : adminMsgList) {
			System.out.println("Id is " + list.getAnsid());
			System.out.println("User id is  " + list.getUserid());
			System.out.println("User Name " + list.getUsername());
			System.out.println("Answer is " + list.getMsgreplay());
			System.out.println("----------------------------------------");
		}
		return null;
	}

	@Override
	public void seeAddToCart(int userid) {

		CartBean cartBean = null;
		for (CartBean list : cartList) {
			if (userid == list.getUserid()) {
				cartBean = list;
			}
		}
		if (cartBean != null) {

			System.out.println(" Medicine Id is " + cartBean.getProductid());
			System.out.println("Cart id is :" + cartBean.getCartid());
			System.out.println("Userid is :" + cartBean.getUserid());
			System.out.println("UserName is  " + cartBean.getUsername());
			System.out.println("Medicine Name :" + cartBean.getMedicineName());
			System.out.println("price is " + cartBean.getPrice());
			System.out.println("Quantity is : " + cartBean.getQuantity());
			System.out.println("----------------------------------------");
		}

	}

	static ArrayList<OrderMedicineBean> list1 = null;

	@Override
	public double payment(int userid) {
		list1 = new ArrayList<OrderMedicineBean>();
		for (OrderMedicineBean list : orderList) {

			if (userid == list.getUserid()) {
				list1.add(list);
			}
		} // end of for loop

		double totalBill = 0;
		if (!list1.isEmpty()) {
			for (OrderMedicineBean infoList : orderList) {
				System.out.println("order id is :" + infoList.getOrderid());
				System.out.println("Cart id is :" + infoList.getCardid());
				System.out.println("Medicine Name is :" + infoList.getMedicineName());
				double price = infoList.getPrice();
				System.out.println("Price is : " + price);
				int quantity = infoList.getQuantity();
				System.out.println("Quantity is :" + quantity);
				double bill = price * quantity;
				totalBill = totalBill + bill;
				System.out.println("------------------------------------");
			}
			System.out.println(" Your Bill is :" + totalBill);
			return totalBill;
		} else {
			System.out.println("Your order list is empty.");
		}
		return totalBill;

	}

	@Override
	public boolean useridValidation(int userid) {
		UserBean userBean = null;
		boolean isValid = false;
		for (UserBean user : userList) {
			if (user.getUserid() == userid) {
				isValid = true;
			}
		}
		

		return isValid;
	}

	@Override
	public boolean cartiddValidation(int cartid) {

		CartBean cartBean = null;
		boolean isValid = false;
		for (CartBean cart : cartList) {
			if (cart.getCartid() == cartid) {
				isValid = true;
			}
		}
		
		return isValid;
	}

	@Override
	public boolean adminidValidation(int adminid) {

		AdminBean adminBean = null;
		boolean isValid = false;
		for (AdminBean admin : adminList) {
			if (admin.getAdminid() == adminid) {
				isValid = true;
			}
		}
		

		return isValid;
	}
	
	
	@Override
	public boolean adminNameValidation(String adminName) {

		AdminBean adminBean = null;
		boolean isValid = false;
		for (AdminBean admin : adminList) {
			if (admin.getAdminName().equals(adminName)) {
				isValid = true;
			}
		}
		

		return isValid;
	}

	@Override
	public boolean productidValidation(int productid) {

		boolean isValid = false;
		for (MedicineBean medicine : mList) {
			if (medicine.getProductid() == productid) {
				isValid = true;

			}
		}
		return isValid;
	}

	@Override
	public boolean productNameValidation(String medicineName) {

		boolean isValid = false;
		for (MedicineBean medicine : mList) {
			if (medicine.getMedicineName().equals(medicineName)) {
				isValid = true;
			}
		}
		

		return isValid;
	}

	@Override
	public boolean orderiddValidation(int orderid) {

		boolean isValid = false;
		for (OrderMedicineBean order : orderList) {
			if (order.getOrderid() == orderid) {
				isValid = true;
			}
		}
		

		return isValid;

	}

	@Override
	public boolean quantitydValidation(int quantity) {

		boolean isValid = false;
		for (MedicineBean medicine : mList) {
			if (medicine.getQuantity() == quantity) {
				isValid = true;
			}
		}
		

		return isValid;
	}

}// end of class
