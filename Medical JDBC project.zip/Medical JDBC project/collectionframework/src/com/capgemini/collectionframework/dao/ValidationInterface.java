package com.capgemini.collectionframework.dao;

public interface ValidationInterface {

	public boolean idValidation(String userid);
	public boolean nameValidation(String name);
	public boolean emailValidation(String email);
	public boolean passValidation(String pass);
	public boolean mobileValidation(String mobile);

}
