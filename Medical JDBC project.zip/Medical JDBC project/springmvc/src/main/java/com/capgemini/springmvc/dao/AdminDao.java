package com.capgemini.springmvc.dao;

import java.util.List;

import com.capgemini.springmvc.beans.AdminBean;
import com.capgemini.springmvc.beans.AdminMsgBean;
import com.capgemini.springmvc.beans.CartBean;
import com.capgemini.springmvc.beans.MedicineBean;
import com.capgemini.springmvc.beans.UserBean;
import com.capgemini.springmvc.beans.UserMsgBean;

public interface AdminDao {

	
	public  UserBean getUser(int userid);
	public AdminBean authenticate(int aid , String password);
	public boolean addProduct(MedicineBean medicine);
	public boolean updateProduct(MedicineBean medicine);
	public boolean deleteProduct(int pid);
	public List<MedicineBean> getAllProducts();
	public List<UserBean> getUserList();
	public boolean deleteUser(int userid);
	public boolean updateAdmin(AdminBean admin);
	public int authenticateUser(String emailId, String pwd);
	public boolean register(UserBean user);
	
	public boolean addToCart( int userid , String medicineName);
	public boolean delete(int cartid);
	public double payment(int userid);
	public boolean updateUser(UserBean user);
	public List<UserMsgBean> getQuestions();
	public List<AdminMsgBean> getAnswer();
	public boolean viewQuestions(int userid , String question);
	public boolean viewAnswers(int userid , String msgreplay);

   

}
