package com.capgemini.springmvc.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cart")
public class CartBean {
	
	@Id
	@Column
	private int cartid;
	
	@Column
	private int userid;
	
	@Column
	private int pid;
	
	@Column
	private String username;
	
	@Column
	private String medicineName;
	
	@Column
	private double price;
	
	@Column
	private int quantity;
	
	
	//getters and setters
	public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuntity() {
		return quantity;
	}
	public void setQuntity(int quntity) {
		this.quantity = quantity;
	}
	

}
