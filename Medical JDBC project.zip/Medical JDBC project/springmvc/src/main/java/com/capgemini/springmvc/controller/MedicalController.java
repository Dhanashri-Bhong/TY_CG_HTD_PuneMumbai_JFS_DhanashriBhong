package com.capgemini.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.springmvc.beans.AdminBean;
import com.capgemini.springmvc.beans.AdminMsgBean;
import com.capgemini.springmvc.beans.CartBean;
import com.capgemini.springmvc.beans.MedicineBean;
import com.capgemini.springmvc.beans.UserBean;
import com.capgemini.springmvc.beans.UserMsgBean;
import com.capgemini.springmvc.service.AdminService;

@Controller
public class MedicalController {

	@Autowired
	private AdminService service;

	@RequestMapping(path = "/home", method = RequestMethod.GET)
	public ModelAndView display() {
		ModelAndView modelAndView = new ModelAndView();
		// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
		modelAndView.setViewName("home");

		return modelAndView;
	}// end of display()

	@RequestMapping(path = "/adminLogin", method = RequestMethod.GET)
	public ModelAndView display1() {
		ModelAndView modelAndView = new ModelAndView();
		// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
		modelAndView.setViewName("adminLogin");

		return modelAndView;
	}// end of display()

	@PostMapping("/adminLoginForm")
	public String adminLogin(int aid, String password, ModelMap modelMap, HttpServletRequest req) {

		AdminBean admin = service.authenticate(aid, password);
		if (admin != null) { // valid credential
			HttpSession session = req.getSession(true);
			session.setAttribute("admin", admin);

			return "adminHomePage";
		} else { // invalid credential
			modelMap.addAttribute("msg", "Iinvalid credential");
			return "adminLogin";
		}
	}// end of empLogin

	@GetMapping("/productInsert")
	public String displayAddProduct(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first.....");
			return "adminLogin";
		} else {
			return "productInsert";
		}
	}// end of addProduct()

	@PostMapping("/productInsertForm")
	public String addProduct(MedicineBean medicine, HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "adminLogin";
		} else {
			if (service.addProduct(medicine)) {
				modelMap.addAttribute("msg", "Medicine Added Successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to add Medicine");
			}
			return "productInsert";
		}

	}// end of addProduct()

	@GetMapping("/productDelete")
	public String displayDeleteProductForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			return "productDelete";
		}
	}// End of displaydeleteProductForm()

	@GetMapping("/productDeleteForm")
	public String deleteProduct(int pid, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			if (service.deleteProduct(pid)) {
				modelMap.addAttribute("msg", "Medicine Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "Medicine ID " + pid + " Not Found!");
			}

			return "productDelete";
		}
	}// End of deleteProduct()

	@GetMapping("/productUpdate")
	public String displayUpdateProductForm(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// invalid session
			modelMap.addAttribute("msg", "Please login first..");
			return "adminLogin";
		} else {
			return "productUpdate";
		}

	}// end of updatedisplay

	@PostMapping("/productUpdateForm")
	public String updateProduct(MedicineBean medicine, HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "adminLogin";
		} else {
			if (service.updateProduct(medicine)) {
				modelMap.addAttribute("msg", "Medicine updated Successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to update Medicine");
			}
			return "productUpdate";
		}

	}// end of update

	@GetMapping("/seeAllProducts")
	public String getAllProducts(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			List<MedicineBean> medicineList = service.getAllProducts();
			modelMap.addAttribute("medicineList", medicineList);

			return "allProducts";
		}
	}// End of getAllProducts()

	@GetMapping("/allProduct")
	public String displayMedicine(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			return "adminHomePage";
		}
	}// End of displayEmpHomePage()

	@GetMapping("/userList")
	public String getuserList(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			List<UserBean> userList = service.getUserList();
			modelMap.addAttribute("userList", userList);

			return "userList";
		}
	}// End of getAllProducts()

	@GetMapping("/userListForm")
	public String displayUser(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			return "adminHomePage";
		}
	}// End of displayHomePage()

	@GetMapping("/deleteUser")
	public String displayDeleteUserForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			return "deleteUser";
		}
	}// End of displaydeleteUserForm()

	@GetMapping("/deleteUserForm")
	public String deleteUser(int userid, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			if (service.deleteUser(userid)) {
				modelMap.addAttribute("msg", "User Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "User ID " + userid + " Not Found!");
			}

			return "deleteUser";
		}
	}// End of deleteP()

	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap modelMap) {
		session.invalidate();
		modelMap.addAttribute("msg", "Logged out successfully");
		return "home";
	}

	@GetMapping("/updateAdmin")
	public String displayUpdateAdminForm(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// invalid session
			modelMap.addAttribute("msg", "Please login first..");
			return "adminLogin";
		} else {
			return "updateAdmin";
		}

	}// end of updatedisplay

	@PostMapping("/updateAdminForm")
	public String updateAdmin(AdminBean admin, HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "adminLogin";
		} else {
			if (service.updateAdmin(admin)) {
				modelMap.addAttribute("msg", "Admin updated Successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to update Admin");
			}
			return "updateAdmin";
		}

	}// end of update

	////// ********************User Section*************************

    int userid = 0;

	@RequestMapping(path = "/userLogin", method = RequestMethod.GET)
	public ModelAndView displayLink() {
		ModelAndView modelAndView = new ModelAndView();
		// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
		modelAndView.setViewName("userHomePage");

		return modelAndView;
	}// end of displayLink()

	@RequestMapping(path = "/userLoginLink", method = RequestMethod.GET)
	public ModelAndView displayUserLogin() {
		ModelAndView modelAndView = new ModelAndView();
		// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
		modelAndView.setViewName("userLogin");

		return modelAndView;
	}// end of display()

	@PostMapping("/userLoginForm")
	public String userLogin(String emailId, String pwd, ModelMap modelMap, HttpServletRequest req) {

	 userid = service.authenticateUser(emailId, pwd);
		if (userid != 0) { // valid credential
			HttpSession session = req.getSession(true);
			session.setAttribute("userid", userid);

			return "userMainList";
		} else { // invalid credential
			modelMap.addAttribute("msg", "Iinvalid credential");
			return "userLogin";
		}
	}// end of empLogin

	@GetMapping("/userRegistration")
	public String displayAddUser(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first.....");
			return "userLogin";
		} else {
			return "userRegistration";
		}
	}// end of addProduct()

	@PostMapping("/userRegistrationForm")
	public String register(UserBean user, HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "userLogin";
		} else {
			if (service.register(user)) {
				modelMap.addAttribute("msg", "user Added Successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to add user");
			}
			return "userRegistration";
		}

	}// end of addusers()

	// messages

	@GetMapping("/replayMessagesForm")
	public String getAnswers(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "userLogin";

		} else {
			// Valid Session
			List<AdminMsgBean> adminMsgList = service.getAnswer();
			modelMap.addAttribute("adminMsgList", adminMsgList);

			return "replayMessages";
		}
	}// End of getAllProducts()

	@GetMapping("/replayMessages")
	public String displayAnswers(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "userLogin";

		} else {
			// Valid Session
			return "userHomePage";
		}
	}// End of displayEmpHomePage()

	@GetMapping("/viewMessagesForm")
	public String getQuestions(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "userLogin";

		} else {
			// Valid Session
			List<UserMsgBean> userMsgList = service.getQuestions();
			modelMap.addAttribute("userMsgList", userMsgList);

			return "viewMessages";
		}
	}// End of getAllProducts()

	@GetMapping("/viewMessages")
	public String displayQuestions(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "adminLogin";

		} else {
			// Valid Session
			return "adminHomePage";
		}
	}// End of displayEmpHomePage()

	@GetMapping("/addToCart")
	public String displayAddToCart(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first.....");
			return "userLogin";
		} else {
			return "insertCard";
		}
	}// end of addProduct()

	@PostMapping("/insertCard")
	public String addToCart(String medicineName, CartBean cart, int userid, HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "userLogin";
		} else {
			if (service.addToCart(userid, medicineName)) {
				modelMap.addAttribute("msg", "Medicine Added Successfully");
			} else {
				modelMap.addAttribute("msg", "Unable to add Medicine");
			}
			return "insertCard";
		}

	}// end of addProduct()

	@GetMapping("/deleteCart")
	public String displayDeleteCartForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "userLogin";

		} else {
			// Valid Session
			return "deleteCart";
		}
	}// End of displaydeleteUserForm()

	@GetMapping("/deleteCartForm")
	public String delete(int cartid, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "userLogin";

		} else {
			// Valid Session
			if (service.delete(cartid)) {
				modelMap.addAttribute("msg", "Medicine Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "cart Id " + cartid + " Not Found!");
			}

			return "deleteCart";
		}
	}// End of deleteP()

	@GetMapping("/payment1")
	public String payment( int userid,HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "userLogin";

		} else {
			// Valid Session
			double bill = service.payment(userid);
			modelMap.addAttribute("bill", bill);
			return "payment";
		}
	}// End of displaydeleteUserForm()
	
	@RequestMapping(path = "/payment", method = RequestMethod.GET)
	public ModelAndView displaypayment() {
		ModelAndView modelAndView = new ModelAndView();
		// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
		modelAndView.setViewName("payment");

		return modelAndView;
	}// end of display()


	  @PostMapping("/payment1") public String payment(int userid, ModelMap modelMap, HttpServletRequest req) {
	  
	  double bill = service.payment(userid);
	  if (bill != 0) { // valid credential
	  HttpSession session = req.getSession(true); 
	  session.setAttribute("bill",bill); 
	  //modelMap.addAttribute("bill", bill);
	 
	  return "payment"; 
	  } else { // invalid credential
		  modelMap.addAttribute("msg","Iinvalid credential");
		  return "payment";
		  } 
	  }
	  
	  
	  @RequestMapping(path = "/userUpdate", method = RequestMethod.GET)
		public ModelAndView displayUpdateUser() {
			ModelAndView modelAndView = new ModelAndView();
			// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
			modelAndView.setViewName("updateUser");

			return modelAndView;
		}// end of display()

	 
	  /*@GetMapping("/updateUser")
		public String displayUpdateUser(HttpSession session, ModelMap modelMap) {

			if (session.isNew()) {
				// invalid session
				modelMap.addAttribute("msg", "Please login first..");
				return "userLogin";
			} else {
				return "updateUser";
			}

		}// end of updatedisplay*/
		@PostMapping("/updateUserForm")
		public String updateUser(UserBean user, HttpSession session, ModelMap modelMap) {

			if (session.isNew()) {
				modelMap.addAttribute("msg", "Please login first..");
				return "userLogin";
			} else {
				user.setUserid(userid);
				if (service.updateUser(user)) {
					modelMap.addAttribute("msg", "User updated Successfully");
				} else {
					modelMap.addAttribute("msg", "Unable to update User");
				}
				return "updateUser";
			}

		}// end of update
		
		
		  @RequestMapping(path = "/question", method = RequestMethod.GET)
			public ModelAndView displayQuestions() {
				ModelAndView modelAndView = new ModelAndView();
				// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
				modelAndView.setViewName("question");

				return modelAndView;
			}// end of display()
		  
		  @PostMapping("/questionForm")
			public String viewQuestions(int userid , String question, UserBean user, HttpSession session, ModelMap modelMap) {

				if (session.isNew()) {
					modelMap.addAttribute("msg", "Please login first..");
					return "userLogin";
				} else {
					user.setUserid(userid);
					if (service.viewQuestions(userid, question)) { 
						modelMap.addAttribute("msg", "Question added Successfully");
					} else {
						modelMap.addAttribute("msg", "Unable to add Question");
					}
					return "question";
				}

			}// end of update
		  
		  @RequestMapping(path = "/answer", method = RequestMethod.GET)
			public ModelAndView displayAnswer() {
				ModelAndView modelAndView = new ModelAndView();
				// modelAndView.setViewName("/WEB-INF/views/helloUser.jsp");
				modelAndView.setViewName("answer");

				return modelAndView;
			}// end of display()
		  
		  
		  @PostMapping("/answerForm")
			public String viewAnswer(int userid , String msgreplay, UserBean user, HttpSession session, ModelMap modelMap) {

				if (session.isNew()) {
					modelMap.addAttribute("msg", "Please login first..");
					return "adminLogin";
				} else {
					user.setUserid(userid);
					if (service.viewAnswers(userid, msgreplay)) {  
						modelMap.addAttribute("msg", "Replay added Successfully");
					} else {
						modelMap.addAttribute("msg", "Unable to add Replay");
					}
					return "answer";
				}

			}// end of update

}
