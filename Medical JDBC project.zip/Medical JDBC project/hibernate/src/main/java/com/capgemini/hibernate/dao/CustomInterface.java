package com.capgemini.hibernate.dao;

public interface CustomInterface {

	
	 public boolean customEmailValidation(String emailId);
	    public boolean customAdminEmailValidation(String email);
	    public boolean medicineNameValidation(String medicineName);
	    public boolean customProductId(int pid);
	    public boolean customAdminId(int aid);
	    public boolean customUserId(int userid);
}
