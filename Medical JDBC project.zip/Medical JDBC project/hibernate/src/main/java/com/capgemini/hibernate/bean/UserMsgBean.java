package com.capgemini.hibernate.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "usermsg")
public class UserMsgBean {

	
	     @Id
	     @Column
		private int msgid;
	     
	     @Column
		private int userid;
	     
	     @Column
		private String username;
	     
	     @Column
		private String question;
		
		//getters and setters
		public int getMsgid() {
			return msgid;
		}
		public void setMsgid(int msgid) {
			this.msgid = msgid;
		}
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getQuestion() {
			return question;
		}
		public void setQuestion(String question) {
			this.question = question;
		}
		
	

}
