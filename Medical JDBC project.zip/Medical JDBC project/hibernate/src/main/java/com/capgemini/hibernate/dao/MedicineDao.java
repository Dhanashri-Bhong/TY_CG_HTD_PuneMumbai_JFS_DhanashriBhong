package com.capgemini.hibernate.dao;

import java.util.List;

import com.capgemini.hibernate.bean.AdminMsgBean;
import com.capgemini.hibernate.bean.CartBean;
import com.capgemini.hibernate.bean.MedicineBean;
import com.capgemini.hibernate.bean.UserBean;
import com.capgemini.hibernate.bean.UserMsgBean;

public interface MedicineDao {
	
	//Admin Methods
	public boolean authenticate(int aid, String password) ;
	public List<MedicineBean> getAllInfo();
	public MedicineBean addProducts( String medicineName, String category , double price);
	public void modifyProducts (int pid);
	public void deleteProducts (int pid);
	public List<UserBean> getAllInfoOfUser();
	public void deleteUser (int usersid);
	public void modifyAdmin (int aid);
	public void insertAnswer(int aid );
	public List<UserMsgBean> seeQuestions();

	
	//user methods
	public UserBean RegisterUsers(String username, String emailId, String pwd , String phoneNumber);
    public int loginAsUser(String emailId , String pwd);
    public CartBean insert(int userid);
	public CartBean delete(String medicineName);
	public CartBean payment(int userid);
	public void modifyUser (int userid);
	public void insertQuestion(int userid );
	public List<AdminMsgBean> seeAnswers();


}
