package com.capgemini.hibernate.controller;

import java.util.Scanner;

import com.capgemini.hibernate.bean.AdminBean;
import com.capgemini.hibernate.bean.UserBean;
import com.capgemini.hibernate.dao.CustomDaoImpl;
import com.capgemini.hibernate.dao.CustomInterface;
import com.capgemini.hibernate.dao.MedicineDao;
import com.capgemini.hibernate.dao.ValidationInterface;
import com.capgemini.hibernate.validation.UserFactory;

public class RegistrationMain {
	public static void registerMain() {

		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		UserBean user = new UserBean();
		CustomInterface custom = new CustomDaoImpl();
		while (true) {
			System.out.println("Enter the user name: ");
			String username = sc.nextLine();
			if (uv.nameValidation(username)) {
				user.setUsername(username);

				System.out.println("Enter the user emailId: ");
				String emailId = sc.nextLine();

				if (uv.emailValidation(emailId)) {
					boolean isValid = custom.customEmailValidation(emailId);
					if (!isValid) {
						user.setEmailId(emailId);
						System.out.println("Enter the password: ");
						String pwd = sc.nextLine();
						if (uv.passValidation(pwd)) {
							user.setPwd(pwd);

							System.out.println("Enter the phone number : ");

							String phoneNumber = sc.nextLine();
							if (uv.mobileValidation(phoneNumber)) {
								user.setPhoneNumber(phoneNumber);
								ms.RegisterUsers(username, emailId, pwd , phoneNumber);
								UserMain.userMain();
							} else {
								System.err.println("enter valid mobile number");
							}

						} else {
							System.err.println("enter valid password...");
						}

					} else {
						System.err.println("Entered email id already exist");
					}

				} else {
					System.err.println("enter valid email...");

				}

			} else {
				System.err.println("enter valid username...");

			}

			

		} // end of while

	}// end of method

}// end of class
