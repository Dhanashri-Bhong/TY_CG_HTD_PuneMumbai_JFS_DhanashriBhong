package com.capgemini.hibernate.validation;

import com.capgemini.hibernate.bean.AdminBean;
import com.capgemini.hibernate.dao.CustomDaoImpl;
import com.capgemini.hibernate.dao.CustomInterface;
import com.capgemini.hibernate.dao.MedicineDao;
import com.capgemini.hibernate.dao.MedicineDaoImpl;
import com.capgemini.hibernate.dao.ValidationImpl;
import com.capgemini.hibernate.dao.ValidationInterface;

public class UserFactory {
	
	private UserFactory() {
	}
	
	public static MedicineDao getDAOImplInstance() {
		MedicineDao dao = new MedicineDaoImpl();
		return dao;
	}
	
	
	public static AdminBean getImplInstance() {
		AdminBean dao = new AdminBean();
		return dao;
	}
	
	
	public static ValidationInterface getValidationInstance() {
		ValidationInterface validation = new ValidationImpl();
		return validation;
	}
	
	public static CustomInterface getDAOImpl() {
		CustomInterface dao = new CustomDaoImpl();
		return dao;
	}
	
}
