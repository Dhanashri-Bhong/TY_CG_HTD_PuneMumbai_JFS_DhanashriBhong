package com.capgemini.hibernate.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hibernate.bean.MedicineBean;
import com.capgemini.hibernate.dao.CustomDaoImpl;
import com.capgemini.hibernate.dao.CustomInterface;
import com.capgemini.hibernate.dao.MedicineDao;
import com.capgemini.hibernate.dao.ValidationInterface;
import com.capgemini.hibernate.validation.UserFactory;

public class MedicineMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		CustomInterface custom = new CustomDaoImpl();
		ValidationInterface uv = UserFactory.getValidationInstance();

		while (true) {
			System.out.println("");
			System.out.println("Welcome To Online Medical Store.....");
			System.out.println("Select A for login as Admin");
			System.out.println("Select U for User Page+");
			System.out.println("Select O for see medicine List");
			String b = sc.nextLine();
			switch (b) {
			case "O": {
				System.out.println("Welcome to Online Medical Stores.....");
				List<MedicineBean> list = ms.getAllInfo();
				if (list != null) {
					for (MedicineBean medicine : list) {
						System.out.println(medicine);
					}
				} else {
					System.err.println("Something Went Wrong...");
				}
			}
			case "A": {
				System.out.println("Please Login as admin...");
				try {
					System.out.println("Enter admin  Id to login  :");
					int aid = Integer.parseInt(sc.nextLine());
					if (custom.customAdminId(aid)) {
						System.out.println("Enter password to login :");
						String password = sc.nextLine();
						try {
							boolean button = ms.authenticate(aid, password);
							if (button == true) {
								AdminMain.adminMain(aid);
							} else {
								System.err.println("Enter valid password ");
							}
						} catch (Exception e) {
							System.err.println("Enter valid password ");

						}
					} else {
						System.err.println("Enter admin id does not exist");
					}

				} catch (Exception e) {
					System.err.println("Enter numbers only");
				}
			} // end of A case
				break;

			case "U": {

				System.out.println("Welcome to user page....");
				System.out.println("press 1 for registration ");
				System.out.println("Press 2 for login....");

				int b1 = Integer.parseInt(sc.nextLine());
				if (b1 == 1) {
					RegistrationMain.registerMain();
				} else if (b1 == 2) {
					UserMain.userMain();
				} else {
					System.err.println("Enter valid number");
				}

			} // end of U case
				break;

			default: {
				System.err.println("Enter valid choice.");
			}

			}// end of main switch

		} // end of while

	}// end of main method
}// end of class