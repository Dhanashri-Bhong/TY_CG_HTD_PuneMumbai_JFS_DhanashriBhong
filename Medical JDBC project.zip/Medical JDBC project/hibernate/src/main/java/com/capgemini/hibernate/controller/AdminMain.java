package com.capgemini.hibernate.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hibernate.bean.MedicineBean;
import com.capgemini.hibernate.bean.UserBean;
import com.capgemini.hibernate.bean.UserMsgBean;
import com.capgemini.hibernate.dao.CustomDaoImpl;
import com.capgemini.hibernate.dao.CustomInterface;
import com.capgemini.hibernate.dao.MedicineDao;
import com.capgemini.hibernate.dao.ValidationInterface;
import com.capgemini.hibernate.validation.UserFactory;

public class AdminMain {
	
	public static void adminMain( int aid) {
	
	Scanner sc = new Scanner(System.in);
	MedicineDao ms = UserFactory.getDAOImplInstance();
	ValidationInterface uv = UserFactory.getValidationInstance();
    CustomInterface custom = new CustomDaoImpl();

     while(true) {
    	 
    	    System.out.println("Press 1 to show all the Medicines");
			System.out.println("Press 2 to Insert the Medicines");
			System.out.println("Press 3 to Update the Medicines");
			System.out.println("Press 4 to  Delete the Medicines");
			System.out.println("Press 5 to see user list");
			System.out.println("Press 6 to  Delete the User");
			System.out.println("Press 7 to change the Administrator and password");
			System.out.println("Select 8 to see all questions ");
			System.out.println("Select 9 to send a answer to users");
            

			System.out.println("Select the Number and Enter :");
		
		String a =sc.nextLine();
		switch (a) {
		case "0": {
			System.out.println("Welcome to Online Medical Store");
		}
			break;
		case "1": {
			List<MedicineBean> list = ms.getAllInfo();
			if (list != null) {
				for (MedicineBean medicine : list) {
					System.out.println(medicine);
				}
			} else {
				System.out.println("Something Went Wrong...");
			}
		}
			break;

		case "2": {
			   
			System.out.println("Give the Medicine  name: ");
			String medicineName = sc.nextLine();
			if(!custom.medicineNameValidation(medicineName)) {
				System.out.println("Give the Medicine category: ");
				String category = sc.nextLine();
				System.out.println("Give the Medicine price: ");
			    try {
					double price = Double.parseDouble(sc.nextLine());
			    	 ms.addProducts( medicineName, category, price);
				} catch (Exception e) {
					System.err.println("Enter number only!");
				}
				
			} else {
				System.err.println("Medicine name is already exist");
			}
			
		}
			break;

		case "3": {
			try {
				System.out.println(" Enter the id of the medicine");
				int pid = Integer.parseInt(sc.nextLine());
				 if(custom.customProductId(pid)) {
						ms.modifyProducts(pid);
				 } else {
					 System.err.println("Enter correct id");
				 }
			} catch (Exception e) {
                System.err.println("Enter digits only");
			}
			
		}
			break;

		case "4": {
			try {
				System.out.println(" Enter the id of the medicine which you want to delete");
				int pid = Integer.parseInt(sc.nextLine());
				 if(custom.customProductId(pid)) {
						ms.deleteProducts(pid);
				 } else {
					 System.err.println("Enter correct id");
				 }
			} catch (Exception e) {
                System.err.println("Enter digits only");
			}
		}
			break;
		case "5": {
			List<UserBean> userList = ms.getAllInfoOfUser();
			if (userList != null) {
				for (UserBean user1 : userList) {
					System.out.println(user1);
				}
			} else {
				System.out.println("Something Went Wrong...");
			}
		}
		case "6": {
			
			try {
				System.out.println("Enter user  id which you want to delete");
				int d = Integer.parseInt(sc.nextLine());
				 if(custom.customUserId(d)) {
						ms.deleteUser(d);
				 } else {
					 System.err.println("Enter correct id");
				 }
			} catch (Exception e) {
                System.err.println("Enter digits only");
			}
			
		}
			break;

		case "7": {
			
			ms.modifyAdmin(aid);
		}
			break;
			
		case "8": {
			List<UserMsgBean> list = ms.seeQuestions();
			if (list != null) {
				for (UserMsgBean question  : list) {
					System.out.println(question);
				}
			} else {
				System.out.println("Something Went Wrong...");
			}
		}
			break;
		case "9":{
			
			try {
				System.out.println(" Enter your id");
				int aid1 = Integer.parseInt(sc.nextLine());
				 if(custom.customAdminId(aid1)) { 
						ms.insertAnswer(aid1);
				 } else {
					 System.err.println("Enter correct id");
				 }
			} catch (Exception e) {
                System.err.println("Enter digits only");
			}
			
			
		}
		default:{ 
			System.out.println("Enter valid choice.");
		}

		}//end of switch

    	 
     }//end of while
  }//end of adminMain()
}//end of class
