package com.capgemini.hibernate.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.hibernate.bean.AdminBean;
import com.capgemini.hibernate.bean.AdminMsgBean;
import com.capgemini.hibernate.bean.CartBean;
import com.capgemini.hibernate.bean.MedicineBean;
import com.capgemini.hibernate.bean.UserBean;
import com.capgemini.hibernate.bean.UserMsgBean;
import com.capgemini.hibernate.validation.UserFactory;

public class MedicineDaoImpl implements MedicineDao {

	Scanner sc = new Scanner(System.in);
	CustomInterface custom = new CustomDaoImpl();
	ValidationInterface uv = UserFactory.getValidationInstance();

	@Override
	public boolean authenticate(int aid, String password) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		String jpql = "from AdminBean where aid = :aid and password = :password";
		Query query = manager.createQuery(jpql);
		tx.begin();
		query.setParameter("aid", aid);
		query.setParameter("password", password);

		AdminBean admin = null;

		try {
			admin = (AdminBean) query.getResultList();
			return true;
		} catch (Exception e) {
			System.err.println("Enter valid password");
			e.printStackTrace();
		}

		return false;

	}

	@Override
	public List<MedicineBean> getAllInfo() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();

		String jpql = " from MedicineBean";
		Query query = em.createQuery(jpql);
		List<MedicineBean> list = query.getResultList();

		for (MedicineBean m : list) {
			System.out.println("Id is " + m.getPid());
			System.out.println("Category is  " + m.getCategory());
			System.out.println("Medicine Name " + m.getMedicineName());
			System.out.println("price is " + m.getPrice());
			System.out.println("----------------------------------------");

		}
		return list;
	}

	@Override
	public MedicineBean addProducts(String medicineName, String category, double price) {
		EntityTransaction transaction = null;
		EntityManager entityManager = null;
		MedicineBean medicine = new MedicineBean();
		// medicine.setPid(pid);
		medicine.setCategory(category);
		medicine.setMedicineName(medicineName);
		medicine.setPrice(price);

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("hibernate");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(medicine);
			System.out.println(" Medicine saved");
			transaction.commit();
		} catch (Exception e) {
			// transaction.rollback();
			e.printStackTrace();
		}

		// entityManager.close();

		return null;

	}

	@Override
	public void modifyProducts(int pid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		while(true) {
		System.out.println("Give the Medicine  name: ");
		String medicineName = sc.nextLine();
		if (!custom.medicineNameValidation(medicineName)) {

			System.out.println("Give the Medicine category: ");
			String category = sc.nextLine();
			System.out.println("Give the Medicine price: ");
			try {
				double price = Double.parseDouble(sc.nextLine());
				tx.begin();
				MedicineBean medicine = manager.find(MedicineBean.class, pid);
				medicine.setCategory(category);
				medicine.setMedicineName(medicineName);
				medicine.setPrice(price);
				tx.commit();
				manager.close();
				if (medicine != null) {
					System.err.println("Medicine Updated..");
				}
			} catch (Exception e) {
				System.err.println("Enter digits only");
			}

		} else {
			System.err.println("Entered medicine name is already exist");
		}
	 }
	}

	@Override
	public void deleteProducts(int pid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();

		String jpql = " delete from  MedicineBean where pid =:pid";
		transaction.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("pid", pid);

		int result = query.executeUpdate();
		System.out.println("Medicine deleted");
		transaction.commit();
		em.close();
	}

	@Override
	public List<UserBean> getAllInfoOfUser() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();

		String jpql = "from UserBean";
		Query query1 = em.createQuery(jpql);
		List<UserBean> userList = query1.getResultList();

		for (UserBean m : userList) {
			System.out.println("Id is " + m.getUserid());
			System.out.println("Username is  " + m.getUsername());
			System.out.println("Email id  " + m.getEmailId());
			System.out.println("Mobile Number " + m.getPhoneNumber());
			System.out.println("Password " + m.getPwd());
			System.out.println("----------------------------------------");

		}
		return userList;
	}

	@Override
	public void deleteUser(int userid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();

		String jpql = " delete from  UserBean where userid =:userid";
		transaction.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("userid", userid);

		int result = query.executeUpdate();
		System.out.println("User deleted");
		transaction.commit();
		em.close();
	}

	@Override
	public void modifyAdmin(int aid) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		System.out.println("Give the Admin  name: ");
		String adminName = sc.nextLine();
		if (uv.nameValidation(adminName)) {

			System.out.println("Give the Email Id: ");
			String email = sc.nextLine();
			if (uv.emailValidation(email)) {
				if (!custom.customAdminEmailValidation(email)) {
					System.out.println("Give the password: ");
					String password = sc.nextLine();
					System.out.println("Give the Mobile Number: ");
					try {

						String mobileNumber = sc.nextLine();
						if (uv.mobileValidation(mobileNumber)) {
							tx.begin();
							AdminBean admin = manager.find(AdminBean.class, aid);
							admin.setAdminName(adminName);
							admin.setEmail(email);
							admin.setPassword(password);
							admin.setMobileNumber(mobileNumber);

							if (admin != null) {
								System.out.println("Admin Updated..");

								manager.close();
								tx.commit();
							}
						} else {
							System.err.println("Enter 10 digits only");
						}

					} catch (Exception e) {
						System.err.println("Enter only digits");
					}

				} else {
					System.err.println("Entered email id is already exist");
				}

			} else {
				System.err.println("Enter correct email id");
			}

		} else {
			System.err.println("Enter name and surname");
		}

	}

	@Override
	public UserBean RegisterUsers(String username, String emailId, String pwd, String phoneNumber) {
		EntityTransaction transaction = null;
		EntityManager entityManager = null;
		UserBean user = new UserBean();
		user.setUsername(username);
		user.setEmailId(emailId);
		user.setPwd(pwd);
		user.setPhoneNumber(phoneNumber);

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("hibernate");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(user);
			System.out.println(" User saved");
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int loginAsUser(String emailId, String pwd) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		String jpql = "from UserBean where emailId = :emailId and pwd = :pwd";
		int id = 0;
		Query query = manager.createQuery(jpql);
		tx.begin();
		query.setParameter("emailId", emailId);
		query.setParameter("pwd", pwd);
		List<UserBean> userList = query.getResultList();

		for (UserBean m : userList) {
			id = m.getUserid();
			System.out.println("Id is " + id);
			return id;
		}
		return id;
	}

	@Override
	public CartBean insert(int userid) {

		System.out.println("user id :" + userid);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		System.out.println("Enter medicine name ");
		String medicineName = sc.nextLine();
		if (custom.medicineNameValidation(medicineName)) {
			System.out.println("Enter Username ");
			String username = sc.nextLine();
			String query2 = "select m from MedicineBean m where medicineName=:medicineName";
			Query query = manager.createQuery(query2);
			query.setParameter("medicineName", medicineName);
			List<MedicineBean> mList = query.getResultList();

			for (MedicineBean m1 : mList) {
				int p = m1.getPid();
				double d = m1.getPrice();
				CartBean cart = new CartBean();

				cart.setPid(p);
				cart.setMedicineName(medicineName);
				cart.setUserid(userid);
				cart.setUsername(username);
				cart.setPrice(d);

				tx.begin();
				manager.persist(cart);
				tx.commit();

				System.out.println(" Medicine added to cart");
			}
			manager.close();

		} else {
			System.err.println("Entered medicine name is not exist");
		}

		return null;
	}

	@Override
	public CartBean delete(String medicineName) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();

		String jpql = " delete from  CartBean where medicineName =:medicineName";
		transaction.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("medicineName", medicineName);

		int result = query.executeUpdate();
		System.out.println("Medicine deleted");
		transaction.commit();
		em.close();
		return null;
	}

	@Override
	public CartBean payment(int userid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();

		String jpql = " select SUM(price) from CartBean  where userid =:userid";
		transaction.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("userid", userid);

		// int result = query.executeUpdate();
		List<Double> cList = query.getResultList();
		double bill = 0;
		for (Double c : cList) {
			bill = c.doubleValue();
			System.out.println(bill);

		}
		transaction.commit();
		em.close();

		return null;
	}

	@Override
	public void modifyUser(int userid) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		while(true) {
		System.out.println("Give the user  name: ");
		String username = sc.nextLine();
		if (uv.nameValidation(username)) {
			System.out.println("Give the Email Id: ");
			String emailId = sc.nextLine();
			if (uv.emailValidation(emailId)) {
				if (!custom.customEmailValidation(emailId)) {
					System.out.println("Give the password: ");
					String pwd = sc.nextLine();
					System.out.println("Give the Mobile Number: ");
					String phoneNumber = sc.nextLine();
					if (uv.mobileValidation(phoneNumber)) {

						tx.begin();
						UserBean user = manager.find(UserBean.class, userid);
						user.setUsername(username);
						user.setEmailId(emailId);
						user.setPwd(pwd);
						user.setPhoneNumber(phoneNumber);

						if (user != null) {
							System.out.println("User Updated..");

							manager.close();
							tx.commit();
						}
					} else {
						System.err.println("Enter 10 digits");
					}

				} else {
					System.out.println("Entered email id is already exist");
				}

			} else {
				System.err.println("Enter valid email id");
			}

		} else {
			System.err.println("Enter name and surname");
		}
	}
	}

// Questions AND ANSWERS
	@Override
	public void insertAnswer(int aid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		System.out.println("Enter Answer ");
		String msgreplay = sc.nextLine();
		System.out.println("Enter Username ");
		String username = sc.nextLine();
		String query2 = "select u from UserBean u where username=:username";
		Query query = manager.createQuery(query2);
		query.setParameter("username", username);
		List<UserBean> uList = query.getResultList();
		for (UserBean m1 : uList) {
			int u = m1.getUserid();

			AdminMsgBean adminMsg = new AdminMsgBean();
			adminMsg.setMsgreplay(msgreplay);
			adminMsg.setUserid(u);
			adminMsg.setUsername(username);

			tx.begin();
			manager.persist(adminMsg);
			tx.commit();

			System.out.println(" Answer inserted");
		}
		manager.close();
	}

	@Override
	public List<UserMsgBean> seeQuestions() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();

		String jpql = " from UserMsgBean";
		Query query = em.createQuery(jpql);
		List<UserMsgBean> list = query.getResultList();

		for (UserMsgBean m : list) {
			System.out.println("Question is : " + m.getQuestion());
			System.out.println(" Userid is : " + m.getUserid());
			System.out.println("User Name is : " + m.getUsername());
			System.out.println("------------------------------------");
		}
		return list;
	}

	@Override
	public List<AdminMsgBean> seeAnswers() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();

		String jpql = " from AdminMsgBean";
		Query query = em.createQuery(jpql);
		List<AdminMsgBean> list = query.getResultList();

		for (AdminMsgBean m : list) {
			System.out.println("Answer is : " + m.getMsgreplay());
			System.out.println(" Userid is : " + m.getUserid());
			System.out.println("User Name is : " + m.getUsername());
			System.out.println("------------------------------------");
		}
		return list;
	}

	@Override
	public void insertQuestion(int userid) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		System.out.println(" Please Enter your problems ");
		String question = sc.nextLine();
		System.out.println("Enter Username ");
		String username = sc.nextLine();
		String query2 = "select u from UserBean u where username=:username";
		Query query = manager.createQuery(query2);
		query.setParameter("username", username);
		List<UserBean> uList = query.getResultList();
		for (UserBean m1 : uList) {
			int u = m1.getUserid();

			UserMsgBean userMsg = new UserMsgBean();
			userMsg.setQuestion(question);
			userMsg.setUserid(u);
			userMsg.setUsername(username);

			tx.begin();
			manager.persist(userMsg);
			tx.commit();

			System.out.println(" Question inserted");
		}
		manager.close();
	}
}// end of class
