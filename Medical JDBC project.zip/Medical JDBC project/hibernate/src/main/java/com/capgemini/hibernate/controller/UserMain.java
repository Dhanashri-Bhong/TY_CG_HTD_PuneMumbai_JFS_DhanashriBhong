package com.capgemini.hibernate.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hibernate.bean.AdminBean;
import com.capgemini.hibernate.bean.AdminMsgBean;
import com.capgemini.hibernate.bean.CartBean;
import com.capgemini.hibernate.bean.MedicineBean;
import com.capgemini.hibernate.bean.UserBean;
import com.capgemini.hibernate.dao.CustomDaoImpl;
import com.capgemini.hibernate.dao.CustomInterface;
import com.capgemini.hibernate.dao.MedicineDao;
import com.capgemini.hibernate.dao.ValidationInterface;
import com.capgemini.hibernate.validation.UserFactory;

public class UserMain {
	public static void userMain() {

		Scanner sc = new Scanner(System.in);
		MedicineDao ms = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		CustomInterface custom = new CustomDaoImpl();

		int id = 0;
		while (true) {
			System.out.println("Please Login as user...");
			System.out.println("Enter email id to login  :");
			String emailId = sc.nextLine();
			if (custom.customEmailValidation(emailId)) {
				System.out.println("Enter password to login :");
				String pwd = sc.nextLine();
				id = ms.loginAsUser(emailId, pwd);
                          
				if (id > 0) {
					System.out.println("Welcome to online Medical Store ");
					while (true) {
						System.out.println("select 0 to see medicine list");
						System.out.println("Select 1 for add to card");
						System.out.println("Select 2 for delete a order");
						System.out.println("Select 3 for payment ");
						System.out.println("Select 4 for change profile");
						System.out.println("Select 5 for send a question to Administrator");
						System.out.println("Select 6 to see all replays ");
						System.out.println("Please enter your choice");

						int c = Integer.parseInt(sc.nextLine());
						switch (c) {

						case 0: {
							List<MedicineBean> list = ms.getAllInfo();
							if (list != null) {
								for (MedicineBean medicine : list) {
									System.out.println(medicine);
								}
							} else {
								System.out.println("Something Went Wrong...");
							}
						}
							break;
						case 1: {
							int userid = id;
							CartBean cart = ms.insert(userid);
						}
							break;
						case 2: {
							try {
								System.out.println("Enter the product name which you want to delete");
								String medicineName = sc.nextLine();
								if(custom.medicineNameValidation(medicineName)) {
									CartBean cart = ms.delete(medicineName);
								} else {
									System.err.println("Enter correct medicine name");
								}
							} catch (Exception e) {
                                System.err.println("Enter digits only");
							}
							
						}
							break;
						case 3: {
							int userid = id;
							CartBean cart = ms.payment(userid);

						}
							break;
						case 4: {
							int userid = id;
							ms.modifyUser(userid);
						}
							break;
						case 5: {
							int userid = id;
							ms.insertQuestion(userid);
						}
							break;
						case 6: {
							List<AdminMsgBean> list1 = ms.seeAnswers();
							if (list1 != null) {
								for (AdminMsgBean answer : list1) {
									System.out.println(answer);
								}
							} else {
								System.err.println("Something Went Wrong...");
							}
						}
							break;
						default: {
							System.err.println("Enter valid choice.");
						}
						}// end of switch

					} // while

				} // end of if

				else {
					System.err.println("Please enter valid username and password.");
				}
			} else {
				System.err.println("Enter valid email id");
			}

		} // end of while

	}// end of method

}// end of class
