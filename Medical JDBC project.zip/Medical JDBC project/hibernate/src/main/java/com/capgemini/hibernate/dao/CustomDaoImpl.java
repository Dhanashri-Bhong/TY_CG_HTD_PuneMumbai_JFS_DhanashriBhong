package com.capgemini.hibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.hibernate.bean.AdminBean;
import com.capgemini.hibernate.bean.MedicineBean;
import com.capgemini.hibernate.bean.UserBean;

public class CustomDaoImpl implements CustomInterface {

	@Override
	public boolean customEmailValidation(String emailId) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from UserBean";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<UserBean> list = null;
		try {
			list = query.getResultList();
			for (UserBean user : list) {
				if (emailId.equals(user.getEmailId())) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

	@Override
	public boolean customAdminEmailValidation(String email) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from AdminBean";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<AdminBean> list = null;
		try {
			list = query.getResultList();
			for (AdminBean admin : list) {
				if (email.equals(admin.getEmail())) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

	@Override
	public boolean medicineNameValidation(String medicineName) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from MedicineBean";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<MedicineBean> list = null;
		try {
			list = query.getResultList();
			for (MedicineBean medicine : list) {
				if (medicineName.equals(medicine.getMedicineName())) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

	@Override
	public boolean customProductId(int pid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from MedicineBean";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<MedicineBean> list = null;
		try {
			list = query.getResultList();
			for (MedicineBean MedicineBean : list) {
				if (pid == MedicineBean.getPid()) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;

	}

	@Override
	public boolean customAdminId(int aid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from AdminBean";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<AdminBean> list = null;
		try {
			list = query.getResultList();
			for (AdminBean admin : list) {
				if (aid == admin.getAid()) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

	@Override
	public boolean customUserId(int userid) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from UserBean";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<UserBean> list = null;
		try {
			list = query.getResultList();
			for (UserBean user : list) {
				if (userid == user.getUserid()) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

}
