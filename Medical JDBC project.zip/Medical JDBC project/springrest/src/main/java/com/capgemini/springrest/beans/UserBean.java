package com.capgemini.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;



@JsonRootName("userInfo")
@XmlRootElement(name = "userlogin")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "userlogin")
@JsonPropertyOrder({"userid","username"})
@JsonInclude(JsonInclude.Include.NON_NULL)

public class UserBean {
	
	@XmlElement
	@Id
	@Column
	private int userid;
	
	@XmlElement
	@Column
	private String username;
	
	@XmlElement
	@Column
	private String emailId;
	
	@XmlElement
	@Column
	private String pwd;
	
	@XmlElement
	@Column
	private int phoneNumber;
	
	
	//getters and setters
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	

}
