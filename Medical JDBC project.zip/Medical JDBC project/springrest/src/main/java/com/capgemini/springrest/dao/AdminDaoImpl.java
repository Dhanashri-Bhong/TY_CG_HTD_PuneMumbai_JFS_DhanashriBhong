package com.capgemini.springrest.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springrest.beans.AdminBean;
import com.capgemini.springrest.beans.AdminMsgBean;
import com.capgemini.springrest.beans.CartBean;
import com.capgemini.springrest.beans.MedicineBean;
import com.capgemini.springrest.beans.UserBean;
import com.capgemini.springrest.beans.UserMsgBean;
@Repository
public class AdminDaoImpl implements AdminDao{

	
	@PersistenceUnit
	 private EntityManagerFactory emf;
	
	@Override
	public UserBean getUser(int userid) {
		
		EntityManager manager = emf.createEntityManager();
		UserBean user = manager.find(UserBean.class, userid);
		manager.close();
		return user;

	}

	@Override
	public AdminBean authenticate(int aid, String password) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from AdminBean where aid = :aid and password = :password";
		Query query = manager.createQuery(jpql);
		query.setParameter("aid", aid);
		query.setParameter("password", password);
		
		AdminBean admin =null;
	try{
		 admin = (AdminBean) query.getSingleResult();
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return admin;
	}

	@Override
	public boolean addProduct(MedicineBean medicine) {
		
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdd= false;
		try{
			tx.begin();
		manager.persist(medicine);
		tx.commit();
		isAdd = true;
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		manager.close();
		return isAdd;
		
	}

	@Override
	public boolean updateProduct(MedicineBean medicine) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		
		MedicineBean medicine1 = manager.find(MedicineBean.class, medicine.getPid());
		if(medicine1 != null) {
			if(medicine.getCategory()!=null) {
				medicine1.setCategory(medicine.getCategory());
			}
			
			if(medicine.getMedicineName() !=null) {
				medicine1.setMedicineName(medicine.getMedicineName());
			}
			
			if(medicine.getQuantity() !=0) {
				medicine1.setQuantity(medicine.getQuantity());
			}
			
			if(medicine.getPrice() !=0) {
				medicine1.setPrice(medicine.getPrice());
			}
			
		}
		boolean isUpdate = false;
		try{
			tx.begin();
		manager.persist(medicine1);
		tx.commit();
		isUpdate = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		manager.close();
		return isUpdate;
	
		
	}//end of update

	@Override
	public boolean deleteProduct(int pid) {
		
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			MedicineBean medicine= entityManager.find(MedicineBean.class, pid);
			entityManager.remove(medicine);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}

	@Override
	public List<MedicineBean> getAllProducts() {
		
		
		EntityManager manager = emf.createEntityManager();
		String jpql = "from MedicineBean";
		Query query = manager.createQuery(jpql);
		
		List<MedicineBean> medicineList = null;
		try {
			medicineList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return medicineList;
	}//end of all products
	
	
	@Override
	public List<UserBean> getUserList() {
		
		
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserBean";
		Query query = manager.createQuery(jpql);
		
		List<UserBean> userList = null;
		try {
			userList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return userList;
	}

	
	@Override
	public boolean deleteUser(int userid) {
		
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			UserBean user= entityManager.find(UserBean.class, userid);
			entityManager.remove(user);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}
	
	
	@Override
	public boolean updateAdmin(AdminBean admin) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		
		AdminBean admin1 = manager.find(AdminBean.class, admin.getAid());
		if(admin1 != null) {
			if(admin.getAdminName()!=null) {
				admin1.setAdminName(admin.getAdminName());
			}
			
			if(admin.getEmail() !=null) {
				admin1.setEmail(admin.getEmail());
			}
			
			if(admin.getPassword() !=null) {
				admin1.setPassword(admin.getPassword());
			}
			
			if(admin.getMobileNumber() != 0) {
				admin1.setMobileNumber(admin.getMobileNumber());
			}
			
		}
		boolean isUpdate = false;
		try{tx.begin();
		manager.persist(admin1);
		tx.commit();
		isUpdate = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		manager.close();
		return isUpdate;
	
		
	}//end of update

	@Override
	public int authenticateUser(String emailId, String pwd) {
		EntityManager manager = emf.createEntityManager();
		int id = 0;
		String jpql = "from UserBean where emailId = :emailId and pwd = :pwd";
		Query query = manager.createQuery(jpql);
		query.setParameter("emailId", emailId);
		query.setParameter("pwd", pwd);
		UserBean user =null;
	try{
		user = (UserBean) query.getSingleResult();
		id = user.getUserid();
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return id;
	}

	@Override
	public boolean register(UserBean user) {
		
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdd= false;
		try{
			tx.begin();
		manager.persist(user);
		tx.commit();
		isAdd = true;
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		manager.close();
		return isAdd;
	}

	

	@Override
	public boolean delete(int cartid ) {
		
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			CartBean cart = entityManager.find(CartBean.class, cartid);
			entityManager.remove(cart);
			isDeleted = true;
			
			tx.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}

	@Override
	public double payment(int userid) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		double bill=0;
		String jpql = "Select SUM(price*quantity) from CartBean where userid=:userid";
		tx.begin();
		Query query = manager.createQuery(jpql);
		query.setParameter("userid", userid);
		List<Double> list=query.getResultList();
		for(Double d:list) {
			bill = d.doubleValue();
			System.out.println("Total Bill is :" +bill); 
		}
		
		return bill;
	}

	@Override
	public List<UserMsgBean> getQuestions() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from UserMsgBean";
		Query query = manager.createQuery(jpql);
		
		List<UserMsgBean> userMsgList = null;
		try {
			userMsgList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return userMsgList;
	}

	@Override
	public List<AdminMsgBean> getAnswer() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from AdminMsgBean";
		Query query = manager.createQuery(jpql);
		
		List<AdminMsgBean> adminMsgList = null;
		try {
			adminMsgList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return adminMsgList;
	}

	@Override
	public boolean viewQuestions(int userid , String question) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		UserMsgBean userMsgBean = new UserMsgBean();
		int userid1 = 0;
		String username=null;
		boolean isAdd = false;
		String jpql="Select u from UserBean u where userid=:userid";
		Query query =  manager.createQuery(jpql);
		query.setParameter("userid", userid);
    	List<UserBean> userList = query.getResultList();
		for (UserBean user :userList ) {
			userid1 = user.getUserid();
			username = user.getUsername();
			
			userMsgBean.setUserid(userid1);
			userMsgBean.setUsername(username);
			userMsgBean.setQuestion(question);
			
			
		}
		tx.begin();
		manager.persist(userMsgBean);
		System.out.println("Question saved");
		tx.commit();
		isAdd = true;
		
		return isAdd;	
		
	}

	@Override
	public boolean viewAnswers(int userid , String msgreplay) {
		
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		AdminMsgBean adminMsgBean = new AdminMsgBean();
		int userid1 = 0;
		String username=null;
		boolean isAdd = false;
		String jpql="Select u from UserBean u where userid=:userid";
		Query query =  manager.createQuery(jpql);
		query.setParameter("userid", userid);
		List<UserBean> userList = query.getResultList();
		for (UserBean user :userList ) {
			userid1 = user.getUserid();
			username = user.getUsername();
			
			adminMsgBean.setUserid(userid1);
			adminMsgBean.setUsername(username);
			adminMsgBean.setMsgreplay(msgreplay);
			
			
		}
		tx.begin();
		manager.persist(adminMsgBean);
		System.out.println("Answer saved");
		tx.commit();
		isAdd = true;
		
		return isAdd;
		
	}

	@Override
	public boolean addToCart(int userid , String medicineName, int quantity ) {

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		int p = 0;
		 double d =0;
		
		 boolean isAdd= false;
		 String username=null;
		String jpql= "from UserBean where userid=:userid";
		 tx.begin();
			Query query1 = manager.createQuery(jpql);
		      query1.setParameter("userid", userid);
		      List<UserBean> uList = query1.getResultList(); 
		      for (UserBean u :uList) {
		    	  username = u.getUsername();
		    	  //userid=u.getUserid();
		      }
		      Scanner sc = new Scanner(System.in);
		      
		String query2= "Select m from MedicineBean m where medicineName=:medicineName";
		Query query = manager.createQuery(query2);
				query.setParameter("medicineName", medicineName);
				
				List<MedicineBean> mList = query.getResultList();

				for (MedicineBean m1 : mList) {
				 p = m1.getPid();
                 d =m1.getPrice();
                // quantity = m1.getQuantity();
                       
				}
				CartBean cart = new CartBean();
                cart.setPid(p);
                cart.setUserid(userid);
                cart.setUsername(username);
                cart.setMedicineName(medicineName);
                cart.setPrice(d);
                cart.setQuntity(quantity);
                
                
               
				manager.persist(cart);
            	isAdd=true;

				tx.commit();

                manager.close();
				  return isAdd;
	}

	@Override
	public boolean updateUser(UserBean user) {
         
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		
		UserBean user1 = manager.find(UserBean.class, user.getUserid());
		if(user1 != null) {
			if(user.getUsername()!=null) {
				user1.setUsername(user.getUsername());
			}
			
			if(user.getEmailId() !=null) {
				user1.setEmailId(user.getEmailId());
			}
			
			if(user.getPwd() !=null) {
				user1.setPwd(user.getPwd());
			}
			
			if(user.getPhoneNumber() != 0) {
				user1.setPhoneNumber(user.getPhoneNumber());
			}
			
		}
		boolean isUpdate = false;
		try{tx.begin();
		manager.persist(user1);
		tx.commit();
		isUpdate = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		manager.close();
		return isUpdate;
	
	}

	@Override
	public List<CartBean> getCartList() {

		EntityManager manager = emf.createEntityManager();
		String jpql = "from CartBean";
		Query query = manager.createQuery(jpql);
		
		List<CartBean> cartList = null;
		try {
			cartList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return cartList;
	}
				
}//end of class

