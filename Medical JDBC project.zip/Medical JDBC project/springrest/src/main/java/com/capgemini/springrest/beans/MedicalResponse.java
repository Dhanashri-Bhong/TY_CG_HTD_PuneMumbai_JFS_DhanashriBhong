package com.capgemini.springrest.beans;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicalResponse {
	
	private int statusCode;
	private String message;
	private String description;
	private double bill;
	
	
	
	private AdminBean adminBean;
	private List<AdminBean> adminList;
	
	private AdminMsgBean adminMsgBean;
	private List<AdminMsgBean> adminMsgList;
	
	private CartBean cartBean;
	private List<CartBean> cartList;
	
	private MedicineBean medicineBean;
	private List<MedicineBean> medicineList;
	
	private UserBean userBean;
	private List<UserBean> userList;
	
	private UserMsgBean userMsgBean;
	private List<UserMsgBean> userMsgList;
	
	//getters and setters
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public AdminBean getAdminBean() {
		return adminBean;
	}
	public void setAdminBean(AdminBean adminBean) {
		this.adminBean = adminBean;
	}
	public List<AdminBean> getAdminList() {
		return adminList;
	}
	public void setAdminList(List<AdminBean> adminList) {
		this.adminList = adminList;
	}
	public AdminMsgBean getAdminMsgBean() {
		return adminMsgBean;
	}
	public void setAdminMsgBean(AdminMsgBean adminMsgBean) {
		this.adminMsgBean = adminMsgBean;
	}
	public List<AdminMsgBean> getAdminMsgList() {
		return adminMsgList;
	}
	public void setAdminMsgList(List<AdminMsgBean> adminMsgList) {
		this.adminMsgList = adminMsgList;
	}
	public CartBean getCartBean() {
		return cartBean;
	}
	public void setCartBean(CartBean cartBean) {
		this.cartBean = cartBean;
	}
	public List<CartBean> getCartList() {
		return cartList;
	}
	public void setCartList(List<CartBean> cartList) {
		this.cartList = cartList;
	}
	public MedicineBean getMedicineBean() {
		return medicineBean;
	}
	public void setMedicineBean(MedicineBean medicineBean) {
		this.medicineBean = medicineBean;
	}
	public List<MedicineBean> getMedicineList() {
		return medicineList;
	}
	public void setMedicineList(List<MedicineBean> medicineList) {
		this.medicineList = medicineList;
	}
	public UserBean getUserBean() {
		return userBean;
	}
	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}
	public List<UserBean> getUserList() {
		return userList;
	}
	public void setUserList(List<UserBean> userList) {
		this.userList = userList;
	}
	public UserMsgBean getUserMsgBean() {
		return userMsgBean;
	}
	public void setUserMsgBean(UserMsgBean userMsgBean) {
		this.userMsgBean = userMsgBean;
	}
	public List<UserMsgBean> getUserMsgList() {
		return userMsgList;
	}
	public void setUserMsgList(List<UserMsgBean> userMsgList) {
		this.userMsgList = userMsgList;
	}
	//getters and setters
		public double getBill() {
			return bill;
		}
		public void setBill(double bill) {
			this.bill = bill;
		}
	
	
	

}
