package com.capgemini.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;


@JsonRootName("adminMsgInfo")
@XmlRootElement(name = "adminmsg")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "adminmsg")
@JsonPropertyOrder({"ansid","username"})
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AdminMsgBean {
	

	@XmlElement
	@Id
	@Column
	private int ansid;
	
	@XmlElement
	@Column
	private int userid;
	
	@XmlElement
	@Column
	private String username;
	
	@XmlElement
	@Column
	private String msgreplay;
	
	//getters and setters
	public int getAnsid() {
		return ansid;
	}
	public void setAnsid(int ansid) {
		this.ansid = ansid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMsgreplay() {
		return msgreplay;
	}
	public void setMsgreplay(String msgreplay) {
		this.msgreplay = msgreplay;
	} 
	
	

}
