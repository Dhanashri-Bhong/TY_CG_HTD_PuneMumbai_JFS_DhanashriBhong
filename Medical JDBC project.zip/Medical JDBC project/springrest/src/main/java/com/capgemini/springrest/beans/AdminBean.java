package com.capgemini.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;


@JsonRootName("adminInfo")
@XmlRootElement(name = "adminlogin")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "adminlogin")
@JsonPropertyOrder({"adminid","adminName"})
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AdminBean {
	
	@XmlElement
	@Id
	@Column
	private int aid;
	
	@XmlElement
	@Column
	private String adminName;
	
	@XmlElement
	@Column
	private String email;
	
	@XmlElement
	@Column
	private String password;
	
	@XmlElement
	@Column
	private long mobileNumber;
	
	//getters and setters
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	

}
