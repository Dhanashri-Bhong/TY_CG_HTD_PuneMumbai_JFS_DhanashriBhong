package com.capgemini.springrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springrest.beans.AdminBean;
import com.capgemini.springrest.beans.AdminMsgBean;
import com.capgemini.springrest.beans.CartBean;
import com.capgemini.springrest.beans.MedicineBean;
import com.capgemini.springrest.beans.UserBean;
import com.capgemini.springrest.beans.UserMsgBean;
import com.capgemini.springrest.dao.AdminDao;

@Service
public class AdminServiceImpl implements AdminService {

	
	@Autowired
	private AdminDao dao;
	
	@Override
	public UserBean getUser(int userid) {
		
		if(userid > 0) {
		return dao.getUser(userid);
		}
		return null;
	}

	@Override
	public AdminBean authenticate(int aid, String password) {
		return dao.authenticate(aid, password);
	}

	@Override
	public boolean addProduct(MedicineBean medicine) {
		return dao.addProduct(medicine);
	}

	@Override
	public boolean updateProduct(MedicineBean medicine) {
		return dao.updateProduct(medicine);
	}
	
	@Override
	public boolean deleteProduct(int pid) {
		return dao.deleteProduct(pid);
	}

	@Override
	public List<MedicineBean > getAllProducts() {
		return dao.getAllProducts();
	}

	@Override
	public List<UserBean> getUserList() {
		return dao.getUserList();
	}

	@Override
	public boolean deleteUser(int userid) {
		return dao.deleteUser(userid);
	}

	@Override
	public boolean updateAdmin(AdminBean admin) {
		return dao.updateAdmin(admin); 
	}

	@Override
	public int authenticateUser(String emailId, String pwd) {
		return dao.authenticateUser(emailId, pwd); 
	}

	@Override
	public boolean register(UserBean user) {
		return dao.register(user);
 	}

	

	@Override
	public boolean delete(int cartid) {
		return dao.delete(cartid);
	}

	@Override
	public double payment(int userid) {
		return dao.payment(userid); 
	}

	@Override
	public List<UserMsgBean> getQuestions() {
		return dao.getQuestions();
	}

	@Override
	public List<AdminMsgBean> getAnswer() {
		return dao.getAnswer();
	}

	@Override
	public boolean viewQuestions(int userid , String question) {
		return dao.viewQuestions(userid, question);
	}

	@Override
	public boolean viewAnswers(int userid , String msgreplay) {
		return dao.viewAnswers(userid, msgreplay);
	}

	@Override
	public boolean addToCart(int userid, String medicineName , int quantity) {
		return dao.addToCart(userid, medicineName , quantity);
	}

	@Override
	public boolean updateUser(UserBean user) {
		return dao.updateUser(user);
	}

	@Override
	public List<CartBean> getCartList() {
		return dao.getCartList();
	}

	

}
