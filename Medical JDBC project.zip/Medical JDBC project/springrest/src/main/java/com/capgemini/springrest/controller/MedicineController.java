package com.capgemini.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springrest.beans.AdminBean;
import com.capgemini.springrest.beans.AdminMsgBean;
import com.capgemini.springrest.beans.CartBean;
import com.capgemini.springrest.beans.MedicalResponse;
import com.capgemini.springrest.beans.MedicineBean;
import com.capgemini.springrest.beans.UserBean;
import com.capgemini.springrest.beans.UserMsgBean;
import com.capgemini.springrest.service.AdminService;
@RestController
public class MedicineController {
	
	@Autowired
	private AdminService service;
	
	@GetMapping("/loginAsAdmin")
	// @ResponseBody
	public MedicalResponse authenticate(int aid , String password) {

		AdminBean adminBean = service.authenticate(aid, password);

		MedicalResponse response = new MedicalResponse();
		
		if(adminBean != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Admin Logged in successfully");
			
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to match Admin record...");

		}
		return response; 
	}//end of adminLogin
	int userid =0;
	@GetMapping("/loginAsUser")
	// @ResponseBody
	public MedicalResponse loginAsUser(String emailId , String pwd) {

		userid = service.authenticateUser(emailId, pwd);

		MedicalResponse response = new MedicalResponse();
		
		if(userid != 0) {
			
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("user Logged in successfully");
			
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to match user record...");

		}
		return response; 
	}//end of adminLogin
	
	//**********Lists*********
	
	@GetMapping(path="/getAll" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse getAllProducts(){
		List<MedicineBean> medicineList =  service.getAllProducts();

		MedicalResponse response = new MedicalResponse();
       
		if(medicineList != null && !medicineList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Medicine List found...");
			response.setMedicineList(medicineList);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find Medicines List...");

		}
		return response;

	}//end of see all
	
	@GetMapping(path="/getAllUsers" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse getAllUsers(){
		List<UserBean> userList =  service.getUserList();

		MedicalResponse response = new MedicalResponse();
       
		if(userList != null && !userList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("User List found...");
			response.setUserList(userList);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find User List...");

		}
		return response;

	}//end of see all
	
	
	@GetMapping(path="/getAllQuestion" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse getAllQuestion(){
		List<UserMsgBean> userMsgList =  service.getQuestions();

		MedicalResponse response = new MedicalResponse();
       
		if(userMsgList != null && !userMsgList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("User Questions found...");
			response.setUserMsgList(userMsgList);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find User Questions...");

		}
		return response;

	}//end of see all
	
	
	@GetMapping(path="/getAllAnswer" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse getAllAnswer(){
		List<AdminMsgBean> adminMsgList =  service.getAnswer();

		MedicalResponse response = new MedicalResponse();
       
		if(adminMsgList != null && !adminMsgList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Admin Answers found...");
			response.setAdminMsgList(adminMsgList);;
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find Admin Answers...");

		}
		return response;

	}//end of see all
	
	//*************Add*********
	
	@PutMapping(path="/addProduct" , consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public MedicalResponse addProduct(@RequestBody MedicineBean medicineBean) {

		boolean isAdd= service.addProduct(medicineBean);
		
		MedicalResponse response = new MedicalResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Medicine added successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to add Medicine record...");
		}
		return response;

	}// end of addemployee()
	
	
	@PutMapping(path="/register" , consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public MedicalResponse register(@RequestBody UserBean userBean) {

		boolean isAdd= service.register(userBean);
		
		MedicalResponse response = new MedicalResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("User registered successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription(" Sorry , Unable to register user...");
		}
		return response;

	}// end of addemployee()
	
//update
	
	@PostMapping(path="/updateAdmin", consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse updateAdmin(@RequestBody AdminBean adminBean) {

		boolean isUpdated= service.updateAdmin(adminBean);
		MedicalResponse response = new MedicalResponse();
		
		if(isUpdated) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Admin updated successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to update Admin record...");
		}
		return response;

	}// end of update
	
	
	@PostMapping(path="/updateUser", consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse updateUser(@RequestBody UserBean userBean) {

		boolean isUpdated= service.updateUser(userBean);
		MedicalResponse response = new MedicalResponse();
		
		if(isUpdated) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("User updated successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to update User record...");
		}
		return response;

	}// end of update
	
	
	@PostMapping(path="/updateProduct", consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse updateProduct(@RequestBody MedicineBean medicineBean) {

		boolean isUpdated= service.updateProduct(medicineBean);
		MedicalResponse response = new MedicalResponse();
		
		if(isUpdated) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Medicine updated successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to update Medicine record...");
		}
		return response;

	}// end of update
	
	
	////*******************delete
	
	@DeleteMapping(path="/deleteProduct",produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
			// @ResponseBody
			public MedicalResponse deleteProduct(int pid) {

				boolean isDeleted= service.deleteProduct(pid);
				MedicalResponse response = new MedicalResponse();
				
				if(isDeleted) {
					response.setStatusCode(201);
					response.setMessage("Success");
					response.setDescription("medicine deleted successfully");
				}else {
					response.setStatusCode(401);
					response.setMessage("Failed");
					response.setDescription("Unable to delete medicine record...");
				}
				return response;

			}// end of delete
	
	@DeleteMapping(path="/deleteUser",produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public MedicalResponse deleteUser(int userid){

		boolean isDeleted= service.deleteUser(userid);
		MedicalResponse response = new MedicalResponse();
		
		if(isDeleted) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("user deleted successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to delete user record...");
		}
		return response;

	}// end of delete
	
	
	@DeleteMapping(path="/deleteCart",produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public MedicalResponse delete(int cartid) {

		boolean isDeleted= service.delete(cartid);
		MedicalResponse response = new MedicalResponse();
		
		if(isDeleted) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("medicine added in cart deleted successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to delete added medicine ..");
		}
		return response;

	}// end of delete
	
	
	@PutMapping(path="/sendQuestion")
	// @ResponseBody
	public MedicalResponse Question(int userid , String question) {

		boolean isAdd= service.viewQuestions(userid, question);
		
		MedicalResponse response = new MedicalResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Question send to admin successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription(" Sorry , Unable to send question to admins...");
		}
		return response;

	}// end of addemployee()
	
	@PutMapping(path="/sendAnswer")
	// @ResponseBody
	public MedicalResponse answer(int userid , String msgreplay) {

		boolean isAdd= service.viewAnswers(userid, msgreplay);
		
		MedicalResponse response = new MedicalResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Answer send to user successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription(" Sorry , Unable to send answer to user...");
		}
		return response;

	}// end of addemployee()
	
	
	@PutMapping(path="/addToCart")
	// @ResponseBody
	public MedicalResponse addToCart( String medicineName , int quantity) {

		boolean isAdd= service.addToCart(userid, medicineName , quantity);
		
		MedicalResponse response = new MedicalResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Medicine added in cart successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to add Medicine in cart...");
		}
		return response;

	}// end of addemployee()
	
	
	
	@GetMapping(path="/getAllCart" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse getAllCart(){
		List<CartBean> cartList =  service.getCartList();

		MedicalResponse response = new MedicalResponse();
       
		if(cartList != null && !cartList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Add To Cart List found...");
			response.setCartList(cartList);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find Add To Cart List...");

		}
		return response;

	}//end of see all
	
	@GetMapping(path="/payment" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public MedicalResponse payment(int userid){
		double bill =  service.payment(userid);
;
		MedicalResponse response = new MedicalResponse();
       
		if(bill != 0) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Bill is ...");
			response.setBill(bill);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find Add To Cart List...");

		}
		return response;

	}//end of see all
	
	
}
