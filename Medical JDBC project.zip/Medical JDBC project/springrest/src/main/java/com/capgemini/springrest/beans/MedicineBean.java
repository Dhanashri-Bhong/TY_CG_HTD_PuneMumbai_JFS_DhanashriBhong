package com.capgemini.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("medicineInfo")
@XmlRootElement(name = "medicine")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "medicine")
@JsonPropertyOrder({"pid","medicineName"})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicineBean {
	
	@XmlElement
	@Id
	@Column
	private int pid;
	
	@XmlElement
	@Column
	private String medicineName;
	
	@XmlElement
	@Column
	private String category;
	
	@XmlElement
	@Column
	private double price;
	
	@XmlElement
	@Column
	private int quantity;
	
	//getters and setters
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
