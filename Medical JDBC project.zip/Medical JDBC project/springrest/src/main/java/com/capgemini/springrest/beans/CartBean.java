package com.capgemini.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;



@JsonRootName("cart")
@XmlRootElement(name = "cart")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "cart")
@JsonPropertyOrder({"cartid","medicineName"})
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CartBean {
	
	@XmlElement
	@Id
	@Column
	private int cartid;
	
	@XmlElement
	@Column
	private int userid;
	
	@XmlElement
	@Column
	private int pid;
	
	@XmlElement
	@Column
	private String username;
	
	@XmlElement
	@Column
	private String medicineName;
	
	@XmlElement
	@Column
	private double price;
	
	@XmlElement
	@Column
	private int quantity;
	
	
	//getters and setters
	public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuntity() {
		return quantity;
	}
	public void setQuntity(int quntity) {
		this.quantity = quantity;
	}
	

}
