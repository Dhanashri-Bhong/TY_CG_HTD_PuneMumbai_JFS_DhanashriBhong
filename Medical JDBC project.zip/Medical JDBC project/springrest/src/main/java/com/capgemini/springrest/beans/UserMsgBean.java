package com.capgemini.springrest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;


@JsonRootName("userMsgInfo")
@XmlRootElement(name = "usermsg")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "usermsg")
@JsonPropertyOrder({"msgid","username"})
@JsonInclude(JsonInclude.Include.NON_NULL)

public class UserMsgBean {

	
	     @XmlElement
	     @Id
	     @Column
		private int msgid;
	     
	     @XmlElement
	     @Column
		private int userid;
	     
	     @XmlElement
	     @Column
		private String username;
	     
	     @XmlElement
	     @Column
		private String question;
		
		//getters and setters
		public int getMsgid() {
			return msgid;
		}
		public void setMsgid(int msgid) {
			this.msgid = msgid;
		}
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getQuestion() {
			return question;
		}
		public void setQuestion(String question) {
			this.question = question;
		}
		
	

}
