package com.capgemini.jdbc.controller;

import java.util.Scanner;

import com.capgemini.jdbc.beans.AdminMsgBean;
import com.capgemini.jdbc.beans.LoginBean;
import com.capgemini.jdbc.beans.UserLoginBean;
import com.capgemini.jdbc.dao.Administrator;
import com.capgemini.jdbc.dao.Card;
import com.capgemini.jdbc.dao.CustomInterface;
import com.capgemini.jdbc.dao.ValidationInterface;
import com.capgemini.jdbc.validation.UserFactory;

public class RegistrationMain {

	public static void register() {

		Scanner sc = new Scanner(System.in);
		Administrator us = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		CustomInterface custom = UserFactory.getDAOImpl();
		UserLoginBean user = new UserLoginBean();
		int id = 0;

		// System.out.println("Enter the userid: ");
		// int userid = Integer.parseInt(sc.nextLine());
		
		System.out.println("Welome to Registration Page");
		while (true) {
			System.out.println("Enter the user name: ");
			String username = sc.nextLine();
			
			if (uv.nameValidation(username)) {
				user.setUsername(username);
			
				System.out.println("Enter the user emailId: ");
			   String emailId = sc.nextLine();

			if (uv.emailValidation(emailId)) {

				boolean isValid = custom.customEmailValidation(emailId);
				if (!isValid) {
					user.setEmailId(emailId);
					System.out.println("Enter the password: ");
					String pwd = sc.nextLine();
					if (uv.passValidation(pwd)) {
						user.setPwd(pwd);
						System.out.println("Enter the phone number : ");
						String phoneNumber = sc.nextLine();
						if (uv.mobileValidation(phoneNumber)) {
							user.setPhoneNumber(phoneNumber);
							us.addUsers(username, emailId, pwd, phoneNumber);
							break;
						} else {
							System.err.println("Enter valid Phone Number");
						}
					} else {
						System.err.println("Enter valid password...");
					}
				} else {
					System.err.println("Email Id is already present ");

				}

			} else {
				System.err.println("enter valid email...");
			}
		}else {
			System.err.println("Enter valid user name");
		}

		} // end of while
		UserMain.userMain();


	}// end of method

}// end of class
