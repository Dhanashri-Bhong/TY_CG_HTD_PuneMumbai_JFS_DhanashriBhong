package com.capgemini.jdbc.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.jdbc.beans.AdminMsgBean;
import com.capgemini.jdbc.beans.AdministratorBeans;
import com.capgemini.jdbc.beans.LoginBean;
import com.capgemini.jdbc.beans.UserLoginBean;
import com.capgemini.jdbc.dao.Administrator;
import com.capgemini.jdbc.dao.Card;
import com.capgemini.jdbc.dao.CustomDaoImpl;
import com.capgemini.jdbc.dao.CustomInterface;
import com.capgemini.jdbc.dao.ValidationInterface;
import com.capgemini.jdbc.validation.UserFactory;

public class AdminMain {

	
	public static void adminMain() {
		
		Scanner sc = new Scanner(System.in);
		Administrator us = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
        CustomInterface custom = new CustomDaoImpl();

        // CardBean card = new CardBean();
         Card cd = UserFactory.getInstance();
         int id = 0;
		
		while(true) {
		System.out.println("Press 1 to show all the Medicines");
		System.out.println("Press 2 to Insert the Medicines");
		System.out.println("Press 3 to Update the Medicines");
		System.out.println("Press 4 to  Delete the Medicines");
		System.out.println("Press 5 to  Delete the User");
		System.out.println("Press 6 to change the Administrator and password");
		System.out.println("Select 7 for send a replay to user");
        System.out.println("Select 8 to see all questions ");

		System.out.println("Select the Number and Enter :");

		String a = sc.nextLine();
		switch (a) {
		case "0": {
			System.out.println("Welcome to Online Medical Store");
		}
			break;
		case "1": {
			List<AdministratorBeans> list = us.getAllInfo();
			if (list != null) {
				for (AdministratorBeans admin : list) {
					System.out.println(admin);
				}
			} else {
				System.out.println("Something Went Wrong...");
			}
		}
			break;
		case "2": {
			//System.out.println("Give the Medicine pid: ");
			//int pid = Integer.parseInt(sc.nextLine());
			System.out.println("Give the Medicine Product name: ");
			String productName = sc.nextLine();
			if(!custom.medicineNameValidation(productName)) {
				
				System.out.println("Give the Medicine category: ");
				String category = sc.nextLine();
				System.out.println("Give the Medicine price: ");
				try {
					double price = Double.parseDouble(sc.nextLine());
					 us.addProducts( productName, category, price);
				} catch (Exception e) {
					System.err.println("Enter the number only!");
				}
				
			   
			} else {
				System.err.println("Enter medicine name is already exist.");
			}
			

		}
			break;
		case "3": {
			System.out.println("Enter Medicine id which you want to update");
			try {
			int pid = Integer.parseInt(sc.nextLine());
			if(custom.customProductId(pid)) {
			us.modifyProducts(pid);
			} else {
				System.err.println("Enter valid medicine id");
			}
			} catch(Exception e) {
				System.err.println("Enter the numbers only!");
			}
		}
			break;
		case "4": {
			System.out.println("Enter product  id which you want to delete");
			try {
			int pid = Integer.parseInt(sc.nextLine());
			if(custom.customProductId(pid)) {
				 us.deleteProducts(pid);	
				 } else {
					System.err.println("Enter valid medicine id");
				}
			} catch (Exception e) {
				System.err.println("Enter the numbers only!");
			}
		}
			break;
		case "5": {
			System.out.println("Enter user  id which you want to delete");
			try {
			int userid = Integer.parseInt(sc.nextLine());
			if(custom.customUserId(userid)) {
		      us.deleteUser(userid);
			} else {
				System.err.println("Enter correct userid");
			}
			} catch(Exception e) {
				System.err.println("Enter the numbers only!");
			}
		}
			break;
		case "6": {
			System.out.println("Enter admin id which you want to update");
			try {
			 id = Integer.parseInt(sc.nextLine());
			if(custom.customAdminId(id)) {
			System.out.println("Enter the password which you want to update");
			String password = sc.nextLine();
			us.modifyAdministraorAndPassword(id, password);
			} else {
				System.err.println("Enter correct id");
			}
			} catch(Exception e) {
				System.err.println("Enter the numbers only!");
			} 
		}
	   break;
			
		case "7":{
			  us.sendRep();
		}
		break;
		case "8":{
			us.seeRequest();
		}
		break;
		default:{ 
			System.err.println("Enter valid choice.");
		}
		
		}//end of switch
	}//end of while
 }
}
