package com.capgemini.jdbc.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.jdbc.beans.AdminMsgBean;
import com.capgemini.jdbc.beans.AdministratorBeans;
import com.capgemini.jdbc.beans.CardBean;
import com.capgemini.jdbc.beans.LoginBean;
import com.capgemini.jdbc.beans.UserLoginBean;
import com.capgemini.jdbc.dao.Administrator;
import com.capgemini.jdbc.dao.Card;
import com.capgemini.jdbc.dao.CustomDaoImpl;
import com.capgemini.jdbc.dao.CustomInterface;
import com.capgemini.jdbc.dao.ValidationInterface;
import com.capgemini.jdbc.validation.UserFactory;

public class UserMain {
	
	public static void userMain() {
		
		
		while(true) {
		Scanner sc = new Scanner(System.in);
		Administrator us = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
         CustomInterface custom = new CustomDaoImpl();
        // CardBean card = new CardBean();
         Card cd = UserFactory.getInstance();
         int id = 0;
	
			System.out.println("Please Login as user...");
			System.out.println("Enter emailId to login  :");
			String emailId = sc.nextLine();
			if(custom.customEmailValidation(emailId)) {
				System.out.println("Enter password to login :");
				String pwd = sc.nextLine();
				 id = us.loginAsUser(emailId, pwd);
				 if(id > 0) {
					 System.out.println("User Logged in successfully.");
				 } else {
					 System.err.println("Entered password is wrong.");
				 }

			}else {
				System.err.println("Entered Email does not exist");
			}
			
		   
			while (id >0) {
				System.out.println("Welcome to online Medical Store ");
				while(true) {
					System.out.println("Select 1 to see all medicine");
					System.out.println("Select 2 for add to card");
					System.out.println("Select 3 for delete a order");
					System.out.println("Select 4 for change profile");
					System.out.println("Select 5 for send a question to Administrator");
			        System.out.println("Select 6 to see all replays ");
			        System.out.println("Select 7 for payment ");
			         System.out.println("Please enter your choice");
					String c = sc.nextLine();
					switch (c) {
					case "1":{
						List<AdministratorBeans> list = us.getAllInfo();
						if (list != null) {
							for (AdministratorBeans admin : list) {
								System.out.println(admin);
							}
						} else {
							System.out.println("Something Went Wrong...");
						}
					}
					break;
					case "2":{
						int userid= id;
						CardBean card = cd.insert(userid);

					}
					break;
					case "3":{
						System.out.println("Enter the product name which you want to delete");
						String productName = sc.nextLine();
						if(custom.medicineNameValidation(productName)) {
						CardBean card = cd.delete(productName);
						} else {
							System.err.println("Enter valid medicine name");
						}
						}
					break;
					
					case "4":{
						int userid= id;
                        us.modifyUser(userid);  
					}
					
					case "5":{
						int userid= id;
						us.sendReqAdmin(userid);
						
					}
					break;
					case "6":{
						int userid= id;
						 us.seeReplayFromAdmin(userid); 
					}
					break;
					case "7" :{
						int userid= id;
			           CardBean card = cd.payment(userid);

					}
					break;
					default:{
						System.err.println("Please Enter Valid number");
					}
					
					}//end of add to card switch

					
				} // end of while
			} 
	
		}
	}//end of method

}//end of class
