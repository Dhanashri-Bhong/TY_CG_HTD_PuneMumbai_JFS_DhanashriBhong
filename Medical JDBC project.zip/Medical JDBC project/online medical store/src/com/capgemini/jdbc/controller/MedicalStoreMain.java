package com.capgemini.jdbc.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.jdbc.beans.AdminMsgBean;
import com.capgemini.jdbc.beans.AdministratorBeans;
import com.capgemini.jdbc.beans.CardBean;
import com.capgemini.jdbc.beans.LoginBean;
import com.capgemini.jdbc.beans.UserLoginBean;
import com.capgemini.jdbc.dao.Administrator;
import com.capgemini.jdbc.dao.Card;
import com.capgemini.jdbc.dao.CustomDaoImpl;
import com.capgemini.jdbc.dao.CustomInterface;
import com.capgemini.jdbc.dao.ValidationInterface;
import com.capgemini.jdbc.validation.UserFactory;

public class MedicalStoreMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Administrator us = UserFactory.getDAOImplInstance();
		ValidationInterface uv = UserFactory.getValidationInstance();
		CustomInterface custom = new CustomDaoImpl();

		int id = 0;
		while (true) {
			System.out.println("Welcome To Online Medical Store.....");
			System.out.println("Press 0 to see Medicine List");
			System.out.println("Press 1 to login as a admin");
			System.out.println("Press 2 to see user page");
			String b = sc.nextLine();
			switch (b) {

			case "0": {
				System.out.println("Welcome to Online Medical Store");
				List<AdministratorBeans> list = us.getAllInfo();
				if (list != null) {
					for (AdministratorBeans admin : list) {
						System.out.println(admin);
					}
				} else {
					System.out.println("Something Went Wrong...");
				}
			}
			break;

			case "1": {
				while (true) {
					System.out.println("Please Login as admin...");
					System.out.println("Enter email to login  :");
					String email = sc.nextLine();
					if (custom.customAdminEmailValidation(email)) {
						System.out.println("Enter password to login :");
						String password = sc.nextLine();
						boolean button = us.loginAsAdmin(email, password);
						if (button == true) {
							System.out.println("admin logged in successfully.");
							AdminMain.adminMain();
						} else {
							System.err.println("Password is wrong");
						}

					} else {
						System.err.println("Enter email id does not exist.");
					}
				} // end of while
			} // end of admin switch
			//break;
			case "2": {

				System.out.println("Welcome to user page....");
				System.out.println("press 1 for registration ");
				System.out.println("Press 2 for login....");

				int b1 = Integer.parseInt(sc.nextLine());
				if (b1 == 1) {
					RegistrationMain.register();
				} else if (b1 == 2) {
					UserMain.userMain();
				} else {
					System.err.println("Enter valid choice");
				}
			}
				break;
			default: {
				System.err.println("Enter valid choice.");
			}

			}// end of switch
		} // end of while

	}// end of main
}// end of class
