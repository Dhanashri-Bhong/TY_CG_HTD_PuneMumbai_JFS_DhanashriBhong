package com.capgemini.jdbc.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.jdbc.beans.AdminMsgBean;
import com.capgemini.jdbc.beans.AdministratorBeans;
import com.capgemini.jdbc.beans.LoginBean;
import com.capgemini.jdbc.beans.UserLoginBean;

public class AdministratorDaoImpl implements Administrator {

	FileReader reader = null;
	Properties prop = null;
	AdministratorBeans admin = null;
	LoginBean login = null;
	Scanner sc = new Scanner(System.in);
	Connection conn = null;
	ResultSet rs = null;
	Statement stmt;
	PreparedStatement pstmt;
    CustomInterface custom = new CustomDaoImpl();

	
	public AdministratorDaoImpl() {
		try {
			
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
			System.out.println("Driver Loaded............");
			System.out.println("-----------------------------------");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<AdministratorBeans> getAllInfo() {

		List<AdministratorBeans> list = new ArrayList<AdministratorBeans>();
		String query = "SELECT * FROM admin";
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password"));
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {
			while (rs.next()) {
				admin = new AdministratorBeans();
				admin.setPid(rs.getInt("pid"));
				admin.setProductName(rs.getString("productName"));
				admin.setCategory(rs.getString("category"));
				admin.setPrice(rs.getInt("price"));

				list.add(admin);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public AdministratorBeans addProducts( String productName, String category, double price) {
		String query = "INSERT INTO admin (productName , category , price) values(?,?,?)";
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
			//pstmt.setInt(1, pid);
			pstmt.setString(1, productName);
			pstmt.setString(2, category);
			pstmt.setDouble(3, price);

			int count = pstmt.executeUpdate();
			if (count > 0) {
				System.out.println("medicine inserted........");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void modifyProducts(int pid) {
		
		
		CustomInterface custom = new CustomDaoImpl();
		ValidationInterface vd = new ValidationImpl();
		System.out.println("Enter 1 to change medicine name");
		System.out.println("Enter 2 to change category");
		System.out.println("Enter 3 to chnage price");
		String choice = sc.nextLine();
		switch(choice) {
		
		case "1":{
			System.out.println("Enter the medicine name");
			 String productName = sc.nextLine();
			 
				 if(!custom.customEmailValidation(productName)) {
					 
					String query = "update admin set productName = ? where pid = ?";
					 try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
						
						 pstmt.setString(1, productName);
						 pstmt.setInt(2, pid);
						  int count = pstmt.executeUpdate();
						  if(count>0) {
							  System.out.println(" Medicine name updated successfully");
						  }
					} catch (Exception e) {
                     e.printStackTrace();
					}
					 
				 }else {
					 System.err.println("Medicine name is already exist");
				 }
			 
			
		}
		break;
		
           case "2":{
			
    	   System.out.println("Enter the category ");
			 String category = sc.nextLine();
					String query = "update admin set category = ? where pid = ?";
					 try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
						
						 pstmt.setString(1, category);
						 pstmt.setInt(2, pid);
						  int count = pstmt.executeUpdate();
						  if(count>0) {
							  System.out.println("category  updated successfully");
						  }
					} catch (Exception e) {
                   e.printStackTrace();
					}
					 
				 }
    	   
		break;
		
       case "3":{
	
    	   System.out.println("Enter the price ");
    	   try {
			 double price = Double.parseDouble(sc.nextLine());
					String query = "update admin set price = ? where pid = ?";
					 try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
						
						 pstmt.setDouble(1, price);
						 pstmt.setInt(2, pid);
						  int count = pstmt.executeUpdate();
						  if(count>0) {
							  System.out.println("price  updated successfully");
						  }
					} catch (Exception e) {
                 e.printStackTrace();
					}
    	   } catch(Exception e) {
    		   System.err.println("Enter only numbers");
    	   }
    	   
           }
        break;
        default:{
        	System.out.println("Enter the number between 1 to 3");
        }
		
		
		}//end of switch

	}//end of method

	@Override
	public AdministratorBeans deleteProducts(int pid) {
		String query = "Delete from admin where pid = ?";

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, pid);
			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("data deleted......");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public UserLoginBean deleteUser(int userid) {
		String query = "Delete from userlogin where userid = ?";

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, userid);
			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("data deleted......");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public LoginBean modifyAdministraorAndPassword(int userid, String pwd) {
		String query = "update login set password = ? where id = ?";

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setString(1, pwd);
			pstmt.setInt(2, userid);

			int count = pstmt.executeUpdate();
			if (count > 0) {
				System.out.println("data updated........");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean loginAsAdmin(String email, String password) {
		String query = "select id from login where email = ? and password = ?";

		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
            
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public int loginAsUser(String emailId, String pwd) {
		String query = "select userid from userlogin where emailId = ? and pwd = ?";
          int id = 0;
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setString(1, emailId);
			pstmt.setString(2, pwd);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				id= rs.getInt(1);
				return id;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public UserLoginBean addUsers( String username, String emailId, String pwd,String phoneNumber) {
		String query = "INSERT INTO userlogin values(?,?,?,?)";
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
			//pstmt.setInt(1, userid);
			pstmt.setString(1, username);
			pstmt.setString(2, emailId);

			pstmt.setString(3, pwd);
			pstmt.setString(4, phoneNumber);


			int count = pstmt.executeUpdate();
			if (count > 0) {
				System.out.println("You are successfully Register........");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	@Override
	public void sendReqAdmin(int userid) {
		
		String getuName=null;
		String msgToAdmin=null;
		String query12 = "select username from userlogin where userid=?";
		try {
		Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); 
			
			
		PreparedStatement pstmt = conn.prepareStatement(query12);

			pstmt.setInt(1, userid);
			rs = pstmt.executeQuery();
			
	   while (rs.next()) {
				
				
                System.out.println("Username is"+rs.getString(1));
                System.out.println("User Id is"+userid);
                getuName=rs.getString(1);
                System.out.println("***********");
                System.out.println("Enter msg to Admin");
                msgToAdmin=sc.nextLine();
                String query2="insert into usermsg(userid,username,question)values(?,?,?)";
                pstmt = conn.prepareStatement(query2);
                pstmt.setInt(1, userid);
                pstmt.setString(2, getuName);
                pstmt.setString(3, msgToAdmin);


                int count = pstmt.executeUpdate();
    			if (count > 0) {

    				System.out.println("data is inserted");

    			}
	}
					}catch(Exception e) {
						e.printStackTrace();
					}

	}		
	

	@Override
	public AdminMsgBean seeRequest() {
		try {
			
			
			String query = "select * from usermsg";
			Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password")); 
				
			pstmt = conn.prepareStatement(query);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println(" Message Id is:" + rs.getInt(1));
				System.out.println(" user Id is:" + rs.getInt(2));
				System.out.println(" User Name  is:" + rs.getString(3));
				System.out.println(" Msg is:" + rs.getString(4));
				System.out.println("***************************");

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return null;
	}

	@Override
	public AdminMsgBean sendRep() {
		String getuName = null;
		String msgFromAdmin = null;
		int userid;
		try {
			Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password")); 
				
			String query = "select username from userlogin where userid=?";
			pstmt = conn.prepareStatement(query);
			System.out.println("enter user Id");
			try {
			userid = Integer.parseInt(sc.nextLine());
			if(custom.customUserId(userid)) {
			pstmt.setInt(1, userid);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				System.out.println("Username is" + rs.getString(1));
				System.out.println("User Id is" + userid);
				getuName = rs.getString(1);
				System.out.println("Enter reply to user");
				msgFromAdmin = sc.nextLine();
				String query2 = "insert into adminmsg(userid,username,msgreplay)values(?,?,?)";
				pstmt = conn.prepareStatement(query2);
				pstmt.setInt(1, userid);
				pstmt.setString(2, getuName);
				pstmt.setString(3, msgFromAdmin);

				int count = pstmt.executeUpdate();
				if (count > 0) {

					System.out.println("data is inserted");

				}
			}
			} else {
				System.err.println("Enter valid userid");
			}
			} catch(Exception e) {
				System.err.println("Enter the numbers only!");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return null;
	}

	@Override
	public void seeReplayFromAdmin(int userid) {
		try {
			Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password")); 
				
			String query = "select msgreplay from adminmsg where userid=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, userid);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				/*
				 * System.out.println(" Ans  Id is:" + rs.getInt(1));
				 * System.out.println(" user Id is:" + rs.getInt(2));
				 * System.out.println("User Name  is:" + rs.getString(3));
				 */
				System.out.println("Msg is:" + rs.getString(1));

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	@Override
	public boolean emailValidation(String emailId) {

		String query = "select emailId from userlogin";
		boolean isValid = false;
		
		try {
			Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password")); 
			try(ResultSet res = pstmt.executeQuery();) {
				
				while(res.next()) {
					if(emailId.equalsIgnoreCase(res.getString(1))) {
						isValid = true;
						return isValid;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
	}

	@Override
	public void modifyUser(int userid) {

		CustomInterface custom = new CustomDaoImpl();
		ValidationInterface vd = new ValidationImpl();
		
		System.out.println("Enter 1 to change email");
		System.out.println("Enter 2 to change password");
		System.out.println("Enter 3 to chnage mobile number");
		String choice = sc.nextLine();
		switch(choice) {
		
		case "1":{
			System.out.println("Enter the email id");
			 String emailId = sc.nextLine();
			 if(vd.emailValidation(emailId)) {
				 if(!custom.customEmailValidation(emailId)) {
					 
					String query = "update userlogin set emailId = ? where userid = ?";
					 try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
						
						 pstmt.setString(1, emailId);
						 pstmt.setInt(2, userid);
						  int count = pstmt.executeUpdate();
						  if(count>0) {
							  System.out.println("Email Id updated successfully");
						  }
					} catch (Exception e) {
                     e.printStackTrace();
					}
					 
				 }else {
					 System.err.println("Email ID is already exist");
				 }
			 } else {
				 System.err.println("Entered email is not valid");
			 }
			
		}
		break;
		
       case "2":{
			
    	   System.out.println("Enter the password ");
			 String pwd = sc.nextLine();
			 if(vd.emailValidation(pwd)) {
					String query = "update userlogin set pwd = ? where userid = ?";
					 try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
						
						 pstmt.setString(1, pwd);
						 pstmt.setInt(2, userid);
						  int count = pstmt.executeUpdate();
						  if(count>0) {
							  System.out.println("password  updated successfully");
						  }
					} catch (Exception e) {
                   e.printStackTrace();
					}
					 
				 }
			 else {
				 System.err.println("Entered password is not valid");
			 }
    	   
		}
		break;
		
       case "3":{
	
    	   System.out.println("Enter the mobile number ");
			 String phoneNumber = sc.nextLine();
			 if(vd.emailValidation(phoneNumber)) {
					String query = "update userlogin set phoneNumber = ? where userid = ?";
					 try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
						
						 pstmt.setString(1, phoneNumber);
						 pstmt.setInt(2, userid);
						  int count = pstmt.executeUpdate();
						  if(count>0) {
							  System.out.println("Mobile Number  updated successfully");
						  }
					} catch (Exception e) {
                 e.printStackTrace();
					}
					 
				 }
			 else {
				 System.err.println("Enter valid mobile number");
			 }
    	   
           }
        break;
        default:{
        	System.out.println("Enter the number between 1 to 3");
        }
		
		
		}//end of switch
		
	}//end of method

}// end of class
