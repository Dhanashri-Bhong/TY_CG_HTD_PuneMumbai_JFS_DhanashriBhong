package com.capgemini.jdbc.dao;

import java.util.List;

import com.capgemini.jdbc.beans.AdminMsgBean;
import com.capgemini.jdbc.beans.AdministratorBeans;
import com.capgemini.jdbc.beans.LoginBean;
import com.capgemini.jdbc.beans.UserLoginBean;

public interface Administrator {
	//admin
	public List<AdministratorBeans> getAllInfo();
	public AdministratorBeans addProducts(String productName, String category , double price);
	public void modifyProducts (int pid);
	public AdministratorBeans deleteProducts (int pid);
	public boolean loginAsAdmin(String email , String password);
	public LoginBean modifyAdministraorAndPassword(int userid, String pwd);

	//login
	public UserLoginBean deleteUser (int userid);
	public UserLoginBean addUsers( String username, String emailId,String phoneNumber, String pwd);
    public int loginAsUser(String emailId , String pwd);
	public boolean emailValidation(String emailId);
	public void modifyUser(int userid);
    
    //msg
    
    public void sendReqAdmin(int userid);
    public AdminMsgBean seeRequest();
    public AdminMsgBean sendRep();
    public void seeReplayFromAdmin(int userid);


	
}//end of interface
