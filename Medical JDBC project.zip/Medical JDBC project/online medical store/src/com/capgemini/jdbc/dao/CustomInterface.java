package com.capgemini.jdbc.dao;

public interface CustomInterface {
	
    public boolean customEmailValidation(String emailId);
    public boolean customAdminEmailValidation(String email);
    public boolean medicineNameValidation(String productName);
    public boolean customProductId(int pid);
    public boolean customAdminId(int id);
    public boolean customUserId(int userid);

}
