package com.capgemini.jdbc.dao;

import com.capgemini.jdbc.beans.CardBean;

public interface Card {
	
	public CardBean insert(int userid);
	public CardBean delete(String productName);
	public CardBean payment(int userid);
	

}//end of interface
