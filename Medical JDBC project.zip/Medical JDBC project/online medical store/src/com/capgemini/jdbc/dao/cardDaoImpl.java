package com.capgemini.jdbc.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.jdbc.beans.CardBean;

public class cardDaoImpl implements Card {

	FileReader reader = null;
	Properties prop = null;
	Scanner sc = new Scanner(System.in);
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	CustomInterface custom = new CustomDaoImpl();

	Connection conn = null;

	public cardDaoImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// end of constructor

	@Override
	public CardBean insert(int userid) {
		System.out.println("--------------------------");
		System.out.println("user id :" + userid);
		String getusername = null;
		String productName = null;
		double getPrice = 0;
		int getpid = 0;
		try {
			String query = "select username from userlogin where userid = ?";
			try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
				System.out.println("user id :" + userid);
				pstmt.setInt(1, userid);
				ResultSet res = pstmt.executeQuery();
				if (res.next()) {

					System.out.println("username : " + res.getString(1));
					System.out.println("userid : " + userid);
					getusername = res.getString(1);

					System.out.println("Enter product name ");
					productName = sc.nextLine();
					if (custom.medicineNameValidation(productName)) {
						String query2 = "select pid,price from admin where productName =?";
						pstmt2 = conn.prepareStatement(query2);
						pstmt2.setString(1, productName);
						ResultSet res2 = pstmt2.executeQuery();
						if (res2.next()) {
							System.out.println("pid : " + res2.getInt(1));
							System.out.println("price : " + res2.getDouble(2));
							getpid = res2.getInt(1);
							getPrice = res2.getDouble(2);

							String query3 = "insert into card (userid,pid,username,productName,price) values(?,?,?,?,?)";
							pstmt2 = conn.prepareStatement(query3);
							pstmt2.setInt(1, userid);
							pstmt2.setInt(2, getpid);
							pstmt2.setString(3, getusername);
							pstmt2.setString(4, productName);
							pstmt2.setDouble(5, getPrice);
							int count = pstmt2.executeUpdate();
							if (count > 0) {
								System.out.println("Product Added");
							}
						}
					}else {
						System.err.println("enter correct medicine name ");
					}
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			System.err.println("Enter the correct medicine name");
		}
		return null;
	}

	@Override
	public CardBean delete(String productName) {
		try {

			Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
			String query = "delete from card where productName= ?";

			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, productName);
			int count = pstmt.executeUpdate();
			if (count > 0) {
				System.out.println("Product deleted.....");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public CardBean payment(int userid) {

		try {

			Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
					prop.getProperty("password"));
			String query4 = "select SUM(price) from card where userid = ? ";
			pstmt = conn.prepareStatement(query4);
			pstmt.setInt(1, userid);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				System.out.println("Total Price : " + res.getDouble(1));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

}// end of class
