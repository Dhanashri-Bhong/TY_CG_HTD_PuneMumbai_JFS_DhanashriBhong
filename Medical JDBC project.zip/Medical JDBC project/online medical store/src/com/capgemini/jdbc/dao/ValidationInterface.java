package com.capgemini.jdbc.dao;

public interface ValidationInterface {

	public boolean idValidation(String id);
	public boolean nameValidation(String name);
	public boolean emailValidation(String email);
	public boolean passValidation(String pass);
	public boolean mobileValidation(String mobileNumber);

}
