package com.capgemini.jdbc.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.jdbc.beans.AdministratorBeans;
import com.capgemini.jdbc.beans.LoginBean;

public class CustomDaoImpl implements CustomInterface {

	FileReader reader = null;
	Properties prop = null;
	AdministratorBeans admin = null;
	LoginBean login = null;
	Scanner sc = new Scanner(System.in);
	Connection conn = null;
	ResultSet rs = null;
	Statement stmt;
	PreparedStatement pstmt;

	public CustomDaoImpl() {

		try {

			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
			System.out.println("Driver Loaded.");
			System.out.println("-----------------------------------");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}//end of constructor

	@Override
	public boolean customEmailValidation(String emailId) {
		
		String query = "select emailId from userlogin";
		boolean isValid = false;
		
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
			 
			try(ResultSet res = pstmt.executeQuery(query)) {
				
				while(res.next()) {
					if(emailId.equals(res.getString(1))) {
						isValid = true;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
	}//end of user email
	
	
	
	@Override
	public boolean customAdminEmailValidation(String email) {
		
		String query = "select email from login";
		boolean isValid = false;
		
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
			 
			try(ResultSet res = pstmt.executeQuery(query)) {
				
				while(res.next()) {
					if(email.equals(res.getString(1))) {
						isValid = true;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
	}

	@Override
	public boolean medicineNameValidation(String productName) {
       
		String query = "select productName from admin";
		boolean isValid = false;
		
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
			 
			try(ResultSet res = pstmt.executeQuery(query)) {
				
				while(res.next()) {
					if(productName.equals(res.getString(1))) {
						isValid = true;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
	
	}//end of method

	@Override
	public boolean customProductId(int pid) {
		String query = "select pid from admin";
		boolean isValid = false;
		
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
			 
			try(ResultSet res = pstmt.executeQuery(query)) {
				
				while(res.next()) {
					if(pid== res.getInt(1)) {
						isValid = true;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
		}//end of method

	@Override
	public boolean customAdminId(int id) {
		
		String query = "select id from login";
		boolean isValid = false;
		
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
			 
			try(ResultSet res = pstmt.executeQuery(query)) {
				
				while(res.next()) {
					if(id== res.getInt(1)) {
						isValid = true;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
	}

	@Override
	public boolean customUserId(int userid) {

		String query = "select userid from userlogin";
		boolean isValid = false;
		
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); PreparedStatement pstmt=conn.prepareStatement(query)) {
			 
			try(ResultSet res = pstmt.executeQuery(query)) {
				
				while(res.next()) {
					if(userid== res.getInt(1)) {
						isValid = true;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return isValid;
	}

}//end of class
