package com.capgemini.jdbc.beans;

public class AdministratorBeans {
	
	private int pid;
	private String productName;
	private String category;
	private double price;
	
	//getters and setters
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "AdministratorBeans [pid=" + pid + ", productName=" + productName + ", category=" + category + ", price="
				+ price + "]";
	}
	
	

}//end of class
