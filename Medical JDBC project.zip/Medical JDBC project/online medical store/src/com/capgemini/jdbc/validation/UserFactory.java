package com.capgemini.jdbc.validation;

import com.capgemini.jdbc.dao.Administrator;
import com.capgemini.jdbc.dao.AdministratorDaoImpl;
import com.capgemini.jdbc.dao.Card;
import com.capgemini.jdbc.dao.CustomDaoImpl;
import com.capgemini.jdbc.dao.CustomInterface;
import com.capgemini.jdbc.dao.ValidationImpl;
import com.capgemini.jdbc.dao.ValidationInterface;
import com.capgemini.jdbc.dao.cardDaoImpl;

public class UserFactory {
	
	private UserFactory() {
	}
	
	public static Administrator getDAOImplInstance() {
		Administrator dao = new AdministratorDaoImpl();
		return dao;
	}
	
	public static Card getInstance() {
		Card dao1 = new cardDaoImpl();
		return dao1;
	}
	
	public static CustomInterface getDAOImpl() {
		CustomInterface dao = new CustomDaoImpl();
		return dao;
	}
	
	public static ValidationInterface getValidationInstance() {
		ValidationInterface validation = new ValidationImpl();
		return validation;
	}
	
	/*
	 * public static UserServices getServiceImplInstance() { UserServices services =
	 * new UserServicesImpl(); return services; }
	 * 
	 * public static UserValidation getValidationInstance() { UserValidation
	 * validation = new UserValidationImpl(); return validation; }
	 */

}
