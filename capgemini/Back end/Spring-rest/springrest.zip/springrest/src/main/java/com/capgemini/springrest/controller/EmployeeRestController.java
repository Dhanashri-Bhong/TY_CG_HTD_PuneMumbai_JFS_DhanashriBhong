package com.capgemini.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springrest.bean.EmployeeInfoBean;
import com.capgemini.springrest.bean.EmployeeResponse;
import com.capgemini.springrest.service.EmployeeService;

//@Controller
@RestController
public class EmployeeRestController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/getEmployee")
	// @ResponseBody
	public EmployeeResponse getEmployee(int empId) {

		EmployeeInfoBean eib = service.getEmployee(empId);

		EmployeeResponse response = new EmployeeResponse();
		
		if(eib != null) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee got successfully");
			response.setEib(eib);
			
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to get employee record...");

		}
		return response; 
				}// end of getemployee()

	@PutMapping(path="/addEmployee" , consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public EmployeeResponse addEmployee(@RequestBody EmployeeInfoBean eib) {

		boolean isAdd= service.addEmployee(eib);
		EmployeeResponse response = new EmployeeResponse();
		
		if(isAdd) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee added successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to add employee record...");
		}
		return response;

	}// end of addemployee()

	@DeleteMapping(path="/deleteEmployee",  
	produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	// @ResponseBody
	public EmployeeResponse deleteEmployee(int empId) {

		boolean isDeleted= service.deleteEmployee(empId);
EmployeeResponse response = new EmployeeResponse();
		
		if(isDeleted) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee deleted successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to delete employee record...");
		}
		return response;

	}// end of delete

	@PostMapping(path="/updateEmployee", consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE} , 
			produces ={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public EmployeeResponse updateEmployee(@RequestBody EmployeeInfoBean eib) {

		boolean isUpdated= service.updateEmployee(eib);
EmployeeResponse response = new EmployeeResponse();
		
		if(isUpdated) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee updated successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to update employee record...");
		}
		return response;

	}// end of update
	
	@GetMapping(path="/getAll" , produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public EmployeeResponse getAllEmployees(){
		List<EmployeeInfoBean> eibList =  service.getAllEmployees();

		EmployeeResponse response = new EmployeeResponse();
       
		if(eibList != null && !eibList.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Success");
			response.setDescription("Employee record found...");
			response.setEibList(eibList);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription("Unable to find employee record...");

		}
		return response;

	}//end of see all

}// end of class
