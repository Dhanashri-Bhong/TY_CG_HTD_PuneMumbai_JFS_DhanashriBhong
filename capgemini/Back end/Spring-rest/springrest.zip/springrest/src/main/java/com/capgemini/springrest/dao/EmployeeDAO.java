package com.capgemini.springrest.dao;

import java.util.List;

import com.capgemini.springrest.bean.EmployeeInfoBean;

public interface EmployeeDAO {

	public EmployeeInfoBean getEmployee(int empId);
	public EmployeeInfoBean authenticate(int empId , String pwd);
	public boolean addEmployee(EmployeeInfoBean eib);
	public boolean updateEmployee(EmployeeInfoBean eib);
	public boolean deleteEmployee(int empId);
	public List<EmployeeInfoBean> getAllEmployees();
}//end of DAO
