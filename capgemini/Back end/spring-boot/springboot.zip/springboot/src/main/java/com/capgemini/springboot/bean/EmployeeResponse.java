package com.capgemini.springboot.bean;

import java.util.List;

public class EmployeeResponse {

	
	private int statusCode;
	private String message;
	private String description;
	private EmployeeInfoBean eib;
	private List<EmployeeInfoBean> eibList ;
	
	//getters and setters
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public EmployeeInfoBean getEib() {
		return eib;
	}
	public void setEib(EmployeeInfoBean eib) {
		this.eib = eib;
	}
	public List<EmployeeInfoBean> getEibList() {
		return eibList;
	}
	public void setEibList(List<EmployeeInfoBean> eibList) {
		this.eibList = eibList;
	}
	
}//end of class
