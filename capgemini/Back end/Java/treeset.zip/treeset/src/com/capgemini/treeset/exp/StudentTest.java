package com.capgemini.treeset.exp;

import java.util.Comparator;
import java.util.TreeSet;


public class StudentTest {
	public static void main(String[] args) {
		
		Comparator<StudentBean> ci = (o1,o2)-> {
			if (o1.getId()>o2.getId())
			{
				return 1;
			}
			else if (o1.getId()<o2.getId())
			{
				return -1;
				
			}
			else
			{
			return 0;
			}

		};


		TreeSet<StudentBean> ts = new TreeSet<StudentBean>(ci);

		StudentBean s1 = new StudentBean();
		s1.setId(20);
		s1.setName("vaibhav");
		s1.setPercentage(71.65);
		s1.setGender('M');

		StudentBean s2 = new StudentBean();
		s2.setId(21);
		s2.setName("Dhanashri");
		s2.setPercentage(81.65);
		s2.setGender('F');

		StudentBean s3 = new StudentBean();
		s3.setId(22);
		s3.setName("Simran");
		s3.setPercentage(91.65);
		s3.setGender('F');

		StudentBean s4 = new StudentBean();
		s4.setId(23);
		s4.setName("Nabila");
		s4.setPercentage(71.65);
		s4.setGender('F');

		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);

		System.out.println("*****************************");
		for (StudentBean r : ts) {
			System.out.println("Name is :" + r.getName());
			System.out.println("Id is :" + r.getId());
			System.out.println("Percentage is :" + r.getPercentage());
			System.out.println("Gender is :" + r.getGender());
			System.out.println("*********************************");
		}

	}
}
