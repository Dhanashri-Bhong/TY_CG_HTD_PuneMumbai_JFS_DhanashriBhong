package com.capgemini.treeset.exp;

import java.util.Comparator;

public class ByNameComp  implements Comparator<StudentBean>{

	@Override
	public int compare(StudentBean o1, StudentBean o2) {
		return o1.getName().compareTo(o2.getName());
	}

	
	
	
}
