package com.capg.corejava.cfs;

public class IfElseIfExample {
  public static void main(String[] args) {
	int marks = 46;
	if(marks>=76) {
		System.out.println("Grade A");
	}
	else if (marks>50 || marks>25)
	{
		System.out.println("Grade B");
	}
	else if (marks<25 && marks>=10 )
	{
		System.out.println("Grade C");
	}
	else
	{
		System.out.println("fail");
	}
}
}
