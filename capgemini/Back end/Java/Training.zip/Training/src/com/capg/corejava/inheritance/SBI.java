package com.capg.corejava.inheritance;

public class SBI implements ATM {

	@Override
	public void validateCard() {
		System.out.println(" I am validating a SBI card");
	}

	@Override
	public void getInfo() {
		System.out.println("I am getting a SBI card");
	}

}
