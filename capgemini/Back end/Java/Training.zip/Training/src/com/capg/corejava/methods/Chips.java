package com.capg.corejava.methods;

public interface  Chips {
	public  void open();
	public void eat();
	
}
