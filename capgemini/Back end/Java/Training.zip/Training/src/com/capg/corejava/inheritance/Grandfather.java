package com.capg.corejava.inheritance;

public class Grandfather {
   String name = "Vijay";
   String lastname = "Jaysingpure";
   
   public static void main(String[] args) 
   {
	Grandfather g = new Grandfather();
	g.printName();
}
   public void printName()
   {
	   System.out.println(name + " " + lastname);
   }
}
