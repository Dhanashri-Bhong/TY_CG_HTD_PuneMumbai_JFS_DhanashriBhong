package com.capg.corejava.inheritance;

public class HDFC implements ATM {

	@Override
	public void validateCard()
	{
		System.out.println(" i am validating a HDFC card");
	}

	@Override
	public void getInfo()
	{
		System.out.println("  I am getting a HDFC card");
	}

}
