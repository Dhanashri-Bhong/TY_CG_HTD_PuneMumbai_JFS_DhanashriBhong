package com.capg.corejava.methods;

public class MethodsExample {
	public static void print()
	{
		System.out.println("print() method");
	}
	public static int areaOfSquare(int side)
	{
		int area = side*side;
		System.out.println(area);

		return area;
	}
	public static void main(String[] args) {
		print();
		areaOfSquare(5);

	}

}