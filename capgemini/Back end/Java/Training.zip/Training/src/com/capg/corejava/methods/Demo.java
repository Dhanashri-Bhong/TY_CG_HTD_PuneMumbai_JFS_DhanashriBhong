package com.capg.corejava.methods;

public class Demo
{
	
	static MethodsExample me = new MethodsExample(); 

	public static void main(String[] args)
	{
		 MethodsExample me1 = new MethodsExample(); 
         System.out.println(me);
		System.out.println(me1);
	}

}
