package com.capg.corejava.inheritance;

public interface InterfaceExample2 
{
   public void print();
   public void printNum();
 
   public static void show()
   {
	   System.out.println("static method of interface");
   }
   default void display()
   {
	   System.out.println("default method of interface");
   }

}
