package com.capg.corejava.inheritance;

public abstract class InEx4 implements InterfaceExample2
{

}
