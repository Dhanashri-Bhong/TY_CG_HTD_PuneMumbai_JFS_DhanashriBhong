package com.capg.corejava.inheritance;

public class ICICI implements ATM {

	@Override
	public void validateCard()
	{
		System.out.println("I am validating  ICICI card");
	}

	@Override
	public void getInfo()
	{
		System.out.println("I am getting a ICICI card");
	}

}
