package com.capg.corejava.basics;

public class ArithmaticOperators {

	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		int res = i + j;
		System.out.println("i+j= " + res);
		res = i - j;
		System.out.println("i-j= " + res);
		res = i * j;
		System.out.println("i*j= " + res);
		res = i / j;
		System.out.println("i/j= " + res);
		res = j % i;
		System.out.println("i%j= " + res);

	}

}
