package com.capg.corejava.cfs;

public class SwitchExample {
	public static void main(String[] args) {
		int dayNum = 5;
		switch(dayNum)
		{
		case 1 :System.out.println("Monday");
		break;
		case 2 :System.out.println("tuesday");
		break;
		case 3 :System.out.println("wednesday");
		break;
		case 4 :System.out.println("thursday");
		break;
		case 5 :System.out.println("friday");
		break;
		case 6 :System.out.println("saturday");
		break;
		case 7 :System.out.println("sunday");
		break;
		default : System.out.println("Invalid Day Num");
		}
		switch(dayNum)
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			System.out.println("WeekDays");
			break;
		case 6:
		case 7:
			System.out.println("WeekEnd");
			break;
		default:
			System.out.println("Invalid Day Num");
		}
	}

}
