package com.capg.corejava.inheritance;

public interface ATM
{

	void validateCard();
	void getInfo();

}
