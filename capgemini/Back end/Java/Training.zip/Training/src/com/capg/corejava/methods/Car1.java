package com.capg.corejava.methods;

public class Car1 {
	public  void car1()
	{
		System.out.println("Pass a car to Driver");
	}
	public  void properties ()
	{
		String name = "Nano";
			
	}
}


