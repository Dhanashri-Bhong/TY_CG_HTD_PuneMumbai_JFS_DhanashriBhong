package com.capg.corejava.basics;

public class UnaryOperators {
	public static void main(String[] args) {
		int i =10;
		int j = 20;
		i = ++i;
		System.out.println(i);
		j = j++;
		System.out.println(j);
		i = --i;
		System.out.println(i);
		j = j--;
		System.out.println(j);
	}

}
