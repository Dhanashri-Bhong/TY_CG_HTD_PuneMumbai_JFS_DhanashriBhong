package com.capg.corejava.methods;

public class Lays implements Chips  {

	@Override
	public void open() {
		System.out.println("I am opening Lays");
		
	}

	@Override
	public void eat() {
		System.out.println("I am eating Lays");
		
	}
	

}
