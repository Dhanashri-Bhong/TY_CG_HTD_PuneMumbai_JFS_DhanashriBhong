package com.capg.corejava.inheritance;

public class Car1 {

}
