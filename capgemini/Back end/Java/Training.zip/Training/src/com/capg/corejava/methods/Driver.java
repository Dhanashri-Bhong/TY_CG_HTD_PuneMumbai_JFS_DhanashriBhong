package com.capg.corejava.methods;

public class Driver extends Car1 {
	public  void driver()
	{
	System.out.println("Get a car From Driver");	
	}
public static void main(String[] args) {
	Driver obj = new Driver ();
	obj.car1();
	obj.driver();
	obj.properties();

	
}

}
