package com.capg.corejava.inheritance;

public class Machine 
{
	void slot(ATM a)
	{
		a.validateCard();
		a.getInfo();
		
	}
}
