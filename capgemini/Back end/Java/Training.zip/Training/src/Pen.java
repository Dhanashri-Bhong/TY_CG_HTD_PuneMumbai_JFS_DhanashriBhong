
public class Pen
{
       int cost;
    public  void  write()
  {
	  System.out.println("this is a write () method"); 
  }
}
