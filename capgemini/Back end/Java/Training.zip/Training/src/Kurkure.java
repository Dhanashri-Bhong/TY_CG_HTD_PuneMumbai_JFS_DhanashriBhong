import com.capg.corejava.methods.Chips;

public class Kurkure implements Chips {

	@Override
	public void open() {
		System.out.println("I am opening Kurkure");

	}

	@Override
	public void eat() {
		System.out.println("I am eating Kurkure");

	}

}
