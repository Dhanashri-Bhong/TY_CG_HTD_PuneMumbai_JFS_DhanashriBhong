import com.capg.corejava.methods.Chips;

public class Baby {

	void recieve(Chips c)
	{
		c.open();
		c.eat();
	}
}
