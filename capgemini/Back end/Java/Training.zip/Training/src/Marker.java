
public class Marker
{
    double size;
   public void color()
{
	System.out.println("this is a black color");
}
}
