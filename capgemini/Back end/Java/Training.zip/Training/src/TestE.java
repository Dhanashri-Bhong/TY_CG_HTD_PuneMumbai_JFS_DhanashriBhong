
public class TestE
{
public static void main(String[] args) 
{
	double age = 24.9;
	int t = (int) age;
	System.out.println("t is "+t);
}
}
