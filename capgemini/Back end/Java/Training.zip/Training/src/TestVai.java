import java.util.Scanner;

public class TestVai {

	public static void main(String[] args) {

		try( Scanner sc = new Scanner(System.in))
		{
			System.out.println(" enter the age");
			int age = sc.nextInt();
			System.out.println("age is " + age);
		}
		
		
	}

}
