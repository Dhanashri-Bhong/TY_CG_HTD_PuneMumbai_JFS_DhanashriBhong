
public class TestB
{
public static void main(String[] args)
{
	Kurkure k = new Kurkure();
	Bingo d = new Bingo();
	Baby b = new Baby();
	b.recieve(d);
}
}
