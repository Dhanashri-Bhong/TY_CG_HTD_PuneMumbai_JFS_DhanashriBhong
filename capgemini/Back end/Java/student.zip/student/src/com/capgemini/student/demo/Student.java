package com.capgemini.student.demo;

public class Student {
	
	String name;
	int id;
	double percentage;
	char gender;
	
	
	public Student()
	{
		
	}
	public Student(String name, int id, double percentage, char gender) {
		super();
		this.name = name;
		this.id = id;
		this.percentage = percentage;
		this.gender = gender;
	}

}
