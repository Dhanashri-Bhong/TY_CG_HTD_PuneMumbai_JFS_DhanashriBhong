package com.capgemini.student;

public class Student {
	String name;
	int id;
	double percentage;
	char gender;
	public Student(String name, int id, double percentage, char gender) {
		super();
		this.name = name;
		this.id = id;
		this.percentage = percentage;
		this.gender = gender;
	}
	
}
