package com.capgemini.student;

import java.util.ArrayList;


public class StudentTest {

	public static void main(String[] args) {
		  
		  Student s1 = new Student ("Vaibhav",  1, 89.23,'M');
		  Student s2 = new Student ("Dhanu"  ,  2, 59.23,'F');
		  Student s3 = new Student ("Chikku",   3, 9.23,'M');
		  Student s4 = new Student ("Gayatri",  4, 69.23,'F');
		  Student s5 = new Student ("Abhay",    5, 19.23,'M');
		  Student s6 = new Student ("Simran",   6, 29.23 ,'F');
		  Student s7 = new Student ("NAbila" ,  7, 49.23, 'F');
		  Student s8 = new Student ("Salman",   8, 23.23, 'M');
		  
		  
		  
		  ArrayList<Student> al1 = new ArrayList<Student>();
		  al1.add(s1);
		  al1.add(s2);
		  al1.add(s3);
		  al1.add(s4);
		  al1.add(s5);
		  al1.add(s6);
		  al1.add(s7);
		  al1.add(s8);
		  StudentHelper h = new StudentHelper();

h.displayTopper(al1);   
		  
	}

}
