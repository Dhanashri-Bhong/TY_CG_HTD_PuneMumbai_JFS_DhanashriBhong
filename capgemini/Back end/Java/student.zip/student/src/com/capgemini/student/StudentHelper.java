package com.capgemini.student;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;


public class StudentHelper {

	void displayPassed(ArrayList<Student> al1)
	{
		List<Student> li = al1.stream().filter(i-> i.percentage >=35).collect(Collectors.toList());

		Iterator <Student> it = li.iterator();
		while ( it.hasNext())
		{
			Student s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.percentage);
			System.out.println("Gender is : "+ s.gender);
			System.out.println( "***************************************************");

		}
	}

	void displayFailed(ArrayList<Student> al1)
	{
		List<Student> li = al1.stream().filter(i-> i.percentage <35).collect(Collectors.toList());

		Iterator <Student> it = li.iterator();
		while ( it.hasNext())
		{
			Student s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.percentage);
			System.out.println("Gender is : "+ s.gender);
			System.out.println( "***************************************************");

		}

	}

	void displayPassedG(ArrayList<Student> al1 , char g)
	{
		List<Student> li = al1.stream().filter(i->( i.percentage >=35 && i.gender==g)).collect(Collectors.toList());

		Iterator <Student> it = li.iterator();
		while ( it.hasNext())
		{
			Student s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.percentage);
			System.out.println("Gender is : "+ s.gender);
			System.out.println( "***************************************************");

		}

	}
	
	void displayFailG(ArrayList<Student> al1 , char g)
	{
		List<Student> li = al1.stream().filter(i->( i.percentage <35 && i.gender==g)).collect(Collectors.toList());

		Iterator <Student> it = li.iterator();
		while ( it.hasNext())
		{
			Student s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.percentage);
			System.out.println("Gender is : "+ s.gender);
			System.out.println( "***************************************************");

		}
}
	
	
	Comparator<Student> comp = (o1 , o2)->
	{
Double i = o1.percentage;
Double j = o2.percentage;
return i.compareTo(j);

	};
	void displayTopper(ArrayList<Student> al1)
	{
		Student s  = al1.stream().max(comp).get();
		
		System.out.println("Id is " + s.id);
		System.out.println("Name is " + s.name);
		System.out.println("Salary is " + s.percentage);
		System.out.println("Gender is : "+ s.gender);
		System.out.println( "***************************************************");
	}

	
	
	void displayAll(ArrayList<Student> al1)
	{

		Iterator <Student> it = al1.iterator();
		while ( it.hasNext())
		{
			Student s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.percentage);
			System.out.println("Gender is : "+ s.gender);
			System.out.println( "***************************************************");

		}

	}

}
