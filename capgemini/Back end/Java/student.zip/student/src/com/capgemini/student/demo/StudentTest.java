package com.capgemini.student.demo;

import java.util.ArrayList;
import java.util.function.Predicate;


public class StudentTest {


	public static void main(String[] args) {

		Student s1 = new Student ("Vaibhav",  1, 89.23,'M');
		Student s2 = new Student ("Dhanu"  ,  2, 59.23,'F');
		Student s3 = new Student ("Chikku",   3, 9.23,'M');
		Student s4 = new Student ("Gayatri",  4, 69.23,'F');
		Student s5 = new Student ("Abhay",    5, 19.23,'M');
		Student s6 = new Student ("Simran",   6, 29.23 ,'F');
		Student s7 = new Student ("NAbila" ,  7, 49.23, 'F');
		Student s8 = new Student ("Salman",   8, 23.23, 'M');	
		
		Predicate<Student> p = i-> {

			if ( i.percentage<35)
			{
				return true;
			}
			else 
			{
				return false;
			}
		};

		boolean res = p.test(s7);
		System.out.println(" Result is :" +res);

	}
}
