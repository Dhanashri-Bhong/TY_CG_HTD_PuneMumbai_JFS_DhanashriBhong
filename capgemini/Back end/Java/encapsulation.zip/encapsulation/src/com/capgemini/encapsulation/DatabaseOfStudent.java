package com.capgemini.encapsulation;

public class DatabaseOfStudent {

	
	void receive (Student t)
	{
		System.out.println("_____Data of Student is________");
		System.out.println(" Id is :" +t.getId());
		System.out.println(" NAme is :" + t.getName());
		System.out.println(" HEight is :" + t.getHeight());

		
	}
	
	
	
	
	
}
