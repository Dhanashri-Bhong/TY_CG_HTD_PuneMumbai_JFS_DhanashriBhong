package com.capgemini.encapsulation;

public class DatabaseOfEmployee {

	void recieve ( Employee e )
	{
		System.out.println("************* Details of employeee************");
		System.out.println(" NAme is " + e.getName());
		System.out.println(" Id is " + e.getId());
		System.out.println(" Salary is " + e.getSalary());
		System.out.println(" Role is " + e.getRole());
		System.out.println(" Department is " + e.getDepartment());

	}
	
	
}
