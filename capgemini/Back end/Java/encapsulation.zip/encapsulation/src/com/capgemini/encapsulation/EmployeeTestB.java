package com.capgemini.encapsulation;

public class EmployeeTestB {

	public static void main(String[] args) {

		Employee d = new Employee();
		d.setName("dhanashri");	
		d.setId(20);
		d.setSalary(52000.36);
		d.setRole("Project Managers");
		d.setDepartment("development");
		


		DatabaseOfEmployee s = new DatabaseOfEmployee();
		s.recieve(d);
		
	}

}
