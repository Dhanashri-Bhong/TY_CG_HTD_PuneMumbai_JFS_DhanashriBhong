package com.capgemini.encapsulation;

public class BusTestD {

	public static void main(String[] args) {

		BusImmutable b = new BusImmutable ( "Purple"  , 25);
		
		System.out.println(" Name is :" +b.getName());
		System.out.println(" Seat no is " +b.getSeats());
		
		
	}

}
