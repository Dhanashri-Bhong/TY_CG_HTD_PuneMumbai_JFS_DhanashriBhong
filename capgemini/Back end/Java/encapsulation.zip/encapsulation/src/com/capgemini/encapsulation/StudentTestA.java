package com.capgemini.encapsulation;

public class StudentTestA {

	public static void main(String[] args) {

		
		Student s = new Student ();
		s.setId(20);
		s.setName("vaibhav");
		s.setHeight(171.65);
		
		
		DatabaseOfStudent db = new DatabaseOfStudent();
		db.receive(s);
		
				
	}

}
