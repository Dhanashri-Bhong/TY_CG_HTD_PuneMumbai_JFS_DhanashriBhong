package com.capgemini.encapsulation;

public final class BusImmutable {
	
	
    private final String name; 
	private  final int seats;
	
	public BusImmutable(String name, int seats) {
		super();
		this.name = name;
		this.seats = seats;
	}

	public String getName() {
		return name;
	}

	public int getSeats() {
		return seats;
	}
	
	
}
