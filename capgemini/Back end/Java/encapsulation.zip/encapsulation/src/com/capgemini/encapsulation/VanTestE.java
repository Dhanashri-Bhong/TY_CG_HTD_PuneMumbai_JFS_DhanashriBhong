package com.capgemini.encapsulation;

public class VanTestE {

	public static void main(String[] args) {

		Van v = Van.getVan();
		System.out.println(v);
		
		Van t = Van.getVan();
		System.out.println(t);

		
		Van s = Van.getVan();
		System.out.println(s);
		
	}

}
