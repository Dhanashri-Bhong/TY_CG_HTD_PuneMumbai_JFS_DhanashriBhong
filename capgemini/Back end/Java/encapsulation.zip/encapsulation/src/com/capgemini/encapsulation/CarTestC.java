package com.capgemini.encapsulation;

public class CarTestC {

	public static void main(String[] args) {

		Car c = new Car(200 , " Benz");
		System.out.println(" Name is " + c.getName());
		System.out.println(" Cost is  "+ c.getCost());
		
		
	}

}
