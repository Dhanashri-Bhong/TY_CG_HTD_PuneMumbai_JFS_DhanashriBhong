package com.capgemini.arraylist;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.capgemini.stream.Employee;


public class EmployeeSort {

	public static void main(String[] args) {

		
		ArrayList<Employee> al = new ArrayList<Employee>();
		al.add(new Employee(1,"VAibhav",5.9));
		al.add(new Employee(2,"Dhanashri",5.4));

		Comparator<Employee> cn = (o1,o2)-> o1.name.compareTo(o2.name);

		List<Employee> li = al.stream().sorted(cn).collect(Collectors.toList());
		
		Iterator <Employee> it = li.iterator();
		
		while ( it.hasNext())
		{
			Employee s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.height);
			System.out.println( "***************************************************");

		}

	}

}
