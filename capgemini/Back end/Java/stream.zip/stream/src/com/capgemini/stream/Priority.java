package com.capgemini.stream;

import java.util.Iterator;
import java.util.PriorityQueue;

public class Priority {

	public static void main(String[] args) {

		PriorityQueue<Integer> p = new PriorityQueue<Integer>();
		
		p.add(18);
		p.add(15);
		p.add(9);
		p.add(10);
		
		System.out.println("Before......");
		System.out.println(p);
		
		Iterator<Integer> it = p.iterator();
		System.out.println("After......");

		while (it.hasNext())
		{
			
			Integer r = it.next();
			System.out.println(r);
		}

		
	}

}
