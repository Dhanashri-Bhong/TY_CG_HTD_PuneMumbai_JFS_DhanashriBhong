package com.capgemini.arraylist;

import java.util.HashSet;
import java.util.Set;

public class Class {

	
	public static void main(String[] args) {
		
		Set n = new HashSet<String>();
		n.add("d");
		n.add(5);
		System.out.println(n);
	}
}
