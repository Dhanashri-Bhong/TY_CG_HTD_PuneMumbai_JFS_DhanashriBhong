package com.capgemini.modifiers.family;

public class Father {
     private void ATM()
     {
    	 System.out.println(" i am atm () method");
     }
     void car()
     {
    	 System.out.println(" i am car () method");
     }
     protected  void bike()
     {
    	 System.out.println("i am bike () method");
     }
     public void cycle()
     {
    	 System.out.println("i am cycle() mthod");
    	 
     }
     void use()
     {
    	ATM();
    	car();
    	bike();
    	cycle();
     }
}
