package com.capgemini.studentapp.qspiders;
import java.io.File;
import java.util.*;
public class TestC {

public static void main(String[] args) {
	File f = new File("Dhanashri.text");
	
	
	String s = new String ("Vaibhav");
	Exception e = new Exception ();

	
}	

}
