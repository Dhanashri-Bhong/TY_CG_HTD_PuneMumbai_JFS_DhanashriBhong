package com.capgemini.studentapp.jspiders;

public class Remote {

	public static int sum = 100;
	public int count = 200;
	
	public static void on ()
	{
		System.out.println("i am on () method");
	}
	public void off()
	{
		System.out.println("i am off () method");
	}
	
}
