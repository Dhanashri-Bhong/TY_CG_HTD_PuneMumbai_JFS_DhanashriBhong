package com.capgemini.studentapp.qspiders;

import com.capgemini.studentapp.jspiders.Remote;

public class TestD {

	public static void main(String[] args) {

		Remote.on();
		System.out.println(Remote.sum);
	}

}
