package com.capgemini.studentapp.qspiders;
import static com.capgemini.studentapp.jspiders.Remote.*;
public class TestE {

	public static void main(String[] args) {
		
		on();
		System.out.println(sum);
	}
}
