package com.capgemini.maps;

public class Student {

	String name;
	int id;
	double percentage;
	public Student(String name, int id, double percentage) {
		super();
		this.name = name;
		this.id = id;
		this.percentage = percentage;
	}
	
	
	
	
	
	
}
