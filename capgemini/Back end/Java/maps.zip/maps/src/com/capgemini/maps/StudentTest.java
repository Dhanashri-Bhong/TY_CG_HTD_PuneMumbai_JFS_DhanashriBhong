package com.capgemini.maps;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;


public class StudentTest {

	public static void main(String[] args) {

		
  Student s1 = new Student ("Vaibhav",1, 89.23);
  Student s2 = new Student ("Dhanu",2, 59.23);
  Student s3 = new Student ("Chikku",3, 99.23);
  Student s4 = new Student ("Gayatri",4, 69.23);
  Student s5 = new Student ("Abhay",5, 19.23);
  Student s6 = new Student ("Simran",6, 39.23);
  Student s7 = new Student ("NAbila",7, 49.23);
  Student s8 = new Student ("Salman",8, 59.23);
  Student s9 = new Student ("Tina",9, 29.23);
  
  ArrayList<Student> al1 = new ArrayList<Student>(); 
  al1.add(s1);
  al1.add(s2);
  al1.add(s3);
  
  ArrayList<Student> al2 = new ArrayList<Student>(); 
  al2.add(s4);
  al2.add(s5);
  
  ArrayList<Student> al3 = new ArrayList<Student>(); 
  al3.add(s6);
  al3.add(s7);
  al3.add(s8);
  al3.add(s9);

LinkedHashMap<String , ArrayList<Student>> hm = new LinkedHashMap<String , ArrayList<Student>>();

  hm.put("First",al1);
  hm.put("Second",al2);
  hm.put("Third",al3);

  ArrayList<Student> al = hm.get("Third");
  Iterator <Student> it = al.iterator();
	
	while ( it.hasNext())
	{
		Student s = it.next();
		System.out.println("Id is " + s.id);
		System.out.println("Name is " + s.name);
		System.out.println("Salary is " + s.percentage);
		System.out.println( "***************************************************");

	}
		
	}

}
