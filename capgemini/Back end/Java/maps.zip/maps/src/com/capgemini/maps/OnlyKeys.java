package com.capgemini.maps;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Set;

public class OnlyKeys {
	public static void main(String[] args) {
		LinkedHashMap<String , Integer> hm = new LinkedHashMap<String , Integer>();

		hm.put("Ondu", 1);
		hm.put("Idhu", 5);
		hm.put("Hathu", 10);
		hm.put("Eredu", 2);

		Set<String> s = hm.keySet();
		for ( String r : s )
		{
			System.out.println(r);
		}

		System.out.println("*********************");
		Collection < Integer> col = hm.values();
		for ( Integer r : col )
		{
			System.out.println(r);
		}
		
		boolean res = hm.containsKey("Idu");
		System.out.println("result is :"+res);
		
		Integer res2 = hm.get("dhanu");
		System.out.println(" result is : "+res2);
		
		

	}	

}
