package com.capgemini.sorting.set;

import java.util.HashSet;
import java.util.Iterator;

public class TestString {

	public static void main(String[] args) {

		HashSet<String> hs = new HashSet<String>();
		hs.add("vaibhav");
		hs.add("DHanu");
		hs.add("Chikku");
		hs.add("Laddu");
		hs.add("Simmu");
		hs.add("Pagal");
		hs.add("madd");

		
		System.out.println("*****************************");
		for ( String r : hs)
		{
			System.out.println(r);
		}
		
		System.out.println("************************************");
		
		Iterator it = hs.iterator();
		
		while ( it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
	}

}
