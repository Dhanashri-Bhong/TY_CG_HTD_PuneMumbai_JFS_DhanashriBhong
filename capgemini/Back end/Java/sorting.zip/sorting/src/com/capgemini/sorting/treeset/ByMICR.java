package com.capgemini.sorting.treeset;

import java.util.Comparator;

public class ByMICR implements Comparator<Bank> {

	@Override
	public int compare(Bank o1, Bank o2) {
		
		if (o1.micr>o2.micr)
		{
			return 1;
		}
		else if (o1.micr<o2.micr)
		{
			return -1;
			
		}
		else
		{
		return 0;
		}
	
	}

	
	
}
