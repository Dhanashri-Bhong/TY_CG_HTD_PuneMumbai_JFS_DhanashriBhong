package com.capgemini.sorting.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetDouble {

	public static void main(String[] args) {

		
		LinkedHashSet<Double> hs = new LinkedHashSet<Double>();
		hs.add(14.27);
		hs.add(27.14);
		hs.add(22.27);
		hs.add(97.97);
		hs.add(null);
		
		System.out.println("*****************************");
		for ( Double r : hs)
		{
			System.out.println(r);
		}
		
		System.out.println("************************************");
		
		Iterator it = hs.iterator();
		
		while ( it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
	}

}
