package com.capgemini.sorting.set;

import java.util.TreeSet;
import java.util.Iterator;

public class LinkedTreeSet {

	public static void main(String[] args) {
		
		TreeSet ts = new TreeSet();
		ts.add(14);
		ts.add(27);
		ts.add(22);
		ts.add(26);
		//ts.add(null);// it throws null pointer exception.
		
		System.out.println("*****************************");
		for ( Object r : ts)
		{
			System.out.println(r);
		}
		
		System.out.println("************************************");
		
		Iterator it = ts.iterator();
		
		while ( it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
	}

}
