package com.capgemini.sorting.set;

import java.util.HashSet;
import java.util.Iterator;

import com.capgemini.sorting.Student;

public class EmployeeTest {

	public static void main(String[] args) {

		HashSet<Employee> hs = new HashSet<Employee>();
		
		
		Employee e1 = new Employee ( 1," Dhanu" , 200000);
		Employee e2 = new Employee ( 2," vaibhav" , 20000);
		Employee e3 = new Employee ( 3," chikku" , 250000);
		Employee e4 = new Employee ( 4," laddu" , 290000);
		Employee e5 = new Employee ( 2," vaibhav" , 20000);

		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		hs.add(e4);
		hs.add(e5);
		
		Iterator <Employee> it = hs.iterator();
		
		while ( it.hasNext())
		{
			Employee s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.salary);
			System.out.println( "***************************************************");

		}
		

		
	}

}
