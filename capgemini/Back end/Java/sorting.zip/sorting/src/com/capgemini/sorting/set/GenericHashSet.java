package com.capgemini.sorting.set;

import java.util.HashSet;
import java.util.Iterator;

public class GenericHashSet {

	public static void main(String[] args) {

		HashSet hs = new HashSet();
		hs.add(14);
		hs.add('V');
		hs.add(2.4);
		hs.add("Dhanu");
		hs.add('V');
		hs.add(null);
		hs.add(null);
		
		
		System.out.println("*************Using for each loop****************");
		for ( Object r : hs)
		{
			System.out.println(r);
		}
		
		
				
	}

	}

