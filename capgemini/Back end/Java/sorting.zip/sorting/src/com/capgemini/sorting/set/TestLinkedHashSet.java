package com.capgemini.sorting.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class TestLinkedHashSet {

	public static void main(String[] args) {

		LinkedHashSet hs = new LinkedHashSet();
		hs.add(14);
		hs.add('V');
		hs.add(2.4);
		hs.add("Dhanu");
		
		System.out.println("*****************************");
		for ( Object r : hs)
		{
			System.out.println(r);
		}
		
		System.out.println("************************************");
		
		Iterator it = hs.iterator();
		
		while ( it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
	}

}
