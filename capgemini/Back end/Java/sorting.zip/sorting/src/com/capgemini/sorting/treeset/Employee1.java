package com.capgemini.sorting.treeset;

import java.util.Iterator;
import java.util.TreeSet;

import com.capgemini.sorting.set.Employee;

public class Employee1 {

	public static void main(String[] args) {
		
		TreeSet<Employee> ts = new TreeSet<Employee>();
		
		Employee e1 = new Employee ( 1," Dhanu" , 200000);
		Employee e2 = new Employee ( 2," vaibhav" , 20000);
		Employee e3 = new Employee ( 3," chikku" , 250000);
		Employee e4 = new Employee ( 4," laddu" , 290000);

		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);
	
		

		Iterator <Employee> it = ts.iterator();
		
		while ( it.hasNext())
		{
			Employee s = it.next();
			System.out.println("Id is " + s.id);
			System.out.println("Name is " + s.name);
			System.out.println("Salary is " + s.salary);
			System.out.println( "***************************************************");

		}
	}
	
}
