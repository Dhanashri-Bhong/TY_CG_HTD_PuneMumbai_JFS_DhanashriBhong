package com.capgemini.sorting;

public class Student implements Comparable<Student> {

		public int id;
		public String name;
		public double percentage;
		
		public Student(int id, String name, double percentage) 
		{
			super();
			this.id = id;
			this.name = name;
			this.percentage = percentage;
		}
		
	/*	@Override
		public int compareTo(Student s)
		 {
			
			Double k = this.percentage;
			Double t = s.percentage;
			 return k.compareTo(t);
		
			
		}*/
		
		@Override
		public int compareTo(Student s)
		 {
			
			Integer k = this.id;
			Integer t = s.id;
			 return k.compareTo(t);
		
			
		}
		
		
		// logic to sort Student id
	//	@Override
	/*	public int compareTo(Student s) {
		
			if (this.id > s.id)
			{
				return 1;
			}
			else if ( this.id < s.id)
			{
				return -1;
			}
			else 
			{
				return 0;
			}
			
		}*/
		
		// logic to sort Student Percentage
	/*	@Override
		public int compareTo(Student s) {
		
			if (this.percentage > s.percentage)
			{
				return 1;
			}
			else if ( this.percentage < s.percentage)
			{
				return -1;
			}
			else 
			{
				return 0;
			}
			
		}*/
		
		
		//logic to sorting name 
		/*@Override
		public int compareTo(Student s)
		 {
			
			String k = this.name;
			String t = s.name;
			 int res = k.compareTo(t);
			 return res;
		
			
			
		}*/

		/*@Override
		public int compareTo(Student s)
		 {
			
			// return   this.name.compareTo(s.name);	//ascending order
			 return   this.name.compareTo(s.name)* -1;	//descending order	

		}*/
	}

	
	

