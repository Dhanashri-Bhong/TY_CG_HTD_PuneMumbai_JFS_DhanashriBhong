package com.capgemini.sorting.treeset;

import java.util.Iterator;
import java.util.TreeSet;


public class BankTest {

	
public static void main(String[] args) {
		
	     ById comp = new ById();
	     ByName comp1 = new ByName();
	     ByMICR comp2 = new ByMICR();

	     
		TreeSet<Bank> ts = new TreeSet<Bank>(comp2);
		
		Bank e1 = new Bank ( 11121," SBI PUNE" , 200000l);
		Bank e2 = new Bank (97142," UKO YAVATMAL" , 202000l);
		Bank e3 = new Bank ( 2707," BANK OF INDIA" , 250000l);
		Bank e4 = new Bank ( 1427," AXIS BANK" , 290000l);

		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);
	
		

		Iterator <Bank> it = ts.iterator();
		
		while ( it.hasNext())
		{
			Bank s = it.next();
			System.out.println("Pin is " + s.pin);
			System.out.println("Name is " + s.name);
			System.out.println("MICR is " + s.micr);
			System.out.println( "***************************************************");

		}
	}
}
