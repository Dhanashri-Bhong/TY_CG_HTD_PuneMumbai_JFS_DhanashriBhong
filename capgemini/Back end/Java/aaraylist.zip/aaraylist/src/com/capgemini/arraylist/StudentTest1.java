package com.capgemini.arraylist;

import java.util.ArrayList;

public class StudentTest1 {

	public static void main(String[] args) {

			ArrayList<Student> als  = new ArrayList<Student> ();
			
			Student s1 = new Student(1,"Dhanashri",83.55);
			Student s2 = new Student(2,"Simran",35.55);
			Student s3 = new Student(3,"Shubhangi",61.55);
			Student s4 = new Student(4,"Shruti",25.55);
			Student s5 = new Student(5,"Nabila",93.55);

			als.add(s1);
			als.add(s2);
			als.add(s3);
			als.add(s4);
			als.add(s5);
  
	Helper h = new Helper();
	h.display(als);
	System.out.println("*********************");
	h.onlyPass(als);
	System.out.println("**************************");
	h.distinct(als);
			
		}

		
		
	}


