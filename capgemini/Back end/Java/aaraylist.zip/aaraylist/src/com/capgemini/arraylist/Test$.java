package com.capgemini.arraylist;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

public class Test$ {

	public static void main(String[] args) {

		
		LinkedList<Double> li = new LinkedList<Double>();
		li.add(2.3);
		li.add(2.69);
		li.add(89.90);
		
		Collections.sort(li);
		System.out.println(li);
		
		

		
	}

}
