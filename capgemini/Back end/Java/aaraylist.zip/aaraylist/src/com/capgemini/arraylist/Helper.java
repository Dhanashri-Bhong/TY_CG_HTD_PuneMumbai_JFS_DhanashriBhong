package com.capgemini.arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class Helper {
	void display(ArrayList<Student> k)
	{
		for (Student e : k)
		{
			System.out.println(" id is :" +e.id);
			System.out.println(" name is :" +e.name);
			System.out.println(" percentage is :" +e.percentage);
			System.out.println("________________________________");

		}

	}

	void onlyPass(ArrayList<Student> u)
	{

		Iterator<Student> it = u.iterator();


		while ( it.hasNext())
		{
			Student v = it.next();
			if (v.percentage >=35)
			{
				System.out.println("Id is :" +v.id );
				System.out.println("Name is :" +v.name );
				System.out.println("Percentage is :" +v.percentage );

			}


		}

	}
	

	void distinct(ArrayList<Student> u)
	{

		Iterator<Student> it = u.iterator();


		while ( it.hasNext())
		{
			Student v = it.next();
			if (v.percentage >=75)
			{
				System.out.println("Id is :" +v.id );
				System.out.println("Name is :" +v.name );
				System.out.println("Percentage is :" +v.percentage );

			}


		}

	}

}