package com.capgemini.arraylist;// 

import java.util.ArrayList;

public class Test2 {
	public static void main(String[] args) {
		
	
	ArrayList<Double> al = new ArrayList<Double>();
	
	al.add(3.6);
	al.add(2.4);
	al.add(4.7);
	al.add(1.6);

	
	ArrayList<Double> bl = new ArrayList<Double>();
	bl.add(2.3);
	bl.add(8.5);
	
	
	
	
	System.out.println("Before ----->" +al);
	al.add(5.4);
	Double res = al.set(2, 6.4);
	
	Double ll = al.remove(3);
	
	boolean bb = al.remove(12.5);
	
	System.out.println(" Return a object is : " +res);
	System.out.println("Removed object is " + ll);
	System.out.println( " Result is : " + bb);
	
	al.addAll(bl);
	
	System.out.println(" After ------->" +al);
	
	boolean b = al.containsAll(bl);
	System.out.println("Does it contain all " +b);
	
	al.removeAll(bl);
	System.out.println("ArrayList is " +al);
	}

}
