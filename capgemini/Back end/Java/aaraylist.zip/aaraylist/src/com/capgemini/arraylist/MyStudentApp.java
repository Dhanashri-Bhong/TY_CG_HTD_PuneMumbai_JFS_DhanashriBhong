package com.capgemini.arraylist;

import java.util.ArrayList;
import java.util.Scanner;

public class MyStudentApp {

	ArrayList<Student> al = new ArrayList<Student>();
	Scanner sc = new Scanner ( System.in);
	
	void addStudent()
	{
		System.out.println(" Enter the Name");
		String name = sc.nextLine();
		
		System.out.println(" Enter the id");
		int id = sc.nextInt();
		
		
		System.out.println();
		String per = sc.nextLine();
		
		
	}
	
	
	
}


