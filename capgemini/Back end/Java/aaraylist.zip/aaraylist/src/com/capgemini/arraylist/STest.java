package com.capgemini.arraylist;

import java.util.Scanner;

public class STest {

	public static void main(String[] args) {

		
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter the name");
			int opt = sc.nextInt();
			
		}
		
	}

}
