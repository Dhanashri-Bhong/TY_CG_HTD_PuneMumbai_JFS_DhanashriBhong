package com.capgemini.arraylist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class CharTest {

	public static void main(String[] args) {

		
		
		ArrayList al = new ArrayList();
		al.add('A');
		al.add('P');
		al.add('P');
		al.add('L');
		al.add('E');
		Collections.sort(al);
		System.out.println(al);


	}

}
