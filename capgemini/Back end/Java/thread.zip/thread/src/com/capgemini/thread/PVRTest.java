package com.capgemini.thread;

public class PVRTest {

	public static void main(String[] args) {

		
		PVR a = new PVR();
		
		
		System.out.println(" Start.....");
		Paytm t1 = new Paytm (a);
		t1.start();
		
		/*try 
		{
			t1.join();
		} 
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		*/
		
		Paytm t2 = new Paytm (a);
		t2.start();
		System.out.println(" End.......");
		
		try
		{
			Thread.sleep(3000);
		} 
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		a.leaveMe();

	}

}
