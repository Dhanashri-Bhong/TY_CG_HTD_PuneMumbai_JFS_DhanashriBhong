package com.capgemini.java.currency;

import java.util.Currency;
import java.util.Set;

public class CurrencyExample {

	public static void main(String[] args) {

		Currency currencyCode1 = Currency.getInstance("INR");
		Currency currencyCode2 = Currency.getInstance("USD");
		Currency currencyCode3 = Currency.getInstance("EUR");
		Currency currencyCode4 = Currency.getInstance("GTQ");

		String currencyCode1Symbol = currencyCode1.getSymbol();
		String currencyCode2Symbol = currencyCode2.getSymbol();
		String currencyCode3Symbol = currencyCode3.getSymbol();
		String currencyCode4Symbol = currencyCode4.getSymbol();

		System.out.println(" Symbol for INR is : " + currencyCode1Symbol);
		System.out.println(" Symbol for UED is : " + currencyCode2Symbol);
		System.out.println(" Symbol for EUR is : " + currencyCode3Symbol);
		System.out.println(" Symbol for GTQ is : " + currencyCode4Symbol);
		System.out.println("***********************************************");

		
		String currencyCode1DisplayName = currencyCode1.getDisplayName();
		String currencyCode2DisplayName = currencyCode2.getDisplayName();
		String currencyCode3DisplayName = currencyCode3.getDisplayName();
		String currencyCode4DisplayName = currencyCode4.getDisplayName();
		
		System.out.println(" Display Name for INR is : " + currencyCode1DisplayName);
		System.out.println(" Display Name for UED is : " + currencyCode2DisplayName);
		System.out.println(" Display Name for EUR is : " + currencyCode3DisplayName);
		System.out.println(" Display Name for GTQ is : " + currencyCode4DisplayName);
		System.out.println("***********************************************");

		
		Set<Currency> currencies = Currency.getAvailableCurrencies();
		System.out.println(currencies);
		System.out.println("-------------------------------------------");
		
		
		int currencyCode1DefaultFraction = currencyCode1.getDefaultFractionDigits();
		int currencyCode2DefaultFraction = currencyCode2.getDefaultFractionDigits();
		int currencyCode3DefaultFraction = currencyCode3.getDefaultFractionDigits();
		int currencyCode4DefaultFraction = currencyCode4.getDefaultFractionDigits();
		
		System.out.println(" Default Fraction Digit for INR is : " + currencyCode1DefaultFraction);
		System.out.println(" Default Fraction Digit for UED is : " + currencyCode2DefaultFraction);
		System.out.println(" Default Fraction Digit for EUR is : " + currencyCode3DefaultFraction);
		System.out.println(" Default Fraction Digitfor GTQ is : " + currencyCode4DefaultFraction);
		System.out.println("***********************************************");
		

		
	}

}
