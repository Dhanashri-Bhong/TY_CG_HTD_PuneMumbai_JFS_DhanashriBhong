package com.capgemini.objectclass.methods;

public class Remote {
  int id;
  String name;
  
  
public Remote(int id, String name)
{
	super();
	this.id = id;
	this.name = name;
}
  
}
