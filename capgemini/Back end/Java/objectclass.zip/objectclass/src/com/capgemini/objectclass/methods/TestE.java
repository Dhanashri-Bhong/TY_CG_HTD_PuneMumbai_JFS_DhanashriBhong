package com.capgemini.objectclass.methods;

public class TestE {

	public static void main(String[] args) {

		
		Student s = new Student( 1,"dhanu",84.36);
		System.out.println(s);
		
		Employee e = new Employee( 6, "vaibhav",95.23 ,'m');
		System.out.println(e);
	}

}
