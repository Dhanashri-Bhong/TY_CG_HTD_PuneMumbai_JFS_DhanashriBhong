package com.capgemini.objectclass.methods;

public class TestA {

	public static void main(String[] args) {

		TestA a = new TestA();
		int v = a.hashCode();
		System.out.println( "address is " +v);
		
	}

}
