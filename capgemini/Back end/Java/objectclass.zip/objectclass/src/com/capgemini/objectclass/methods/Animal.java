package com.capgemini.objectclass.methods;

public class Animal {

	 public int hashCode()
	{
		return 6;
	}
}
