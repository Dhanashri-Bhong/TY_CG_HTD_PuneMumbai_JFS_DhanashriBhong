package com.capgemini.objectclass.methods;

public class Student {
  int id;
  String name;
  double percantage;
  public Student ( int id , String name, double percantage)
  {
	  super();
	  this.id = id;
	  this.name = "Dhanu";
	  this.percantage = percantage;
	  
	  
  }
	
		public String toString()
	{
		return "Name: "+name+", id : "+id+ " , percantage: "+percantage;
		
	}
	
}
