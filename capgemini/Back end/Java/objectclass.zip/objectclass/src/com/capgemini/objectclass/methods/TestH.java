  package com.capgemini.objectclass.methods;

public class TestH {

	public static void main(String[] args)  throws CloneNotSupportedException{

		Marker m  = new Marker ( 1,"dhanu");
		System.out.println("id is " + m.id);
		System.out.println(" Name is " + m.name);
		System.out.println("--------------------------");
		
		
		Object o = m.clone();
		Marker k = (Marker)o;
		System.out.println("id is "+ k.id);
		System.out.println("name is "+ k.name);
		
		
		
		
		
		
		
	}

}
