package com.capgemini.objectclass.methods;

public class TestG {

	public static void main(String[] args) {

		Remote r = new Remote(1,"dhanu");
		System.out.println("id is " + r.id);
		System.out.println(" name is " + r.name);
		Class c = r.getClass();
		
		
		
	}

}
