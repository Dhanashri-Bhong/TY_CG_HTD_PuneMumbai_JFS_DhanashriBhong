package com.capgemini.objectclass.methods;

public class TestF {


public static void main(String[] args) {
	Cow c = new Cow();
	c.name="dhanu";
	c.id=1;
	
	Cow a = new Cow();
	a.name = "vaibhav";
	a.id=3;
	
	Cow e = new Cow();
	e.name="dhanu";
	e.id=1;
	System.out.println(c==a);
	System.out.println(c.equals(e));
}

}
