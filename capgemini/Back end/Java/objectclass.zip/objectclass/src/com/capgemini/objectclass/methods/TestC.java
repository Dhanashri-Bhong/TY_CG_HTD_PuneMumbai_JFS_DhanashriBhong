package com.capgemini.objectclass.methods;

public class TestC {

	public static void main(String[] args) {
    
		
		Animal a = new Animal();
		System.out.println(a);
		int b = a.hashCode();
		System.out.println(b);
		
		
	}

}
