package com.capgemini.objectclass.methods;

public class TestB {

	public static void main(String[] args) {
     
		
		Pen p = new Pen();
		int a = p.hashCode();
		System.out.println(" address is " + a);
		String r = p.toString();
		System.out.println(r);
		System.out.println(p);// return the same value as that of toString()
		
		
		
	}

}
