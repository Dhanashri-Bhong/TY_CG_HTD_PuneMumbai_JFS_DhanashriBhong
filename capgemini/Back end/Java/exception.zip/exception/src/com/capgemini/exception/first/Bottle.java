package com.capgemini.exception.first;

import java.io.File;
import java.io.IOException;

public class Bottle {

	void open () throws IOException, ClassNotFoundException
	{
		File f = new File ("dhanu.txt");
	    f.createNewFile();
		
		
		
		
		
		
	}
	
	
	
	
}
