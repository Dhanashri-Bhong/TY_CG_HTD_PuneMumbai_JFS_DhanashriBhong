package com.capgemini.exception.first;

public class Testc {

	public static void main(String[] args) {

		
		
		
		
	}

}
