package com.capgemini.exception.first;

public class Validator {

	void verify ( int age)
	{
		if ( age < 20)
		{
			throw new InvalidAgeException();
		}
	}
	
	
}
