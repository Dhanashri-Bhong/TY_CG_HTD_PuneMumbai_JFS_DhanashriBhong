package com.capgemini.exception.first;

public class TesrD {

	public static void main(String[] args) {

		System.out.println(" main started");
		Paytm p = new Paytm ();
		try
		{
			p.book();
		}
		catch (ArithmeticException d)
		{
			System.out.println("exception caught the main method");
		}
        
		finally
		{
		System.out.println(" main ended");
		}

	}

}
