package com.capgemini.exception.first;

public class Pencil {

	public static void main(String[] args) {
		System.out.println("main strated");
		
		try
		{
			System.out.println(10/0);
		}

		
		catch ( ArithmeticException e)
		{
			System.out.println("please don't divided by zero");
		}


		System.out.println(" main ends ");
	}

}
