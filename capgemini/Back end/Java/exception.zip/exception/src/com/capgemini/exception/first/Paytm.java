package com.capgemini.exception.first;

public class Paytm {

	void book()
	{
		System.out.println(" book started");
		
		IRCTC i = new IRCTC();
		try {
		i.confirm();
		}

		catch(ArithmeticException h)
		{
			System.out.println("exception caught at book");
			throw h;
		}
		
		
		finally
		{
		
		System.out.println(" book ended");
		}
		
	}
	
	
}
