package com.capgemini.exception.custome;

public class Demo {

	public static void main(String[] args) {

		try
		{
			
		}

		finally
		{
			
		}
		
		
		
	}

}
