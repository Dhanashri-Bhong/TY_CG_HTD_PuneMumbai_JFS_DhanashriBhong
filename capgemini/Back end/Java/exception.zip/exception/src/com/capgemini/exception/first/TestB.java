package com.capgemini.exception.first;

public class TestB {

	public static void main(String[] args) {
     
		System.out.println(" main strated ");
		String s= "dhanu";
		
		
		try
		{
			System.out.println(s.length());
			System.out.println(10/0);
			System.out.println("hii");
			System.out.println("keep smiling");
		}
		catch (ArithmeticException e)
		{
			System.out.println(" don't didvided by zero");
		}
		
		
		System.out.println("main ended");
		
	}

}
