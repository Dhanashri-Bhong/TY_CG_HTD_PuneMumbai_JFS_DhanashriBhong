package com.capgemini.exception.first;

public class TestI {

	public static void main(String[] args) {
Validator v = new Validator();
try
{
	v.verify(15);
	System.out.println(" welcome to pub");
}

catch( InvalidAgeException in)
{
	System.err.println(in.getMessage());
}
		
		
		
		
		
	}

}
