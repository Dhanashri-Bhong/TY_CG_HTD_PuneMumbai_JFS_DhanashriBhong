package com.capgemini.exception.first;

import java.io.IOException;

public class TestG {

	public static void main(String[] args) throws ClassNotFoundException, IOException {

		Bottle b = new Bottle();
		
		b.open();
		
		
		
	}

}
