package com.capgemini.exception.first;

public class TestH {

	public static void main(String[] args) {

		System.out.println(" main started");
		int [] a = new int[3];
		String k = null;
		
		
		try
		{
			System.out.println(k.length());
			System.out.println(10/0);
			System.out.println(a[5]);
		}
		
			
	
		catch(ArrayIndexOutOfBoundsException | NullPointerException | ArithmeticException e)
		{
			e.printStackTrace();
		}
		
		
		System.out.println(" main ended");
	}

}
