package com.capgemini.exception.first;

public class IRCTC {

	void confirm ()
	{
		System.out.println(" confirm started");

		try
		{
			System.out.println(10/0);
		}

		catch (ArithmeticException s)
		{
			System.out.println("exception caught at confirm");
			throw s;
		}
		finally
		{
			System.out.println(" confirm ended");
		}
	}

}
