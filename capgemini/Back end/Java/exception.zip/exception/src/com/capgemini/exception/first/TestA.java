package com.capgemini.exception.first;

public class TestA {

	public static void main(String[] args) {

		System.out.println(" main strated ");
          String s = "vaibhav";
          
		int[] a = new int[3];

		try {
             System.out.println(s.toUpperCase());
			System.out.println(a[1]);
			System.out.println(10/0);
		}
		catch (ArithmeticException c)
		{
			System.out.println("Don't divided by the zero");
		}
		 
		catch ( ArrayIndexOutOfBoundsException d)
		{
			System.out.println(" don't cross the array limit");
		}
		catch (Exception e)
		{
			System.out.println(" sorry somthing wents wrong");
		}


		System.out.println("main ended");
	}

}
