package com.capgemini.exception.first;

import java.io.File;
import java.io.IOException;

public class TestE {

	public static void main(String[] args) {

		System.out.println(" main started");
		File f = new File("G:/simran.txt");
		
		try {
		f.createNewFile();
		
		System.out.println("file is created");
		}
		
		catch (IOException y)
		{
			System.out.println("sorry not able to create the file");
		}
		
		System.out.println("main ended");
		
	}

}
