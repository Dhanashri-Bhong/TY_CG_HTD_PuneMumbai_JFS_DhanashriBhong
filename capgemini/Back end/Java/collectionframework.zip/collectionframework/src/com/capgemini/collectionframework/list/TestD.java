
package com.capgemini.collectionframework.list;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class TestD {


	public static void main(String[] args) {

		ArrayList al = new ArrayList ();

		al.add(14);
		al.add("laddu and chikku");
		al.add(8995);
		al.add('V');
		al.add(14.27);

		ListIterator r = al.listIterator();

		System.out.println(al);


	}

}











