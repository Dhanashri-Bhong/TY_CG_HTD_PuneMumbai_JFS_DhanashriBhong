package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class TestH {

	public static void main(String[] args) {

		
	ArrayList<Double> al = new ArrayList<Double>();
		al.add(2.4);
		al.add(9.6);
		al.add(4.1);
		al.add(3.2);
		
		ListIterator< Double> v = al.listIterator();
		while( v.hasNext())
		{
			Double d = v.next();
			System.out.println(d);
		}
		System.out.println("**** backword ****");
		while ( v.hasPrevious())
		{
			Double f = v.previous();
			System.out.println(f);
		}
		
	}

}
