package com.capgemini.collectionframework.list;

import java.util.Vector;
import java.util.ListIterator;

public class TestVector2 {


	public static void main(String[] args) {


		Vector<Character> al = new Vector<Character>();
		al.add('A');
		al.add('P');
		al.add('P');
		al.add('L');
		al.add('E');



		ListIterator< Character> v = al.listIterator();
		System.out.println("************forword************");
		while( v.hasNext())
		{
			Character d = v.next();
			System.out.println(d);
		}
		System.out.println("**** backword ****");
		while ( v.hasPrevious())
		{
			Character f = v.previous();
			System.out.println(f);

		}


	}

}
