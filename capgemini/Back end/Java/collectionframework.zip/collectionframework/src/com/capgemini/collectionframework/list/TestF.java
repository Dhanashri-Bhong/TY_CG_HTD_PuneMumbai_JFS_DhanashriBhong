package com.capgemini.collectionframework.list;

		import java.util.ArrayList;
		import java.util.Iterator;

		public class TestF {

			public static void main(String[] args) {

				
				ArrayList al = new ArrayList();
				al.add("Raju");
				al.add(19);
				al.add('M');
				al.add(6.14);
				 
				
				Iterator it = al.iterator();


				for ( Object r :al)
				{
					System.out.println(r);
				}
				System.out.println(al);
				
				
			}

		}

	


