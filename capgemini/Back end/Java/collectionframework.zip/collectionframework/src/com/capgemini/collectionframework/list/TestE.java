package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;

public class TestE {

	public static void main(String[] args) {

		
		ArrayList al = new ArrayList();
		al.add("priya");
		al.add(2);
		al.add('F');
		al.add(5.6);
		 
		
		Iterator it = al.iterator();

		System.out.println("************Forword*********************");
		while ( it.hasNext())
		{
		Object m = it.next();
		System.out.println(m);
		}
		System.out.println("___*_*_*___");
		System.out.println(al);
		
		
	}

}
