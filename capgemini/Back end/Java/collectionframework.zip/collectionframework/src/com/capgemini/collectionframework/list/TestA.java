package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestA {

	public static void main(String[] args) {
		
		ArrayList al = new ArrayList ();
		
		al.add(24);
		al.add("chikku");
		al.add(2.9);
		al.add('N');
		
		Object r = al.get(1);
		System.out.println(r);
		
		Object k = al.get(0);
		System.out.println(k);

		Object o = al.get(2);
		System.out.println(o);

		Object p = al.get(3);
		System.out.println(p);
		System.out.println("***********************************");
		
		for ( int i = 0; i<4; i++)
		{
			Object w = al.get(i);
			System.out.println(w);
		}

		
	}

}
