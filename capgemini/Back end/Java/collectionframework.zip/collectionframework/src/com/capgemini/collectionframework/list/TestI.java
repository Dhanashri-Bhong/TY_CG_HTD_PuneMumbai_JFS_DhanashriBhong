package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestI {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		al.add(2.4);
		al.add("Proya");
		al.add(4);
		al.add(3.2);
		System.out.println("****for loop******");
		for ( int i = 0; i<4; i++)
		{
			Object w = al.get(i);
			System.out.println(w);
		}
		
		System.out.println("************for each loop************");

		for ( Object r :al)
		{
			System.out.println(r);
		}
		
		System.out.println("********ListIterator************");

		ListIterator< Double> v = al.listIterator();
		while( v.hasNext())
		{
			Double d = v.next();
			System.out.println(d);
		}
		System.out.println("**** backword ****");
		while ( v.hasPrevious())
		{
			Double f = v.previous();
			System.out.println(f);
		}
		
	}

}
