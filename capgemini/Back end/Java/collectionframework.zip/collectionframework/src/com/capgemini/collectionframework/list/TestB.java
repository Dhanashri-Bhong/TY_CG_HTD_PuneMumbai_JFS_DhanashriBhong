package com.capgemini.collectionframework.list;
import java.util.ArrayList;
import java.util.Iterator;

public class TestB {


	public static void main(String[] args) {

		ArrayList al = new ArrayList ();

		al.add(27);
		al.add("laddu");
		al.add(89);
		al.add('V');
		al.add(14.27);
		
		Iterator it = al.iterator();
		while ( it.hasNext())
		{
		Object v = it.next();
		System.out.println(v);
		}
		
		System.out.println("**************************");
		System.out.println("***************************************");


	}

}






