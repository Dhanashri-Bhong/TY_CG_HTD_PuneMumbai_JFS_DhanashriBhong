package com.capgemini.collectionframework.list;


		import java.util.ArrayList;
		import java.util.Iterator;
		import java.util.ListIterator;

		public class LInkedString {

			public static void main(String[] args) {

				
			ArrayList<String> al = new ArrayList<String>();
				al.add("Dhanu");
				al.add("Vaibhav");
				al.add("Chikku");
				al.add("Laddu");
				
				ListIterator< String> v = al.listIterator();
				while( v.hasNext())
				{
					String d = v.next();
					System.out.println(d);
				}
				System.out.println("**** backword ****");
				while ( v.hasPrevious())
				{
					String f = v.previous();
					System.out.println(f);
				}
				
			}

		}

	


