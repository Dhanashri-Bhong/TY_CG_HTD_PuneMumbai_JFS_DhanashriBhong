package com.capgemini.collectionframework.list;
import java.util.ArrayList;

public class Dummy {


	public static void main(String[] args) {

		ArrayList al = new ArrayList ();

		al.add(27);
		al.add("laddu");
		al.add(89);
		al.add('V');

		for ( Object r :al)
		{
			System.out.println(r);
		}


	}

}



