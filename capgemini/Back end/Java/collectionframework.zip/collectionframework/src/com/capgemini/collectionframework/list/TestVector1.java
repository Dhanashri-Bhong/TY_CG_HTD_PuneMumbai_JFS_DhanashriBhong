package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestVector1 {

	public static void main(String[] args) {



		ArrayList al = new ArrayList();
		al.add(9.6);
		al.add('M');
		al.add("Dhanu");
		al.add(2);
		System.out.println("****for loop******");
		for ( int i = 0; i<4; i++)
		{
			Object w = al.get(i);
			System.out.println(w);
		}
		

		
	}

}
