package com.capgemini.collectionframework.list;
	import java.util.ArrayList;
	import java.util.Iterator;
import java.util.ListIterator;

	public class TestC {


		public static void main(String[] args) {

			ArrayList al = new ArrayList ();

			al.add(27);
			al.add("laddu");
			al.add(89);
			al.add('V');
			al.add(14.27);
			
			ListIterator r = al.listIterator();
			
			System.out.println("************Forword*********************");
			while ( r.hasNext())
			{
			Object m = r.next();
			System.out.println(m);
			}
			
			System.out.println("*****************Backword**********************");

			while ( r.hasPrevious())
			{
			Object m = r.previous();
			System.out.println(m);
			}


		}

	}








