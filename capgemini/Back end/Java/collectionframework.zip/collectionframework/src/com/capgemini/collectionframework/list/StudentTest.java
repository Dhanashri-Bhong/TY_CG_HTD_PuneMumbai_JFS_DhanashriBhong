 package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class StudentTest {

	public static void main(String[] args) {

		ArrayList<Student> als  = new ArrayList<Student> ();
		 
		Student s1 = new Student(1,"Dhanashri",23.55);
		Student s2 = new Student(2,"Simran",35.55);
		Student s3 = new Student(3,"Shubhangi",11.55);
		Student s4 = new Student(4,"Shruti",25.55);
		Student s5 = new Student(5,"Nabila",13.55);

		als.add(s1);
		als.add(s2);
		als.add(s3);
		als.add(s4);
		als.add(s5);

	
				System.out.println("****for loop******");
				for ( int i = 0; i<6; i++)
				{
					Student s = als.get(i);
					System.out.println("id is : " +s.id);
					System.out.println("name is : " +s.name);
					System.out.println("percentage is : " +s.percentage);

				}
				
				System.out.println("************for each loop************");

				for ( Student s :als)
				{
					System.out.println("id is : " +s.id);
					System.out.println("name is : " +s.name);
					System.out.println("percentage is : " +s.percentage);
				}
				
				System.out.println("********ListIterator************");

				ListIterator< Student> v = als.listIterator();
				System.out.println("******forword******");
				while( v.hasNext())
				{
					Student d = v.next();
					System.out.println(d);
				}
				System.out.println("**** backword ****");
				while ( v.hasPrevious())
				{
					Student f = v.previous();
					System.out.println(f);
				}
				
			}

		}

		
		
	


