package com.capgemini.stringexp.one;

public class TestB {

	public static void main(String[] args) {
     
		int i = 90;
		Integer k = new Integer(i);
		
		System.out.println(k);
		byte v = 9;
		Byte d = v;
		System.out.println(d);
		
		
		
		
	}

}
