package com.capgemini.stringexp.one;

public class TestC {

	public static void main(String[] args) {

		String k = new String("dhanu vaibhav Jaysingpure ");
		String p [] = k.split ("a", 0);
		System.out.println("zero limit");
		for ( String str:p)
		{
			System.out.println(str);
		}
      System.out.println(k.substring(5));
     char[] d = k.toCharArray();
     for (char c : d) {
    	 System.out.println(c);
     }
		
	}

	
}
