package com.capgemini.stringexp.one;

public class Test1 {

	public static void main(String[] args) {

		String k = "dhanashri";
		String t = "dhAnaShri";
		String p =  new String ("dhanashri");
		boolean res = k.equals(t);
		
		System.out.println("result is "+ res);
		
		
	}
}












 