package com.capgemini.stringexp.one;

public class TestA {
       
	public static void main(String[] args) {

		StringBuilder sb = new StringBuilder();
		sb.append("dhanashri");
		System.out.println(sb);
		
		
		
		
		
		String k = "dhanashri";
		String t = "vaibhav";
		String m = "dhanashri";
		System.out.println("k is " + k);
		System.out.println(" m is " +m);
		System.out.println("t is " + t);
		
		
	}

}
