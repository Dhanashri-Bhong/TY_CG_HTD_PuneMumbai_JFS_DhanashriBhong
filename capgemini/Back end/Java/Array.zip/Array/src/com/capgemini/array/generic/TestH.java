package com.capgemini.array.generic;

interface dv{
	double area (double r);
}



public class TestH {

	public static void main(String[] args) {
      
		dv s=  r -> 3.14*r*r;
		
		double h = s.area(89.232);
		System.out.println(h);
		
		
	}

}
