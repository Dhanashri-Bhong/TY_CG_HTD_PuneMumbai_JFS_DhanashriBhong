package com.capgemini.array.generic;

public class TestD {

	public static void main(String[] args) {
		char [] i = new char [4];
	
		
		for ( char a :i)
		{
			System.out.println(a);
		}

	}

}
