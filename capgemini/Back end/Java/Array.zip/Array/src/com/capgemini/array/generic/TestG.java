package com.capgemini.array.generic;

interface Sum {
	int sqr ( int a);

}


public class TestG {

	public static void main(String[] args) {

		Sum f = (a)-> a*a;
		int j = f.sqr(20);
		System.out.println(j);
		
		
		
		
	}

}
