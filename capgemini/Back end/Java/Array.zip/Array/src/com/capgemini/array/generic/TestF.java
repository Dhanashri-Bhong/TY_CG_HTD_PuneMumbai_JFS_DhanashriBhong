package com.capgemini.array.generic;

public class TestF {

	public static void main(String[] args) {

		int[] i = chikku();
		for( int k : i)
		{
			System.out.println(k);
		}
		
	}
     static int [] chikku()
     {
    	 int [] a = {10,20,30,40};
    	 return a;
     }
}
