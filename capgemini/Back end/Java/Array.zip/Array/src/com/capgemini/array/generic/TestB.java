package com.capgemini.array.generic;

public class TestB {

	public static void main(String[] args) {

		int a [] = { 12,55,55,552,44};
		
		recieve (a);
		
	}
		static void recieve(int [] c)
		{
			for (int i :c)
			{
				System.out.println(i);
			}
		}
		
	}