package com.capgemini.array.generic;

public class Mouse {

	void onlyOdd( int [] y)
	{
		System.out.println("----only odd-----");
		for( int f : y)
		{
			if(f%2==1)
			{
			System.out.println(f);
		     }
		}
	}
		
	void walk(double[] a)
	{
		for( double k : a)
		{
			System.out.println(k);
		}
	}

	void run ( int[] b)
	{
		for (int i = 0; i<=b.length; i++) 
		{
			System.out.println(b[i]);
		}

	}


}
