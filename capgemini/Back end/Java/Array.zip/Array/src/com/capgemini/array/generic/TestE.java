package com.capgemini.array.generic;

public class TestE {

	public static void main(String[] args)
	{
    Student [] st = new Student[4];
    Student s1 = new Student(1,"dhanu",84.36);
    Student s2 = new Student(2,"vaibhav",89.36);
    Student s3 = new Student(3,"himmu",80.36);
    Student s4 = new Student(4,"uruu",85.36);

		st [0] = s1;
		st [1] = s2;
		st [2] = s3;
		st [3] = s4;
recieve(st);

	}
 static void recieve(Student[] st)
 {
	 for(Student s: st)
	 {
		 System.out.println(s.id);
		 System.out.println(s.name);
		 System.out.println(s.percentage);
		 System.out.println("-------------");


	 }
 }
	
	
	
}
