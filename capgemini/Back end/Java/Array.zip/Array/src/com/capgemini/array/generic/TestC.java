package com.capgemini.array.generic;

public class TestC {

	public static void main(String[] args) {

		
		char ch [] = { 'a','b','n','k','d','v'};
		
		for ( char a : ch)
		{
			System.out.println(a);
		}
		
		double d [] = { 12.2,23.5,58.23,25.85,78.256,452.2887};
	recieve(d);
	}

	static void recieve(double [] c)
	{
		for ( double r: c)
		{
			System.out.println(r);
		}
	}
	
}
