package com.capgemini.array.generic;

interface Gm{
	void gm();
	
}



public class TestJ {

	public static void main(String[] args) {

		Gm m = ()->System.out.println("Good Morning");
		m.gm();
		
		
	}

}
