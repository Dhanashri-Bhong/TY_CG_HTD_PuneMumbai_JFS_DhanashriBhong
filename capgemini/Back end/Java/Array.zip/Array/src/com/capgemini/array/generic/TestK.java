package com.capgemini.array.generic;

public class TestK {

	public static void main(String[] args) {


		Mouse m = new Mouse();
		double [] v = { 23.26,52.85,855.556};
		m.walk(v);
		System.out.println("----------");
		int [] h = {1,2,3,5};
		m.onlyOdd(h);
		System.out.println("----------");
		m.run(h);


	}

}
