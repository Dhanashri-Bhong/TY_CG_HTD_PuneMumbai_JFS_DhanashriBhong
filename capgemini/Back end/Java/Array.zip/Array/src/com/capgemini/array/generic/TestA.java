package com.capgemini.array.generic;
public class TestA {
	public static void main(String[] args) {
		String [] s = new String [4];
		s[0] = "dhanu";
		s[1] = "vaibhav";
		s[2] = "himmu";
		s[3] = "uru";
		recieve(s);
System.out.println("-----------------");
		int [] k= new int [5];
		k[0] = 12;
		k[1] = 52;
		k[2] = 52;
		for( int j =0;j<3; j++) {
			System.out.println(k[j]);
		}
	}
	static void recieve ( String []f)
	{
		for( String g: f)
		{
			System.out.println(g);
		}
	}
}
