package com.capgemini.employeewebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.employeewebapp.bean.EmployeeInfoBean;
import com.capgemini.employeewebapp.dao.EmployeeDAO;
import com.capgemini.employeewebapp.dao.EmployeeDAOJpImpl;
@WebServlet("/update")
public class UpdateEmployeeServlet extends HttpServlet {

	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	HttpSession session = req.getSession(false);
	if(session !=null) {
		//valid session
		//get the form data
		int empId = Integer.parseInt(req.getParameter("empId"));
		String empName = req.getParameter("empName");
		String password = req.getParameter("password");
		String designation = req.getParameter("designation");
		long mobile = Long.parseLong(req.getParameter("mobile"));
		double salary =Double.parseDouble( req.getParameter("salary"));
		String gender = req.getParameter("gender");
		int age = Integer.parseInt(req.getParameter("age"));

		

		EmployeeInfoBean eib = new EmployeeInfoBean();
		eib.setEmpId(empId);
		eib.setEmpName(empName);
		eib.setDesignation(designation);
		eib.setPassword(password);
		eib.setAge(age);
		eib.setGender(gender);
		eib.setSalary(salary);
		eib.setMobile(mobile);

		
		EmployeeDAO dao = new EmployeeDAOJpImpl();
		boolean isAdd = dao.updateEmployee(eib);
		
		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");
        if(isAdd) {
        	
        	out.println("<h1 style='color :red'>Record Updated Successfull....</h1>");
        }else {
        	
        	out.println("<h2 style='color :red'>Employee not Updated...</h2>");
        }
		
		
	}else {
		 
		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<h2 style='color :red'> Please Login First!</h2>");
		out.println("</body>");
		out.println("</html>");
		RequestDispatcher dispatcher = req.getRequestDispatcher("./loginForm.html");
        dispatcher.include(req, resp);
		
	}
	
	}//end of dopost
}
