package com.capgemini.employeewebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.employeewebapp.bean.EmployeeInfoBean;
import com.capgemini.employeewebapp.dao.EmployeeDAO;
import com.capgemini.employeewebapp.dao.EmployeeDAOJpImpl;

@WebServlet("/searchEmployee")
public class SearchEmployeeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// get the form data
		String empIdVal = req.getParameter("empId");
		int empId = Integer.parseInt(empIdVal);

		EmployeeDAO dao = new EmployeeDAOJpImpl();
		EmployeeInfoBean eib = dao.getEmployee(empId);

		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		out.println("<html>");
		out.println("<body>");

		if (eib != null) {
			// display employee record
			out.println("<h2>Employee Id = " + empId + "Found-<h2>");
			out.println("Employee Name = " + eib.getEmpName());
			out.println("<br>Age = " + eib.getAge());
			out.println("<br>Salary = " + eib.getSalary());
			out.println("<br>Mobile Number = " + eib.getMobile());
			out.println("<br>Gender = " + eib.getGender());
			out.println("<br>Password = " + eib.getPassword());
			out.println("<br>Designation = " + eib.getDesignation());

		} else {
			// display error message
			out.println("<h3 style = 'color :red'>Employee Id " + empId + "Not Found !!!");
		}

		out.println("</body>");
		out.println("</html>");
	}

}// end of class
