package com.capgemini.employeewebapp.dao;

import com.capgemini.employeewebapp.bean.EmployeeInfoBean;

public interface EmployeeDAO {

	public EmployeeInfoBean getEmployee(int empId);
	public EmployeeInfoBean authenticate(int empId , String pwd);
	public boolean addEmployee(EmployeeInfoBean eib);
	public boolean updateEmployee(EmployeeInfoBean eib);
}//end of DAO
