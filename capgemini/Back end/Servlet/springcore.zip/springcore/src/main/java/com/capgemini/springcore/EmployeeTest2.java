package com.capgemini.springcore;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;

public class EmployeeTest2 {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeConfig.xml");
		EmployeeBean eb1 = context.getBean("employee", EmployeeBean.class);
		
		System.out.println("Enter Employee Id : ");
		int empId = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Employee Name : ");
		String empName = sc.nextLine();
		eb1.setEmpId(empId);
		eb1.setEmpName(empName);
		
		EmployeeBean eb2 = context.getBean("employee", EmployeeBean.class);

		System.out.println("Enter Employee2 Id : ");
		int empId2 = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Employee2 Name : ");
		String empName2 = sc.nextLine();
		eb2.setEmpId(empId2);
		eb2.setEmpName(empName2);
		
		System.out.println("eb1 Id :" +eb1.getEmpId());
		System.out.println("eb1 Name : " +eb1.getEmpName());
		System.out.println("eb2 Id :" +eb2.getEmpId());
		System.out.println("eb2 Name : " +eb2.getEmpName());
		
		
		
	}//end of main()

}//end of class
