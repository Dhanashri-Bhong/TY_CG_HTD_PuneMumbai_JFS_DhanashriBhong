package com.capgemini.springcore.interfaceses;

public interface Engine {

	public int getCC();
	public String getType();
	
}//end of interface
