package com.capgemini.springcore.annotation.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.springcore.annotation.beans.MessageBean;
import com.capgemini.springcore.annotation.config.MessageConfig;

public class MessageTest {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(MessageConfig.class);
		MessageBean mb = context.getBean(MessageBean.class);

		System.out.println(mb.getMessage());

		MessageBean mb2 = context.getBean(MessageBean.class);
		System.out.println(mb2.getMessage());
		
		mb2.setMessage("Hiii I am new object...");
		System.out.println("Message 1 = "+mb.getMessage());
        System.out.println("Message 2 = "+mb2.getMessage());

	}// end of main

}// end of class
