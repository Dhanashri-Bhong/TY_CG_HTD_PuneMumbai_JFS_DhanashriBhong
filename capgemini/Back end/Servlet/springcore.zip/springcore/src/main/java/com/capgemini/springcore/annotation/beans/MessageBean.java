package com.capgemini.springcore.annotation.beans;

public class MessageBean {

	private String message;

	//getter and setter
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}//end of class
