package com.capgemini.springcore.annotation.beans;

import com.capgemini.springcore.interfaceses.Engine;

public class VW implements Engine {

	@Override
	public int getCC() {
		return 1800;
	}

	@Override
	public String getType() {
		return "VW-4-Stroke Petrol";
	}

}//end of class
