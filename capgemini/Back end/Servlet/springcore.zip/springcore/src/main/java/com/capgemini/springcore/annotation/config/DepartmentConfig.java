package com.capgemini.springcore.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.springcore.annotation.beans.DepartmentBean;
@Configuration
public class DepartmentConfig {
	
	@Bean(name = "d1")
	public DepartmentBean getDevelopmentDept()
	{
		DepartmentBean db = new DepartmentBean();
		db.setDeptId(1);
		db.setDeptName("Development");
		return db;
	}
	
	@Bean(name = "d2")
	public DepartmentBean getTestingDept()
	{
		DepartmentBean db = new DepartmentBean();
		db.setDeptId(2);
		db.setDeptName("Testing");
		return db;
	}
	
	
	@Bean(name = "d3")
	//@Primary
	public DepartmentBean getHRDept()
	{
		DepartmentBean db = new DepartmentBean();
		db.setDeptId(3);
		db.setDeptName("HR");
		return db;
	}

}//end of class

