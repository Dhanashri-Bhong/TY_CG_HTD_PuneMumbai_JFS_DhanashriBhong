package com.capgemini.springcore.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.capgemini.springcore.annotation.beans.ISUZU;
import com.capgemini.springcore.annotation.beans.VW;
import com.capgemini.springcore.interfaceses.Engine;

@Configuration
public class EngineConfig {

	@Bean(name="ISUZU")
	@Primary
	public Engine getISUZU() {
		return new ISUZU();
	}
	
	@Bean(name="VW")
	public Engine getVW() {
		return new VW();
	}
	
}//end of class
