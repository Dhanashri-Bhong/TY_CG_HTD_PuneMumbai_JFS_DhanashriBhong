package com.capgemini.springcore.interfaceses;

public interface Animal {

	public void eat();
	public void speak();
	public void walk();
}
