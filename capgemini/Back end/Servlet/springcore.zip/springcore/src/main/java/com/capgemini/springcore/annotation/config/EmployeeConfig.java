package com.capgemini.springcore.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;


import com.capgemini.springcore.annotation.beans.DepartmentBean;
import com.capgemini.springcore.annotation.beans.EmployeeBean;
@Import(DepartmentConfig.class)
@Configuration
public class EmployeeConfig {

	@Bean
	public EmployeeBean getEmployeeBean()
	{
		EmployeeBean eb = new EmployeeBean();
		eb.setEmpId(101);
		eb.setEmpName("Nabila");
		
		return eb;
	}
	
	/*
	@Bean(name = "d2")
	public DepartmentBean getTestingDept()
	{
		DepartmentBean db = new DepartmentBean();
		db.setDeptId(2);
		db.setDeptName("Testing");
		return db;
	}
	
	
	@Bean(name = "d3")
	//@Primary
	public DepartmentBean getHRDept()
	{
		DepartmentBean db = new DepartmentBean();
		db.setDeptId(3);
		db.setDeptName("HR");
		return db;
	}*/
	
	
}//end of class
