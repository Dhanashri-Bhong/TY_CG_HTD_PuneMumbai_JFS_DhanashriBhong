package com.capgemini.springcore.beans;

public class MobileBean {

	private String brandName;
	private String modeName;
	private double price;
	private MobileDisplay md;
	
	//getters and setters
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getModeName() {
		return modeName;
	}
	public void setModeName(String modeName) {
		this.modeName = modeName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public MobileDisplay getMd() {
		return md;
	}
	public void setMd(MobileDisplay md) {
		this.md = md;
	}
	
	
	
}
