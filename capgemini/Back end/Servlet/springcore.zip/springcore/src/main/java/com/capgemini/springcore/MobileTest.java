package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MobileBean;

public class MobileTest {

	public static void main(String[] args) {

		
	ApplicationContext context = new ClassPathXmlApplicationContext("mobile.xml");
	MobileBean mb = context.getBean("mobile" , MobileBean.class);
	
	System.out.println("Brand Name : "+mb.getBrandName());
	System.out.println("Model Name : "+mb.getModeName());
	System.out.println("Price : "+mb.getPrice());
	System.out.println("Display Size :" +mb.getMd().getDisplaySize());
	System.out.println("Resolution : "+mb.getMd().getResolution());
	System.out.println("***************************************************");
	
	
	MobileBean mb1 = context.getBean("mobile1" , MobileBean.class);
	System.out.println("Brand Name : "+mb1.getBrandName());
	System.out.println("Model Name : "+mb1.getModeName());
	System.out.println("Price : "+mb1.getPrice());
	System.out.println("Display Size :" +mb1.getMd().getDisplaySize());
	System.out.println("Resolution : "+mb1.getMd().getResolution());
	System.out.println("***************************************************");

	
	MobileBean mb3 = context.getBean("mobile2" , MobileBean.class);
	System.out.println("Brand Name : "+mb3.getBrandName());
	System.out.println("Model Name : "+mb3.getModeName());
	System.out.println("Price : "+mb3.getPrice());
	System.out.println("Display Size :" +mb3.getMd().getDisplaySize());
	System.out.println("Resolution : "+mb3.getMd().getResolution());
	}

}
