package com.capgemini.springcore.annotation.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.capgemini.springcore.annotation.beans.EmployeeBean;
import com.capgemini.springcore.annotation.config.EmployeeConfig;

public class EmployeeTest {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);

//ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class,DepartmentConfig.class);

		EmployeeBean eb = context.getBean(EmployeeBean.class);

		System.out.println("Employee Info.......");
		System.out.println("Employee Id : " + eb.getEmpId());
		System.out.println("Employee Name :" + eb.getEmpName());
		System.out.println("-----------------------------------------");
		System.out.println("Department Info.....");
		System.out.println("Department No. :" + eb.getDeptBean().getDeptId());
		System.out.println("Department Name : " + eb.getDeptBean().getDeptName());

		((AbstractApplicationContext) context).close();
	}// end of main

}// end of class
