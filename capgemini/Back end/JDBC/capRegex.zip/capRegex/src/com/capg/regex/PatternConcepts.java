package com.capg.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts 
{
	static Pattern pattern;
	static Matcher matcher;

	public static void main(String[] args) 
	{
		pattern = Pattern.compile("\\d{1,9}");//single digits , D means not a single digits
		matcher = pattern.matcher("1234567890");
		System.out.println(" pattern \\d {1,9}  : "+matcher.matches());
		
		System.out.println("********************************************");
		pattern = Pattern.compile("\\d");//single digits , D means not a single digits
		matcher = pattern.matcher("1");
		System.out.println(" pattern \\d   : "+matcher.matches());
		
		System.out.println("-------------------------------------");
		pattern = Pattern.compile("\\d+");// multiple digits  D+ means not a multiple digits
		matcher = pattern.matcher("142797");
		System.out.println(" pattern \\d+ : "+matcher.matches());
		System.out.println("--*__*__*__*__*__*__*__*__*__*__*__*__*__*");
		
		pattern = Pattern.compile("\\D+");// multiple digits  D+ means not a multiple digits
		matcher = pattern.matcher("vvv");
		System.out.println(" pattern \\D+ : "+matcher.matches());
		System.out.println("--*__*__*__*__*__*__*__*__*__*__*__*__*__*");
		
		pattern = Pattern.compile("\\s");// single space
		matcher = pattern.matcher("     ");
		System.out.println(" pattern \\s : "+matcher.matches());
		System.out.println("--*__*__*__*__*__*__*__*__*__*__*__*__*__*");
		
		pattern = Pattern.compile("\\S");// no space
		matcher = pattern.matcher("e");
		System.out.println(" pattern \\S : "+matcher.matches());
		System.out.println("--*__*__*__*__*__*__*__*__*__*__*__*__*__*");
		
		pattern = Pattern.compile("\\W");//single charaters W means not acharacter
		matcher = pattern.matcher("V");
		System.out.println("patter \\w :  "+matcher.matches());
		
	System.out.println("--------------------------------------------------");
        System.out.println("//**//**//**//**//**//**//**//**//**//**//");
		pattern = Pattern.compile("\\w+");// string
		matcher = pattern.matcher("Vaibhav");
		System.out.println("patter \\w+ :  "+matcher.matches());
	
	}	

}
