package com.capgemini.jdbc.controller;

public class Regex {

	public static void main(String[] args) {
		
	}

}
