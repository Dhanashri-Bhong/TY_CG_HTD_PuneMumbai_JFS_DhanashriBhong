package com.capgemini.jdbc.factory;

import com.capgemini.jdbc.dao.UserDAOJDBCImpl;
import com.capgemini.jdbc.dao.UserDao;

public class UserFactory {
	
	
	private UserFactory() {
		
	}

	public static UserDao getInstance()
	{
		UserDao dao = new UserDAOJDBCImpl();
		return dao;
	}
}
