package com.capgemini.jdbc.controller;

import java.util.Scanner;

import com.capgemini.jdbc.beans.UserBean;
import com.capgemini.jdbc.dao.UserDao;
import com.capgemini.jdbc.factory.UserFactory;

public class UserLogin {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		UserDao dao = UserFactory.getInstance();
		System.out.println(" ENter the userid ...");
		int userid = Integer.parseInt(sc.nextLine());
		System.out.println(" Enter the password......");
		String password = sc.nextLine();
		UserBean user = dao.userLogin(userid, password);
		
		
		if ( user != null)
		{
			System.out.println(user);
		}
		else
		{
			System.out.println(" Something wents Wrong");
		}
		sc.close();
	}
	
	
}
