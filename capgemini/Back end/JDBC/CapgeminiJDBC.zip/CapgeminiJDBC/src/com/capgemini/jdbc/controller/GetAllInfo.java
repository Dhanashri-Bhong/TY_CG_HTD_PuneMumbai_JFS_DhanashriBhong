package com.capgemini.jdbc.controller;

import java.util.List;

import com.capgemini.jdbc.beans.UserBean;
import com.capgemini.jdbc.dao.UserDao;
import com.capgemini.jdbc.factory.UserFactory;

public class GetAllInfo {
	
	
	public static void main(String[] args) {
		
		UserDao dao = UserFactory.getInstance();
		List<UserBean> user = dao.getAllInfo();
		if ( user != null)
		{
			for ( UserBean list: user)
			{
				System.out.println(list);
			}
		}
		
		else 
		{
			System.out.println(" Something wents wrong ..........");
		}
		
	}
	
}
