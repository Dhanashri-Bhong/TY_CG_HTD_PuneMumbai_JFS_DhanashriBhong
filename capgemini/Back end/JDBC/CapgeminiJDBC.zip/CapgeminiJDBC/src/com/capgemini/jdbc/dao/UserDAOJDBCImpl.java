package com.capgemini.jdbc.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.jdbc.beans.UserBean;

public class UserDAOJDBCImpl implements UserDao {
	FileReader reader = null;
	Properties prop = null;
	UserBean user = null;


	
	public UserDAOJDBCImpl ()
	{
		try 
		{
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
			
			Class.forName(prop.getProperty("driverClass"));
			System.out.println("Driver Loaded............");
			System.out.println("*************************************");

		}
		
		catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	@Override
	public UserBean getInfo(int userid)
	{
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl") ,
				prop.getProperty("user") ,prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query2")))
		 {
			pstmt.setInt(1, userid);
			try(ResultSet rs = pstmt.executeQuery()) 
			{
			if (rs.next())
			{
				user = new UserBean();
				user.setUserid(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setEmail(rs.getString(3));

			}
			return user;
				
			} catch (Exception e) {
			}
		} 
		catch (Exception e) {
		}
		return null;
	}


	@Override
	public UserBean userLogin(int userid, String password) {
	
		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl") ,
				prop.getProperty("user") ,prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query3")))
		 {
			pstmt.setInt(1, userid);
			pstmt.setString(2, password);
			try(ResultSet rs = pstmt.executeQuery()) 
			{
			if (rs.next())
			{
				user = new UserBean();
				user.setUserid(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setEmail(rs.getString(3));
         
			}
			return user;
				
			} catch (Exception e) {
			}
		} 
		catch (Exception e) {
		}
		return null;
	
	}


	@Override
	public List<UserBean> getAllInfo() {
		
		List<UserBean> userList = new ArrayList<UserBean>();

		try(Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl") ,
				prop.getProperty("user") ,prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query")))
		 {
			
			try(ResultSet rs = pstmt.executeQuery()) 
			{
			while (rs.next())
			{
				user = new UserBean();
				user.setUserid(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setEmail(rs.getString(3));
                userList.add(user);
			}
			return userList;
				
			} catch (Exception e) {
			}
		} 
		catch (Exception e) {
		}
		return null;
		
	}
	
	

}
