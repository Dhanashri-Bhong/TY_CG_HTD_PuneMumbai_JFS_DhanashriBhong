package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InsertionRegex {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		
        try {
		      //Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded............");
			System.out.println("*************************************");
			
			//Get the Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("Connection Estd..................");
			System.out.println("****************************************"); 
			
			//Issue SQL via connection
			String query = "INSERT INTO users_info values(?,?,?,?)";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter userid:");
			String id=sc.nextLine();
			Pattern pat=Pattern.compile("\\d{7}");
			Matcher mat=pat.matcher(id);
			boolean b=mat.matches();
			if(b==true) {
				pstmt.setString(1,id);

			}else {
				System.out.println("enter id according to format");
			}
			
			
			System.out.println("Enter name :");
			String name=sc.nextLine();
			Pattern pat1=Pattern.compile("\\w+\\s\\w+");
			Matcher mat1=pat1.matcher(name);
			boolean b1=mat1.matches();
			if(b1==true) {
				pstmt.setString(2,name);

			}else {
				System.out.println("enter name according to format");
			}
			System.out.println("Enter email :");
			String email=sc.nextLine();
			Pattern pat2=Pattern.compile("\\w{1,10}\\@\\w{1,5}\\.\\w{1,3}");
			Matcher mat2=pat2.matcher(email);
			boolean b2=mat2.matches();
			if(b==true) {
				pstmt.setString(3,email);

			}else {
				System.out.println("enter email according to format");
			}
			System.out.println("Enter password :");
			String password=sc.nextLine();
			Pattern pat3=Pattern.compile("\\w+\\d+");
			Matcher mat3=pat3.matcher(password);
			boolean b3=mat.matches();
			if(b==true) {
				pstmt.setString(4,password);

			}else {
				System.out.println("enter password according to format");
			}
            	int count = pstmt.executeUpdate(query);
			
			//Process the results
			if (count>0) {
				System.out.println(" Data inserted");
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
        finally
        {
        	if (conn != null)
        	{
        		try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
        	}
        	if (pstmt !=null)
        	{
        		try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
        	}
        	sc.close();
        }
	}
	
	
}
