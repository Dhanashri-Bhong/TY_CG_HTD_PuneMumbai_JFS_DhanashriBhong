package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCUpdate {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded............");
			System.out.println("*************************************");

			// Get the Connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			DriverManager.getConnection(dbUrl);
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("Connection Estd..................");
			System.out.println("****************************************");

			// Issue SQL via connection
			String query = "update  users_info set  username = ?  where userid=?";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter name :");
			pstmt.setString(1, sc.nextLine());
			System.out.println("Enter userid:");
			pstmt.setInt(2, Integer.parseInt(sc.nextLine()));
			int count = pstmt.executeUpdate();

			// Process the results
			if (count > 0) {
				System.out.println(" Data update");
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			sc.close();
		}
	}

}
