package com.capgemini.jpawithhibernateassign.jpawithhibernateassignment;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernateassignment.dto.Employee;


public class ReadDemo {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Dhanu");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		Employee data = entityManager.find(Employee.class, 1);
		System.out.println("Id is :"+data.getEid());
		System.out.println("Name is :"+data.getName());
		System.out.println("Salary is :"+data.getSalary());
		System.out.println("Comm is :"+data.getComm());

		System.out.println("-------------------------------------");
				
	}

}
