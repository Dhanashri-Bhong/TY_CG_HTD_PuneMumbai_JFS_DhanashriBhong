package com.capgemini.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springmvc.beans.EmployeeInfoBean;
//@Component
@Repository
public class EmployeeDAOJpImpl implements EmployeeDAO {
  
	//@Autowired
	@PersistenceUnit
	 private EntityManagerFactory emf;

	@Override
	public EmployeeInfoBean getEmployee(int empId) {
      
		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean eib = manager.find(EmployeeInfoBean.class, empId);
		manager.close();
		
		
		return eib;
	}//end of getEmployeee

	@Override
	public EmployeeInfoBean authenticate(int empId, String pwd) {
	
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean where empId = :empId and password = :pwd";
		Query query = manager.createQuery(jpql);
		query.setParameter("empId", empId);
		query.setParameter("pwd", pwd);
		
	EmployeeInfoBean eib =null;
	try{
		eib = (EmployeeInfoBean) query.getSingleResult();
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return eib;
	}//end if authenticate

	@Override
	public boolean addEmployee(EmployeeInfoBean eib) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdd= false;
		try{tx.begin();
		manager.persist(eib);
		tx.commit();
		isAdd = true;
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		manager.close();
		return isAdd;
	}//end of add

	@Override
	public boolean updateEmployee(EmployeeInfoBean eib) {

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		
		EmployeeInfoBean empInfo = manager.find(EmployeeInfoBean.class, eib.getEmpId());
		if(empInfo != null) {
			if(eib.getEmpName()!=null) {
				empInfo.setEmpName(eib.getEmpName());
			}
			if(eib.getAge() !=0) {
				empInfo.setAge(eib.getAge());
			}
			if(eib.getPassword() !=null) {
				empInfo.setPassword(eib.getPassword());
			}
			if(eib.getDesignation() !=null) {
				empInfo.setDesignation(eib.getDesignation());
			}
			if(eib.getGender()!=null) {
				empInfo.setGender(eib.getGender());
			}
			if(eib.getMobile() !=0) {
				empInfo.setMobile(eib.getMobile());
			}
			if(eib.getSalary() !=0) {
				empInfo.setSalary(eib.getSalary());
			}
			
		}
		boolean isUpdate = false;
		try{tx.begin();
		manager.persist(empInfo);
		tx.commit();
		isUpdate = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		manager.close();
		return isUpdate;
	
	}
	
	@Override
	public boolean deleteEmployee(int empId) {
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			EmployeeInfoBean employeeInfoBean= entityManager.find(EmployeeInfoBean.class, empId);
			entityManager.remove(employeeInfoBean);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}// End of deleteEmployee()

	@Override
	public List<EmployeeInfoBean> getAllEmployees() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean";
		Query query = manager.createQuery(jpql);
		
		List<EmployeeInfoBean> employeesList = null;
		try {
			employeesList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return employeesList;
		
	}// End of getAllEmployees()
	

	
	
}//end of class
