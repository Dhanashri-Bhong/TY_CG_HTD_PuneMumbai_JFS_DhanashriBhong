package com.capgemini.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.capgemini.springmvc.beans.EmployeeInfoBean;
import com.capgemini.springmvc.service.EmployeeService;

@Controller
public class EmployeeController {
  
	@Autowired
	private EmployeeService service;
	
	
	@GetMapping("/employeeLogin")
	public String displayEmpLoginform() {
		
		return "employeeLogin";
		
	}//end of displatEmpLoginForm
	
	@PostMapping("/empLogin")
	public String empLogin( int empId , String password , ModelMap modelMap,HttpServletRequest req) {
		
		EmployeeInfoBean eib = service.authenticate(empId, password);
		if(eib != null) {
			//valid credential
			HttpSession session = req.getSession(true);
			session.setAttribute("eib", eib);
			
			return "empHomePage";
		}else {
			//invalid credential
            modelMap.addAttribute("msg", "Iinvalid credential");
		return "employeeLogin";
		}
	}//end of empLogin
	
	@GetMapping("/addEmployeeForm")
	public String displayAddEmployee(HttpSession session ,ModelMap modelMap) {
		if(session.isNew()) {
			modelMap.addAttribute("msg", "Please login first.....");
			return "employeeLogin";
		}else {
			return "addEmployee";
		}
	}//end of addemployee()
	
	@PostMapping("/addEmployee")
	public String addEmployee( EmployeeInfoBean eib ,HttpSession session, ModelMap modelMap) {
		
		if(session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "employeeLogin";
		} else {
			if (service.addEmployee(eib)) {
				modelMap.addAttribute("msg", "Employee Added Successfully");
			}else {
				modelMap.addAttribute("msg", "Unable to add Employee");
			}
			return "addEmployee";
		}
		
	}//end of addEmplyee()
	
	@GetMapping("/updateEmployeeForm")
	public String displayUpdateEmployeeForm(HttpSession session , ModelMap modelMap) {
		
		if(session.isNew()) {
			//invalid session
			modelMap.addAttribute("msg", "Please login first..");
			return "employeeLogin";
		} else {
			return "updateEmployee";
		}
		
	}//end of update
	
	
	@PostMapping("/updateEmployee")
	public String updateEmployee(EmployeeInfoBean eib ,HttpSession session, ModelMap modelMap ) {
		
		if(session.isNew()) {
			modelMap.addAttribute("msg", "Please login first..");
			return "employeeLogin";
		} else {
			if (service.updateEmployee(eib)) {
				modelMap.addAttribute("msg", "Employee updated Successfully");
			}else {
				modelMap.addAttribute("msg", "Unable to update Employee");
			}
			return "updateEmployee";
		}
		
	}
	
	
	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap modelMap) {
		session.invalidate();
		modelMap.addAttribute("msg", "Logged out successfully");
		return "employeeLogin";
	}
	
	
	
	
	@GetMapping("/searchEmployeeForm")
	public String displaySearchEmployeeForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";
		
		} else {
			// Valid Session
			return "searchEmployeeForm";
		}
	}// End of displaySearchEmployeeForm()
	
	@GetMapping("/searchEmployee")
	public String searchEmployee(int empId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";
		
		} else {
			EmployeeInfoBean employeeInfoBean = service.getEmployee(empId);
			if (employeeInfoBean != null) {
				modelMap.addAttribute("employeeInfoBean", employeeInfoBean);
			} else {
				modelMap.addAttribute("msg", "Employee ID " + empId + " Not Found!!!");
			}
			
			return "searchEmployeeForm";
		}
	}// End of searchEmployee()
	
	@GetMapping("/deleteEmployeeForm")
	public String displayDeleteEmployeeForm(HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";
		
		} else {
			// Valid Session
			return "deleteEmployeeForm";
		}
	}// End of displaySearchEmployeeForm()
	
	@GetMapping("/deleteEmployee")
	public String deleteEmployee(int empId, HttpSession session, ModelMap modelMap) {
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";
		
		} else {
			// Valid Session
			if(service.deleteEmployee(empId)) {
				modelMap.addAttribute("msg", "Employee Deleted Successfully!");
			} else {
				modelMap.addAttribute("msg", "Employee ID " + empId + " Not Found!");
			}
			
			return "deleteEmployeeForm";
		}
	}// End of searchEmployee()
	
	@GetMapping("/seeAllEmployees")
	public String getAllEmployees(HttpSession session, ModelMap modelMap) {
		
		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";
		
		} else {
			// Valid Session
			List<EmployeeInfoBean> employeesList = service.getAllEmployees();
			modelMap.addAttribute("employeesList", employeesList);
			
			return "displayAllEmployees";
		}
	}// End of getAllEmployees()
	
	@GetMapping("/home")
	public String displayEmpHomePage(HttpSession session, ModelMap modelMap) {

		if (session.isNew()) {
			// Invalid Session
			modelMap.addAttribute("msg", "Please Login First");
			return "empLoginForm";
		
		} else {
			// Valid Session
			return "empHomePage";
		}
	}// End of displayEmpHomePage()
	
	
}//end of controller
