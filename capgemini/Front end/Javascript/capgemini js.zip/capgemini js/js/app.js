// prompt('Please write your name');
var myname =9922120326;
myname="Dhanashri";
console.log(typeof myname);
var areYouGood = true;
console.log(typeof areYouGood);
var d = 9325494959;
console.log(typeof d);

