
//fat arrow function with two arg.
let add = (a,b) =>{
    console.log("the sum is : ",a+b);
}

add(12,60);
console.log('-----------------')

//fat arrow function with one arg.
let printage = age =>{
    console.log("the age is :" ,age);
}
printage(12364);

console.log('--------------------------')
let product = (a,b)=>a*b;
console.log(product(123,123));
