let myString = 'Capgemini trainees are really intelligent';
console.log(myString.indexOf('are'));
console.log('------------------------------');

console.log(myString.includes('train'));
console.log('---------------------------------');

let reversedString = myString.split('').reverse().join('');
console.log(reversedString);
console.log('-------------------');
console.log(myString.charAt(2));
console.log('-----------------------');
console.log(myString.charCodeAt(1));
console.log('---------------');

