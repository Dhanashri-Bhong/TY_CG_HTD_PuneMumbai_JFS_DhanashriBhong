// alert('Are you sure want to proceed?');

//confirm method
// var inputFromUser = confirm('are you really sure?');

//console method
// console.log(inputFromUser);

//propt method
// var userName = prompt('Please enter your name')
// console.log(userName);

document.write('Good morning all of you......');
