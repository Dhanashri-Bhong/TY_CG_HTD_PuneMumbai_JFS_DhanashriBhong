// var x = [12344,'Vaibhav',true,{name:'Salman Khan'}];
// console.log(x[0]);

// for ( var a=0; a<x.length;a++)
// {
//     console.log(x[a]);
// }

var colors = ['red','white','orange','yellow','black','green'];
console.log(colors);
colors.pop();
console.log(colors);
colors.push('violet','Grey');
console.log(colors);
colors.shift();
console.log(colors);
colors.unshift('Purple','Brown');
console.log(colors);
colors.splice(2,2);
console.log(colors);
colors.splice(3,0,'indigo','indian black','pink');
console.log(colors);

colors.forEach(function(value,index , array){
    console.log(value,index , array);
})

console.log(colors.indexOf('yellow'));

var myArray=[10,100,117,120,130,140];

var newArray=myArray.filter(function(value){
    return value>100;
});
console.log(newArray);

var filteredArray = myArray.filter(function(value,index,array){
    return array.indexOf(value) === index;
});
console.log(filteredArray);
console.log('----------------------------------------');

if(123=='123')
{
    console.log('true');
}
else{
    console.log('false');
}


//strict 
if(123==='123')
{
    console.log('true');
}
else{
    console.log('false');
}

console.log('------------------------------------------');

//for of loop
for(var x of myArray)
{
    console.log(x);

}

console.log('------------------------------------');

//for in loop

for (var v in colors )
{
    console.log('value is '+colors[v] ,'index is '+v);
}
console.log('------------------------------------');

var movie = {
    name:'Wanted',
    actor:'Salman Khan',
    movies:256,
    hits:202,
    actress:'Shreya'
};
for (var key in movie)
{
    console.log(movie[key]);
}



// var i=1
// setInterval(function() {
//     console.log(i);
//     i++;
    
// // }, 2000);



// function test(callback){
//     console.log('test function started');
//     callback();
//     console.log('test function ended');
// }
// test (function()
// {
//     console.log('callback function is being executed');
// });

// setTimeout(function()
// {
//     console.log('5 seconds done');
// },5000);

