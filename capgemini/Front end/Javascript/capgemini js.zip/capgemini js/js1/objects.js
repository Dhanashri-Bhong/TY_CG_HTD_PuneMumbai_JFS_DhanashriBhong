var student = {
    name:'Sandeep Maheshwari',
    age:39,
    degree:'BE',
    phoneNumber:9922120326
};

console.log(student.name);
console.log(student);


student.phoneNumber=9325494959;

console.log(student.phoneNumber);
student.selectedCompany = 'Capgemini' ;
console.log(student);

//using object constructor
var laptop = new Object();
laptop.brand = 'Dell';
laptop.ram = '8GB';
laptop.processor='core i5';
laptop.price =45000;
console.log(laptop);

var laptop1 = new Object();
laptop1.brand = 'HP';
laptop1.ram = '8GB';
laptop1.processor='core i4';
laptop1.price =41000;
console.log(laptop1);

console.log(Object.keys(laptop));

console.log(Object.keys(laptop1).length);
