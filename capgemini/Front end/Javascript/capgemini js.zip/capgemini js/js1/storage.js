localStorage.setItem('name','Dhanashri');
console.log(localStorage.length);
console.log(localStorage.getItem('name'));
console.log(localStorage.clear());
console.log(localStorage.length);
console.log('----------------------------------');
sessionStorage.setItem('name','Vaibhav');
console.log(sessionStorage.getItem('name'));
