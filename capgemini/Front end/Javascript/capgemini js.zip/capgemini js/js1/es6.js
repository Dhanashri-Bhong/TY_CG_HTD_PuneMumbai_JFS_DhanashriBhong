let person = 
{
    name:'Vaibhav',
    age:22
};

let student = 
{
    ...person,
    id: 1234,
    percentage:89.75

};

console.log(student);
console.log('-------------------------------------');
let bangaloreCRS=['Vaibhav','Dhanashri'];
let mumbaiCRS = ['DOremon','Doremee'];
let puneCRS=['Nobita','Shizuka'];
let noidaCRS=['Shinchan','Zuiko'];

let CRS = [
    ...mumbaiCRS,
    ...puneCRS,
    ...noidaCRS,
    ...bangaloreCRS,
    'subrat'
];
console.log(CRS);

let [name1,name2,name3,name4,...restValues] = CRS;
console.log(name1);
console.log(name2);
console.log(restValues);
 


