var myString = `Enclosing quotation marks
Let’s say you’re trying to use quotation marks inside a string. 
You’ll need to use opposite quotation marks inside and outside. 
That means strings containing single quotes need to use double quotes
 and strings containing double quotes need to use single quotes.`

 console.log(myString);

 var name = 'Dhanashri';
 var role = 'CR';
var batch = 'Pune';

console.log(`I am ${name} and i am  the ${role} of ${batch} batch`);

console.log( `the sum of 1234 and 4321 is${1234+4321}`);