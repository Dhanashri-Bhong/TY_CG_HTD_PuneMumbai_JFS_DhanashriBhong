export class Circle{
    circumference( r:number){
        return 2*3.14*r;
    }

    areaOfCircle(r:number){
        return 3.14*r*r;
    }
}