let myName :String = 'Dhanashri';

//myName=123:error-we con not change the datatype


let company ;//implicitly it will be consider as any

company= 123;
company = 'dhanu';
company=true;

//union
let age:string | number;
age=123;
age='vaibhav';

//touple
let details:[string,number,number]=['xyz',12,4522];

//arrys
let mobiles=['iphone','samsung',2020,true] //if we are not mentioning any type then it will accept any type of value

let a:string[] = ['ghj','ghj','dfcb','ghfj'] // it is homogeneous type declaration

//functions
function add(a:number , b:number):number{
    return a+b;
}