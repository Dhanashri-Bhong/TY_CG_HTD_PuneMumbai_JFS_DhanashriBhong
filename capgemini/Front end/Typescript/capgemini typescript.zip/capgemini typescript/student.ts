class Student {
   constructor(
   public name:String,
     public age:number,
   public marks:number,
   public degree ? :string
   ){

   }

//    printDetails ()
//    {
//        console.log(`Name id  ${this.name} age is ${this.age} 
//        and the marks is ${this.marks}` );

//    }
}

//object using new keyword
let student1 = new Student('dhanu' ,22,89.75);
console.log(student1);
// student1.printDetails();

//array



//object using literal
let student2 :Student={
    name:'vaibhav',
    age :22,
    marks :85,
    degree : 'BE'

}

console.log(student2);

//array

let students:Student[]=
[
    new Student('chikku' ,299,100),
    {
        name:'Laddu',
        age:200,
        marks:500,
        degree:'BE'
    },
    student2,
    student1
];
for (let student of students ){
    console.log(student);
}


class D extends Student{
    constructor(
         name:String,
      age:number,
    marks:number,
    degree ? :string
    ){
        super(name,age,marks);
    }
}

