var myName = 'Dhanashri';
//myName=123:error-we con not change the datatype
var company; //implicitly it will be consider as any
company = 123;
company = 'dhanu';
company = true;
//union
var age;
age = 123;
age = 'vaibhav';
//touple
var details = ['xyz', 12, 4522];
//arrys
var mobiles = ['iphone', 'samsung', 2020, true]; //if we are not mentioning any type then it will accept any type of value
var a = ['ghj', 'ghj', 'dfcb', 'ghfj']; // it is homogeneous type declaration
//functions
function add(a, b) {
    return a + b;
}
