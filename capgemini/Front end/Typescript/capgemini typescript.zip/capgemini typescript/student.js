var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Student = /** @class */ (function () {
    function Student(name, age, marks, degree) {
        this.name = name;
        this.age = age;
        this.marks = marks;
        this.degree = degree;
    }
    return Student;
}());
//object using new keyword
var student1 = new Student('dhanu', 22, 89.75);
console.log(student1);
// student1.printDetails();
//array
//object using literal
var student2 = {
    name: 'vaibhav',
    age: 22,
    marks: 85,
    degree: 'BE'
};
console.log(student2);
//array
var students = [
    new Student('chikku', 299, 100),
    {
        name: 'Laddu',
        age: 200,
        marks: 500,
        degree: 'BE'
    },
    student2,
    student1
];
for (var _i = 0, students_1 = students; _i < students_1.length; _i++) {
    var student = students_1[_i];
    console.log(student);
}
var D = /** @class */ (function (_super) {
    __extends(D, _super);
    function D(name, age, marks, degree) {
        return _super.call(this, name, age, marks) || this;
    }
    return D;
}(Student));
