package com.capgemini.selenium.calculator;

import org.junit.Assert;
import org.junit.Test;

public class CalculatorTest {
	
	@Test
	public void addTest() {
		
		Calculator cal = new Calculator();
		int a = 10;
		int b = 20;
		int expected = 30;
		int actual = cal.add(a , b);
		Assert.assertEquals(expected, actual);
		
	}
	
	@Test
	public void subTest() {
		
		Calculator cal = new Calculator();
		int a = 50;
		int b = 20;
		int expected = 30;
		int actual = cal.sub(a , b);
		Assert.assertEquals(expected, actual);
		
	}
	
	@Test
	public void mulTest() {
		
		Calculator cal = new Calculator();
		int a = 50;
		int b = 2;
		int expected = 100;
		int actual = cal.mul(a , b);
		Assert.assertEquals(expected, actual);
		
	}
	
	@Test
	public void divTest() {
		
		Calculator cal = new Calculator();
		int a = 40;
		int b = 20;
		int expected = 2;
		int actual = cal.div(a , b);
		Assert.assertEquals(expected, actual);
		
	}

}
