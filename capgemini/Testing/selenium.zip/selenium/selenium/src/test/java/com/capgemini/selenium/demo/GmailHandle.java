package com.capgemini.selenium.demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailHandle {

	

static {
		
	System.setProperty("webdriver.chrome.driver", "./src/main/resource/driver/chromedriver.exe");
	   }//end of static 
	
	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.gmail.com");
		driver.findElement(By.id("identifierId")).sendKeys("bhongdhanashri@gmail.com");
		
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		driver.findElement(By.name("password")).sendKeys("dhanashri*");
		driver.findElement(By.xpath("//input[@class='whsOnd zHQkBf']"));
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		driver.findElement(By.xpath("//span[text()='Send']")).click();

        driver.quit();

	}
}
