package com.capgemini.junit;

public class Sum {

	public int add(int a , int b) {
		
		return a + b;
	}   
	
	public int addThree(int a , int b , int c) {
		
		return a + b + c;
	}
	
}  
