package com.capgemini.junit;

public class Calculator {

	public int add(int a , int b) {
		return a + b;
	} 
	
	public int substract(int c , int d) {
		return c - d;
	}
	
	public int multiply( int s , int t) {
		return s * t;
	}
	
	public int divide( int g , int v) {
		return g/v;
	}
} 
