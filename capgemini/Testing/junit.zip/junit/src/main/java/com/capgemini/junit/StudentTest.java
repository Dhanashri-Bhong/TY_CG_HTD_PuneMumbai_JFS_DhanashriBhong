package com.capgemini.junit;

public class StudentTest {
	public static void main(String[] args) {

	Student s = new Student("Dhanu" , 86.36 , 'F');
	Student s1 = new Student("Vaibhav" , 85.36 , 'M');
	
	School sc = new School();
	
      Student	regstu = sc.registerStudent(s);
      Student	regstu1 = sc.registerStudent(s1);

	System.out.println("Id is "+ regstu.getId());
	System.out.println("Name is : "+regstu.getName());
	System.out.println("-----------------------------------------");
	System.out.println("Id is "+ regstu1.getId());
	System.out.println("Name is : "+regstu1.getName());
	}

}
