package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTestThree {
	@Test
	 public void addTestThree() {
   Sum s = new Sum();
   int i = s.addThree(10, 5 ,20);
   assertEquals(35, i);
	} 

}
