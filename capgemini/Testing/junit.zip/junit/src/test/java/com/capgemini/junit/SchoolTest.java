package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SchoolTest {

	private School school;
	
	@BeforeEach
	public void createObject() {
	 school = new School();	
	}
	
	@Test
	public void testRgisterStudent() {
		Student student = new Student("Chikku" , 96.23 , 'M');
		Student stu = school.registerStudent(student);
		assertEquals(1, stu.getId());
	}
	
	@Test
	public void testRgisterStudentForNull() {
		//Student student = new Student("Chikku" , 96.23 , 'M');
		//Student stu = school.registerStudent(student);
		assertThrows(NullPointerException.class, ()->school.registerStudent(null));
	}
}
