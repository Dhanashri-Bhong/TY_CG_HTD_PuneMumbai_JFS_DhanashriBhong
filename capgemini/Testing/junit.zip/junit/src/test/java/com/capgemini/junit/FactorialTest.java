package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FactorialTest {

	@Test
	public void factTest() {
		Factorial f = new Factorial();
		int d = f.fact(5);
		assertEquals(120, d);
	}
	
	@Test
	public void factTestForZero() {
		Factorial f = new Factorial();
		int d = f.fact(0);
		assertEquals(1, d);
	}
	
	@Test
	public void factTestForNegative() {
		Factorial f = new Factorial();
		int d = f.fact(-5);
		assertEquals(1, d);
	}
	
}
