package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	
	Calculator calculator= null;
	
	@BeforeEach
	public void createObject() {
		 calculator= new Calculator();
	}
  
	@Test
	public void addTest() {
		int q = calculator.add(-45, -10);
		assertEquals(-55, q);
	}

	@Test
	public void substractTest() {
		int q = calculator.substract(20, 10);
		assertEquals(10, q);
	} 
	
	@Test
	public void multiplyTest() {
		int q = calculator.multiply(10, 5);
		assertEquals(50, q);
	}
	
	@Test
	public void divideTest() {
		int q = calculator.divide(50, 10);
		assertEquals(5, q);
	}
	
	@Test
	public void divideByZeroTest() {
		assertThrows(ArithmeticException.class, ()->calculator.divide(50, 0));
	}

}
